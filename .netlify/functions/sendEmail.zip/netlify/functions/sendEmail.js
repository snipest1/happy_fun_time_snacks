var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to2, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to2, key) && key !== except)
        __defProp(to2, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to2;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/node_modules/delayed-stream/lib/delayed_stream.js
var require_delayed_stream = __commonJS({
  "netlify/functions/node_modules/delayed-stream/lib/delayed_stream.js"(exports2, module2) {
    var Stream = require("stream").Stream;
    var util = require("util");
    module2.exports = DelayedStream;
    function DelayedStream() {
      this.source = null;
      this.dataSize = 0;
      this.maxDataSize = 1024 * 1024;
      this.pauseStream = true;
      this._maxDataSizeExceeded = false;
      this._released = false;
      this._bufferedEvents = [];
    }
    util.inherits(DelayedStream, Stream);
    DelayedStream.create = function(source, options) {
      var delayedStream = new this();
      options = options || {};
      for (var option in options) {
        delayedStream[option] = options[option];
      }
      delayedStream.source = source;
      var realEmit = source.emit;
      source.emit = function() {
        delayedStream._handleEmit(arguments);
        return realEmit.apply(source, arguments);
      };
      source.on("error", function() {
      });
      if (delayedStream.pauseStream) {
        source.pause();
      }
      return delayedStream;
    };
    Object.defineProperty(DelayedStream.prototype, "readable", {
      configurable: true,
      enumerable: true,
      get: function() {
        return this.source.readable;
      }
    });
    DelayedStream.prototype.setEncoding = function() {
      return this.source.setEncoding.apply(this.source, arguments);
    };
    DelayedStream.prototype.resume = function() {
      if (!this._released) {
        this.release();
      }
      this.source.resume();
    };
    DelayedStream.prototype.pause = function() {
      this.source.pause();
    };
    DelayedStream.prototype.release = function() {
      this._released = true;
      this._bufferedEvents.forEach(function(args) {
        this.emit.apply(this, args);
      }.bind(this));
      this._bufferedEvents = [];
    };
    DelayedStream.prototype.pipe = function() {
      var r2 = Stream.prototype.pipe.apply(this, arguments);
      this.resume();
      return r2;
    };
    DelayedStream.prototype._handleEmit = function(args) {
      if (this._released) {
        this.emit.apply(this, args);
        return;
      }
      if (args[0] === "data") {
        this.dataSize += args[1].length;
        this._checkIfMaxDataSizeExceeded();
      }
      this._bufferedEvents.push(args);
    };
    DelayedStream.prototype._checkIfMaxDataSizeExceeded = function() {
      if (this._maxDataSizeExceeded) {
        return;
      }
      if (this.dataSize <= this.maxDataSize) {
        return;
      }
      this._maxDataSizeExceeded = true;
      var message = "DelayedStream#maxDataSize of " + this.maxDataSize + " bytes exceeded.";
      this.emit("error", new Error(message));
    };
  }
});

// netlify/functions/node_modules/combined-stream/lib/combined_stream.js
var require_combined_stream = __commonJS({
  "netlify/functions/node_modules/combined-stream/lib/combined_stream.js"(exports2, module2) {
    var util = require("util");
    var Stream = require("stream").Stream;
    var DelayedStream = require_delayed_stream();
    module2.exports = CombinedStream;
    function CombinedStream() {
      this.writable = false;
      this.readable = true;
      this.dataSize = 0;
      this.maxDataSize = 2 * 1024 * 1024;
      this.pauseStreams = true;
      this._released = false;
      this._streams = [];
      this._currentStream = null;
      this._insideLoop = false;
      this._pendingNext = false;
    }
    util.inherits(CombinedStream, Stream);
    CombinedStream.create = function(options) {
      var combinedStream = new this();
      options = options || {};
      for (var option in options) {
        combinedStream[option] = options[option];
      }
      return combinedStream;
    };
    CombinedStream.isStreamLike = function(stream) {
      return typeof stream !== "function" && typeof stream !== "string" && typeof stream !== "boolean" && typeof stream !== "number" && !Buffer.isBuffer(stream);
    };
    CombinedStream.prototype.append = function(stream) {
      var isStreamLike = CombinedStream.isStreamLike(stream);
      if (isStreamLike) {
        if (!(stream instanceof DelayedStream)) {
          var newStream = DelayedStream.create(stream, {
            maxDataSize: Infinity,
            pauseStream: this.pauseStreams
          });
          stream.on("data", this._checkDataSize.bind(this));
          stream = newStream;
        }
        this._handleErrors(stream);
        if (this.pauseStreams) {
          stream.pause();
        }
      }
      this._streams.push(stream);
      return this;
    };
    CombinedStream.prototype.pipe = function(dest, options) {
      Stream.prototype.pipe.call(this, dest, options);
      this.resume();
      return dest;
    };
    CombinedStream.prototype._getNext = function() {
      this._currentStream = null;
      if (this._insideLoop) {
        this._pendingNext = true;
        return;
      }
      this._insideLoop = true;
      try {
        do {
          this._pendingNext = false;
          this._realGetNext();
        } while (this._pendingNext);
      } finally {
        this._insideLoop = false;
      }
    };
    CombinedStream.prototype._realGetNext = function() {
      var stream = this._streams.shift();
      if (typeof stream == "undefined") {
        this.end();
        return;
      }
      if (typeof stream !== "function") {
        this._pipeNext(stream);
        return;
      }
      var getStream = stream;
      getStream(function(stream2) {
        var isStreamLike = CombinedStream.isStreamLike(stream2);
        if (isStreamLike) {
          stream2.on("data", this._checkDataSize.bind(this));
          this._handleErrors(stream2);
        }
        this._pipeNext(stream2);
      }.bind(this));
    };
    CombinedStream.prototype._pipeNext = function(stream) {
      this._currentStream = stream;
      var isStreamLike = CombinedStream.isStreamLike(stream);
      if (isStreamLike) {
        stream.on("end", this._getNext.bind(this));
        stream.pipe(this, { end: false });
        return;
      }
      var value = stream;
      this.write(value);
      this._getNext();
    };
    CombinedStream.prototype._handleErrors = function(stream) {
      var self2 = this;
      stream.on("error", function(err) {
        self2._emitError(err);
      });
    };
    CombinedStream.prototype.write = function(data) {
      this.emit("data", data);
    };
    CombinedStream.prototype.pause = function() {
      if (!this.pauseStreams) {
        return;
      }
      if (this.pauseStreams && this._currentStream && typeof this._currentStream.pause == "function") this._currentStream.pause();
      this.emit("pause");
    };
    CombinedStream.prototype.resume = function() {
      if (!this._released) {
        this._released = true;
        this.writable = true;
        this._getNext();
      }
      if (this.pauseStreams && this._currentStream && typeof this._currentStream.resume == "function") this._currentStream.resume();
      this.emit("resume");
    };
    CombinedStream.prototype.end = function() {
      this._reset();
      this.emit("end");
    };
    CombinedStream.prototype.destroy = function() {
      this._reset();
      this.emit("close");
    };
    CombinedStream.prototype._reset = function() {
      this.writable = false;
      this._streams = [];
      this._currentStream = null;
    };
    CombinedStream.prototype._checkDataSize = function() {
      this._updateDataSize();
      if (this.dataSize <= this.maxDataSize) {
        return;
      }
      var message = "DelayedStream#maxDataSize of " + this.maxDataSize + " bytes exceeded.";
      this._emitError(new Error(message));
    };
    CombinedStream.prototype._updateDataSize = function() {
      this.dataSize = 0;
      var self2 = this;
      this._streams.forEach(function(stream) {
        if (!stream.dataSize) {
          return;
        }
        self2.dataSize += stream.dataSize;
      });
      if (this._currentStream && this._currentStream.dataSize) {
        this.dataSize += this._currentStream.dataSize;
      }
    };
    CombinedStream.prototype._emitError = function(err) {
      this._reset();
      this.emit("error", err);
    };
  }
});

// netlify/functions/node_modules/mime-db/db.json
var require_db = __commonJS({
  "netlify/functions/node_modules/mime-db/db.json"(exports2, module2) {
    module2.exports = {
      "application/1d-interleaved-parityfec": {
        source: "iana"
      },
      "application/3gpdash-qoe-report+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/3gpp-ims+xml": {
        source: "iana",
        compressible: true
      },
      "application/3gpphal+json": {
        source: "iana",
        compressible: true
      },
      "application/3gpphalforms+json": {
        source: "iana",
        compressible: true
      },
      "application/a2l": {
        source: "iana"
      },
      "application/ace+cbor": {
        source: "iana"
      },
      "application/activemessage": {
        source: "iana"
      },
      "application/activity+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-costmap+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-costmapfilter+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-directory+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-endpointcost+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-endpointcostparams+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-endpointprop+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-endpointpropparams+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-error+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-networkmap+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-networkmapfilter+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-updatestreamcontrol+json": {
        source: "iana",
        compressible: true
      },
      "application/alto-updatestreamparams+json": {
        source: "iana",
        compressible: true
      },
      "application/aml": {
        source: "iana"
      },
      "application/andrew-inset": {
        source: "iana",
        extensions: ["ez"]
      },
      "application/applefile": {
        source: "iana"
      },
      "application/applixware": {
        source: "apache",
        extensions: ["aw"]
      },
      "application/at+jwt": {
        source: "iana"
      },
      "application/atf": {
        source: "iana"
      },
      "application/atfx": {
        source: "iana"
      },
      "application/atom+xml": {
        source: "iana",
        compressible: true,
        extensions: ["atom"]
      },
      "application/atomcat+xml": {
        source: "iana",
        compressible: true,
        extensions: ["atomcat"]
      },
      "application/atomdeleted+xml": {
        source: "iana",
        compressible: true,
        extensions: ["atomdeleted"]
      },
      "application/atomicmail": {
        source: "iana"
      },
      "application/atomsvc+xml": {
        source: "iana",
        compressible: true,
        extensions: ["atomsvc"]
      },
      "application/atsc-dwd+xml": {
        source: "iana",
        compressible: true,
        extensions: ["dwd"]
      },
      "application/atsc-dynamic-event-message": {
        source: "iana"
      },
      "application/atsc-held+xml": {
        source: "iana",
        compressible: true,
        extensions: ["held"]
      },
      "application/atsc-rdt+json": {
        source: "iana",
        compressible: true
      },
      "application/atsc-rsat+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rsat"]
      },
      "application/atxml": {
        source: "iana"
      },
      "application/auth-policy+xml": {
        source: "iana",
        compressible: true
      },
      "application/bacnet-xdd+zip": {
        source: "iana",
        compressible: false
      },
      "application/batch-smtp": {
        source: "iana"
      },
      "application/bdoc": {
        compressible: false,
        extensions: ["bdoc"]
      },
      "application/beep+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/calendar+json": {
        source: "iana",
        compressible: true
      },
      "application/calendar+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xcs"]
      },
      "application/call-completion": {
        source: "iana"
      },
      "application/cals-1840": {
        source: "iana"
      },
      "application/captive+json": {
        source: "iana",
        compressible: true
      },
      "application/cbor": {
        source: "iana"
      },
      "application/cbor-seq": {
        source: "iana"
      },
      "application/cccex": {
        source: "iana"
      },
      "application/ccmp+xml": {
        source: "iana",
        compressible: true
      },
      "application/ccxml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["ccxml"]
      },
      "application/cdfx+xml": {
        source: "iana",
        compressible: true,
        extensions: ["cdfx"]
      },
      "application/cdmi-capability": {
        source: "iana",
        extensions: ["cdmia"]
      },
      "application/cdmi-container": {
        source: "iana",
        extensions: ["cdmic"]
      },
      "application/cdmi-domain": {
        source: "iana",
        extensions: ["cdmid"]
      },
      "application/cdmi-object": {
        source: "iana",
        extensions: ["cdmio"]
      },
      "application/cdmi-queue": {
        source: "iana",
        extensions: ["cdmiq"]
      },
      "application/cdni": {
        source: "iana"
      },
      "application/cea": {
        source: "iana"
      },
      "application/cea-2018+xml": {
        source: "iana",
        compressible: true
      },
      "application/cellml+xml": {
        source: "iana",
        compressible: true
      },
      "application/cfw": {
        source: "iana"
      },
      "application/city+json": {
        source: "iana",
        compressible: true
      },
      "application/clr": {
        source: "iana"
      },
      "application/clue+xml": {
        source: "iana",
        compressible: true
      },
      "application/clue_info+xml": {
        source: "iana",
        compressible: true
      },
      "application/cms": {
        source: "iana"
      },
      "application/cnrp+xml": {
        source: "iana",
        compressible: true
      },
      "application/coap-group+json": {
        source: "iana",
        compressible: true
      },
      "application/coap-payload": {
        source: "iana"
      },
      "application/commonground": {
        source: "iana"
      },
      "application/conference-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/cose": {
        source: "iana"
      },
      "application/cose-key": {
        source: "iana"
      },
      "application/cose-key-set": {
        source: "iana"
      },
      "application/cpl+xml": {
        source: "iana",
        compressible: true,
        extensions: ["cpl"]
      },
      "application/csrattrs": {
        source: "iana"
      },
      "application/csta+xml": {
        source: "iana",
        compressible: true
      },
      "application/cstadata+xml": {
        source: "iana",
        compressible: true
      },
      "application/csvm+json": {
        source: "iana",
        compressible: true
      },
      "application/cu-seeme": {
        source: "apache",
        extensions: ["cu"]
      },
      "application/cwt": {
        source: "iana"
      },
      "application/cybercash": {
        source: "iana"
      },
      "application/dart": {
        compressible: true
      },
      "application/dash+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mpd"]
      },
      "application/dash-patch+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mpp"]
      },
      "application/dashdelta": {
        source: "iana"
      },
      "application/davmount+xml": {
        source: "iana",
        compressible: true,
        extensions: ["davmount"]
      },
      "application/dca-rft": {
        source: "iana"
      },
      "application/dcd": {
        source: "iana"
      },
      "application/dec-dx": {
        source: "iana"
      },
      "application/dialog-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/dicom": {
        source: "iana"
      },
      "application/dicom+json": {
        source: "iana",
        compressible: true
      },
      "application/dicom+xml": {
        source: "iana",
        compressible: true
      },
      "application/dii": {
        source: "iana"
      },
      "application/dit": {
        source: "iana"
      },
      "application/dns": {
        source: "iana"
      },
      "application/dns+json": {
        source: "iana",
        compressible: true
      },
      "application/dns-message": {
        source: "iana"
      },
      "application/docbook+xml": {
        source: "apache",
        compressible: true,
        extensions: ["dbk"]
      },
      "application/dots+cbor": {
        source: "iana"
      },
      "application/dskpp+xml": {
        source: "iana",
        compressible: true
      },
      "application/dssc+der": {
        source: "iana",
        extensions: ["dssc"]
      },
      "application/dssc+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xdssc"]
      },
      "application/dvcs": {
        source: "iana"
      },
      "application/ecmascript": {
        source: "iana",
        compressible: true,
        extensions: ["es", "ecma"]
      },
      "application/edi-consent": {
        source: "iana"
      },
      "application/edi-x12": {
        source: "iana",
        compressible: false
      },
      "application/edifact": {
        source: "iana",
        compressible: false
      },
      "application/efi": {
        source: "iana"
      },
      "application/elm+json": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/elm+xml": {
        source: "iana",
        compressible: true
      },
      "application/emergencycalldata.cap+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/emergencycalldata.comment+xml": {
        source: "iana",
        compressible: true
      },
      "application/emergencycalldata.control+xml": {
        source: "iana",
        compressible: true
      },
      "application/emergencycalldata.deviceinfo+xml": {
        source: "iana",
        compressible: true
      },
      "application/emergencycalldata.ecall.msd": {
        source: "iana"
      },
      "application/emergencycalldata.providerinfo+xml": {
        source: "iana",
        compressible: true
      },
      "application/emergencycalldata.serviceinfo+xml": {
        source: "iana",
        compressible: true
      },
      "application/emergencycalldata.subscriberinfo+xml": {
        source: "iana",
        compressible: true
      },
      "application/emergencycalldata.veds+xml": {
        source: "iana",
        compressible: true
      },
      "application/emma+xml": {
        source: "iana",
        compressible: true,
        extensions: ["emma"]
      },
      "application/emotionml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["emotionml"]
      },
      "application/encaprtp": {
        source: "iana"
      },
      "application/epp+xml": {
        source: "iana",
        compressible: true
      },
      "application/epub+zip": {
        source: "iana",
        compressible: false,
        extensions: ["epub"]
      },
      "application/eshop": {
        source: "iana"
      },
      "application/exi": {
        source: "iana",
        extensions: ["exi"]
      },
      "application/expect-ct-report+json": {
        source: "iana",
        compressible: true
      },
      "application/express": {
        source: "iana",
        extensions: ["exp"]
      },
      "application/fastinfoset": {
        source: "iana"
      },
      "application/fastsoap": {
        source: "iana"
      },
      "application/fdt+xml": {
        source: "iana",
        compressible: true,
        extensions: ["fdt"]
      },
      "application/fhir+json": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/fhir+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/fido.trusted-apps+json": {
        compressible: true
      },
      "application/fits": {
        source: "iana"
      },
      "application/flexfec": {
        source: "iana"
      },
      "application/font-sfnt": {
        source: "iana"
      },
      "application/font-tdpfr": {
        source: "iana",
        extensions: ["pfr"]
      },
      "application/font-woff": {
        source: "iana",
        compressible: false
      },
      "application/framework-attributes+xml": {
        source: "iana",
        compressible: true
      },
      "application/geo+json": {
        source: "iana",
        compressible: true,
        extensions: ["geojson"]
      },
      "application/geo+json-seq": {
        source: "iana"
      },
      "application/geopackage+sqlite3": {
        source: "iana"
      },
      "application/geoxacml+xml": {
        source: "iana",
        compressible: true
      },
      "application/gltf-buffer": {
        source: "iana"
      },
      "application/gml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["gml"]
      },
      "application/gpx+xml": {
        source: "apache",
        compressible: true,
        extensions: ["gpx"]
      },
      "application/gxf": {
        source: "apache",
        extensions: ["gxf"]
      },
      "application/gzip": {
        source: "iana",
        compressible: false,
        extensions: ["gz"]
      },
      "application/h224": {
        source: "iana"
      },
      "application/held+xml": {
        source: "iana",
        compressible: true
      },
      "application/hjson": {
        extensions: ["hjson"]
      },
      "application/http": {
        source: "iana"
      },
      "application/hyperstudio": {
        source: "iana",
        extensions: ["stk"]
      },
      "application/ibe-key-request+xml": {
        source: "iana",
        compressible: true
      },
      "application/ibe-pkg-reply+xml": {
        source: "iana",
        compressible: true
      },
      "application/ibe-pp-data": {
        source: "iana"
      },
      "application/iges": {
        source: "iana"
      },
      "application/im-iscomposing+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/index": {
        source: "iana"
      },
      "application/index.cmd": {
        source: "iana"
      },
      "application/index.obj": {
        source: "iana"
      },
      "application/index.response": {
        source: "iana"
      },
      "application/index.vnd": {
        source: "iana"
      },
      "application/inkml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["ink", "inkml"]
      },
      "application/iotp": {
        source: "iana"
      },
      "application/ipfix": {
        source: "iana",
        extensions: ["ipfix"]
      },
      "application/ipp": {
        source: "iana"
      },
      "application/isup": {
        source: "iana"
      },
      "application/its+xml": {
        source: "iana",
        compressible: true,
        extensions: ["its"]
      },
      "application/java-archive": {
        source: "apache",
        compressible: false,
        extensions: ["jar", "war", "ear"]
      },
      "application/java-serialized-object": {
        source: "apache",
        compressible: false,
        extensions: ["ser"]
      },
      "application/java-vm": {
        source: "apache",
        compressible: false,
        extensions: ["class"]
      },
      "application/javascript": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["js", "mjs"]
      },
      "application/jf2feed+json": {
        source: "iana",
        compressible: true
      },
      "application/jose": {
        source: "iana"
      },
      "application/jose+json": {
        source: "iana",
        compressible: true
      },
      "application/jrd+json": {
        source: "iana",
        compressible: true
      },
      "application/jscalendar+json": {
        source: "iana",
        compressible: true
      },
      "application/json": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["json", "map"]
      },
      "application/json-patch+json": {
        source: "iana",
        compressible: true
      },
      "application/json-seq": {
        source: "iana"
      },
      "application/json5": {
        extensions: ["json5"]
      },
      "application/jsonml+json": {
        source: "apache",
        compressible: true,
        extensions: ["jsonml"]
      },
      "application/jwk+json": {
        source: "iana",
        compressible: true
      },
      "application/jwk-set+json": {
        source: "iana",
        compressible: true
      },
      "application/jwt": {
        source: "iana"
      },
      "application/kpml-request+xml": {
        source: "iana",
        compressible: true
      },
      "application/kpml-response+xml": {
        source: "iana",
        compressible: true
      },
      "application/ld+json": {
        source: "iana",
        compressible: true,
        extensions: ["jsonld"]
      },
      "application/lgr+xml": {
        source: "iana",
        compressible: true,
        extensions: ["lgr"]
      },
      "application/link-format": {
        source: "iana"
      },
      "application/load-control+xml": {
        source: "iana",
        compressible: true
      },
      "application/lost+xml": {
        source: "iana",
        compressible: true,
        extensions: ["lostxml"]
      },
      "application/lostsync+xml": {
        source: "iana",
        compressible: true
      },
      "application/lpf+zip": {
        source: "iana",
        compressible: false
      },
      "application/lxf": {
        source: "iana"
      },
      "application/mac-binhex40": {
        source: "iana",
        extensions: ["hqx"]
      },
      "application/mac-compactpro": {
        source: "apache",
        extensions: ["cpt"]
      },
      "application/macwriteii": {
        source: "iana"
      },
      "application/mads+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mads"]
      },
      "application/manifest+json": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["webmanifest"]
      },
      "application/marc": {
        source: "iana",
        extensions: ["mrc"]
      },
      "application/marcxml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mrcx"]
      },
      "application/mathematica": {
        source: "iana",
        extensions: ["ma", "nb", "mb"]
      },
      "application/mathml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mathml"]
      },
      "application/mathml-content+xml": {
        source: "iana",
        compressible: true
      },
      "application/mathml-presentation+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-associated-procedure-description+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-deregister+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-envelope+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-msk+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-msk-response+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-protection-description+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-reception-report+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-register+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-register-response+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-schedule+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbms-user-service-description+xml": {
        source: "iana",
        compressible: true
      },
      "application/mbox": {
        source: "iana",
        extensions: ["mbox"]
      },
      "application/media-policy-dataset+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mpf"]
      },
      "application/media_control+xml": {
        source: "iana",
        compressible: true
      },
      "application/mediaservercontrol+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mscml"]
      },
      "application/merge-patch+json": {
        source: "iana",
        compressible: true
      },
      "application/metalink+xml": {
        source: "apache",
        compressible: true,
        extensions: ["metalink"]
      },
      "application/metalink4+xml": {
        source: "iana",
        compressible: true,
        extensions: ["meta4"]
      },
      "application/mets+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mets"]
      },
      "application/mf4": {
        source: "iana"
      },
      "application/mikey": {
        source: "iana"
      },
      "application/mipc": {
        source: "iana"
      },
      "application/missing-blocks+cbor-seq": {
        source: "iana"
      },
      "application/mmt-aei+xml": {
        source: "iana",
        compressible: true,
        extensions: ["maei"]
      },
      "application/mmt-usd+xml": {
        source: "iana",
        compressible: true,
        extensions: ["musd"]
      },
      "application/mods+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mods"]
      },
      "application/moss-keys": {
        source: "iana"
      },
      "application/moss-signature": {
        source: "iana"
      },
      "application/mosskey-data": {
        source: "iana"
      },
      "application/mosskey-request": {
        source: "iana"
      },
      "application/mp21": {
        source: "iana",
        extensions: ["m21", "mp21"]
      },
      "application/mp4": {
        source: "iana",
        extensions: ["mp4s", "m4p"]
      },
      "application/mpeg4-generic": {
        source: "iana"
      },
      "application/mpeg4-iod": {
        source: "iana"
      },
      "application/mpeg4-iod-xmt": {
        source: "iana"
      },
      "application/mrb-consumer+xml": {
        source: "iana",
        compressible: true
      },
      "application/mrb-publish+xml": {
        source: "iana",
        compressible: true
      },
      "application/msc-ivr+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/msc-mixer+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/msword": {
        source: "iana",
        compressible: false,
        extensions: ["doc", "dot"]
      },
      "application/mud+json": {
        source: "iana",
        compressible: true
      },
      "application/multipart-core": {
        source: "iana"
      },
      "application/mxf": {
        source: "iana",
        extensions: ["mxf"]
      },
      "application/n-quads": {
        source: "iana",
        extensions: ["nq"]
      },
      "application/n-triples": {
        source: "iana",
        extensions: ["nt"]
      },
      "application/nasdata": {
        source: "iana"
      },
      "application/news-checkgroups": {
        source: "iana",
        charset: "US-ASCII"
      },
      "application/news-groupinfo": {
        source: "iana",
        charset: "US-ASCII"
      },
      "application/news-transmission": {
        source: "iana"
      },
      "application/nlsml+xml": {
        source: "iana",
        compressible: true
      },
      "application/node": {
        source: "iana",
        extensions: ["cjs"]
      },
      "application/nss": {
        source: "iana"
      },
      "application/oauth-authz-req+jwt": {
        source: "iana"
      },
      "application/oblivious-dns-message": {
        source: "iana"
      },
      "application/ocsp-request": {
        source: "iana"
      },
      "application/ocsp-response": {
        source: "iana"
      },
      "application/octet-stream": {
        source: "iana",
        compressible: false,
        extensions: ["bin", "dms", "lrf", "mar", "so", "dist", "distz", "pkg", "bpk", "dump", "elc", "deploy", "exe", "dll", "deb", "dmg", "iso", "img", "msi", "msp", "msm", "buffer"]
      },
      "application/oda": {
        source: "iana",
        extensions: ["oda"]
      },
      "application/odm+xml": {
        source: "iana",
        compressible: true
      },
      "application/odx": {
        source: "iana"
      },
      "application/oebps-package+xml": {
        source: "iana",
        compressible: true,
        extensions: ["opf"]
      },
      "application/ogg": {
        source: "iana",
        compressible: false,
        extensions: ["ogx"]
      },
      "application/omdoc+xml": {
        source: "apache",
        compressible: true,
        extensions: ["omdoc"]
      },
      "application/onenote": {
        source: "apache",
        extensions: ["onetoc", "onetoc2", "onetmp", "onepkg"]
      },
      "application/opc-nodeset+xml": {
        source: "iana",
        compressible: true
      },
      "application/oscore": {
        source: "iana"
      },
      "application/oxps": {
        source: "iana",
        extensions: ["oxps"]
      },
      "application/p21": {
        source: "iana"
      },
      "application/p21+zip": {
        source: "iana",
        compressible: false
      },
      "application/p2p-overlay+xml": {
        source: "iana",
        compressible: true,
        extensions: ["relo"]
      },
      "application/parityfec": {
        source: "iana"
      },
      "application/passport": {
        source: "iana"
      },
      "application/patch-ops-error+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xer"]
      },
      "application/pdf": {
        source: "iana",
        compressible: false,
        extensions: ["pdf"]
      },
      "application/pdx": {
        source: "iana"
      },
      "application/pem-certificate-chain": {
        source: "iana"
      },
      "application/pgp-encrypted": {
        source: "iana",
        compressible: false,
        extensions: ["pgp"]
      },
      "application/pgp-keys": {
        source: "iana",
        extensions: ["asc"]
      },
      "application/pgp-signature": {
        source: "iana",
        extensions: ["asc", "sig"]
      },
      "application/pics-rules": {
        source: "apache",
        extensions: ["prf"]
      },
      "application/pidf+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/pidf-diff+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/pkcs10": {
        source: "iana",
        extensions: ["p10"]
      },
      "application/pkcs12": {
        source: "iana"
      },
      "application/pkcs7-mime": {
        source: "iana",
        extensions: ["p7m", "p7c"]
      },
      "application/pkcs7-signature": {
        source: "iana",
        extensions: ["p7s"]
      },
      "application/pkcs8": {
        source: "iana",
        extensions: ["p8"]
      },
      "application/pkcs8-encrypted": {
        source: "iana"
      },
      "application/pkix-attr-cert": {
        source: "iana",
        extensions: ["ac"]
      },
      "application/pkix-cert": {
        source: "iana",
        extensions: ["cer"]
      },
      "application/pkix-crl": {
        source: "iana",
        extensions: ["crl"]
      },
      "application/pkix-pkipath": {
        source: "iana",
        extensions: ["pkipath"]
      },
      "application/pkixcmp": {
        source: "iana",
        extensions: ["pki"]
      },
      "application/pls+xml": {
        source: "iana",
        compressible: true,
        extensions: ["pls"]
      },
      "application/poc-settings+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/postscript": {
        source: "iana",
        compressible: true,
        extensions: ["ai", "eps", "ps"]
      },
      "application/ppsp-tracker+json": {
        source: "iana",
        compressible: true
      },
      "application/problem+json": {
        source: "iana",
        compressible: true
      },
      "application/problem+xml": {
        source: "iana",
        compressible: true
      },
      "application/provenance+xml": {
        source: "iana",
        compressible: true,
        extensions: ["provx"]
      },
      "application/prs.alvestrand.titrax-sheet": {
        source: "iana"
      },
      "application/prs.cww": {
        source: "iana",
        extensions: ["cww"]
      },
      "application/prs.cyn": {
        source: "iana",
        charset: "7-BIT"
      },
      "application/prs.hpub+zip": {
        source: "iana",
        compressible: false
      },
      "application/prs.nprend": {
        source: "iana"
      },
      "application/prs.plucker": {
        source: "iana"
      },
      "application/prs.rdf-xml-crypt": {
        source: "iana"
      },
      "application/prs.xsf+xml": {
        source: "iana",
        compressible: true
      },
      "application/pskc+xml": {
        source: "iana",
        compressible: true,
        extensions: ["pskcxml"]
      },
      "application/pvd+json": {
        source: "iana",
        compressible: true
      },
      "application/qsig": {
        source: "iana"
      },
      "application/raml+yaml": {
        compressible: true,
        extensions: ["raml"]
      },
      "application/raptorfec": {
        source: "iana"
      },
      "application/rdap+json": {
        source: "iana",
        compressible: true
      },
      "application/rdf+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rdf", "owl"]
      },
      "application/reginfo+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rif"]
      },
      "application/relax-ng-compact-syntax": {
        source: "iana",
        extensions: ["rnc"]
      },
      "application/remote-printing": {
        source: "iana"
      },
      "application/reputon+json": {
        source: "iana",
        compressible: true
      },
      "application/resource-lists+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rl"]
      },
      "application/resource-lists-diff+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rld"]
      },
      "application/rfc+xml": {
        source: "iana",
        compressible: true
      },
      "application/riscos": {
        source: "iana"
      },
      "application/rlmi+xml": {
        source: "iana",
        compressible: true
      },
      "application/rls-services+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rs"]
      },
      "application/route-apd+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rapd"]
      },
      "application/route-s-tsid+xml": {
        source: "iana",
        compressible: true,
        extensions: ["sls"]
      },
      "application/route-usd+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rusd"]
      },
      "application/rpki-ghostbusters": {
        source: "iana",
        extensions: ["gbr"]
      },
      "application/rpki-manifest": {
        source: "iana",
        extensions: ["mft"]
      },
      "application/rpki-publication": {
        source: "iana"
      },
      "application/rpki-roa": {
        source: "iana",
        extensions: ["roa"]
      },
      "application/rpki-updown": {
        source: "iana"
      },
      "application/rsd+xml": {
        source: "apache",
        compressible: true,
        extensions: ["rsd"]
      },
      "application/rss+xml": {
        source: "apache",
        compressible: true,
        extensions: ["rss"]
      },
      "application/rtf": {
        source: "iana",
        compressible: true,
        extensions: ["rtf"]
      },
      "application/rtploopback": {
        source: "iana"
      },
      "application/rtx": {
        source: "iana"
      },
      "application/samlassertion+xml": {
        source: "iana",
        compressible: true
      },
      "application/samlmetadata+xml": {
        source: "iana",
        compressible: true
      },
      "application/sarif+json": {
        source: "iana",
        compressible: true
      },
      "application/sarif-external-properties+json": {
        source: "iana",
        compressible: true
      },
      "application/sbe": {
        source: "iana"
      },
      "application/sbml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["sbml"]
      },
      "application/scaip+xml": {
        source: "iana",
        compressible: true
      },
      "application/scim+json": {
        source: "iana",
        compressible: true
      },
      "application/scvp-cv-request": {
        source: "iana",
        extensions: ["scq"]
      },
      "application/scvp-cv-response": {
        source: "iana",
        extensions: ["scs"]
      },
      "application/scvp-vp-request": {
        source: "iana",
        extensions: ["spq"]
      },
      "application/scvp-vp-response": {
        source: "iana",
        extensions: ["spp"]
      },
      "application/sdp": {
        source: "iana",
        extensions: ["sdp"]
      },
      "application/secevent+jwt": {
        source: "iana"
      },
      "application/senml+cbor": {
        source: "iana"
      },
      "application/senml+json": {
        source: "iana",
        compressible: true
      },
      "application/senml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["senmlx"]
      },
      "application/senml-etch+cbor": {
        source: "iana"
      },
      "application/senml-etch+json": {
        source: "iana",
        compressible: true
      },
      "application/senml-exi": {
        source: "iana"
      },
      "application/sensml+cbor": {
        source: "iana"
      },
      "application/sensml+json": {
        source: "iana",
        compressible: true
      },
      "application/sensml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["sensmlx"]
      },
      "application/sensml-exi": {
        source: "iana"
      },
      "application/sep+xml": {
        source: "iana",
        compressible: true
      },
      "application/sep-exi": {
        source: "iana"
      },
      "application/session-info": {
        source: "iana"
      },
      "application/set-payment": {
        source: "iana"
      },
      "application/set-payment-initiation": {
        source: "iana",
        extensions: ["setpay"]
      },
      "application/set-registration": {
        source: "iana"
      },
      "application/set-registration-initiation": {
        source: "iana",
        extensions: ["setreg"]
      },
      "application/sgml": {
        source: "iana"
      },
      "application/sgml-open-catalog": {
        source: "iana"
      },
      "application/shf+xml": {
        source: "iana",
        compressible: true,
        extensions: ["shf"]
      },
      "application/sieve": {
        source: "iana",
        extensions: ["siv", "sieve"]
      },
      "application/simple-filter+xml": {
        source: "iana",
        compressible: true
      },
      "application/simple-message-summary": {
        source: "iana"
      },
      "application/simplesymbolcontainer": {
        source: "iana"
      },
      "application/sipc": {
        source: "iana"
      },
      "application/slate": {
        source: "iana"
      },
      "application/smil": {
        source: "iana"
      },
      "application/smil+xml": {
        source: "iana",
        compressible: true,
        extensions: ["smi", "smil"]
      },
      "application/smpte336m": {
        source: "iana"
      },
      "application/soap+fastinfoset": {
        source: "iana"
      },
      "application/soap+xml": {
        source: "iana",
        compressible: true
      },
      "application/sparql-query": {
        source: "iana",
        extensions: ["rq"]
      },
      "application/sparql-results+xml": {
        source: "iana",
        compressible: true,
        extensions: ["srx"]
      },
      "application/spdx+json": {
        source: "iana",
        compressible: true
      },
      "application/spirits-event+xml": {
        source: "iana",
        compressible: true
      },
      "application/sql": {
        source: "iana"
      },
      "application/srgs": {
        source: "iana",
        extensions: ["gram"]
      },
      "application/srgs+xml": {
        source: "iana",
        compressible: true,
        extensions: ["grxml"]
      },
      "application/sru+xml": {
        source: "iana",
        compressible: true,
        extensions: ["sru"]
      },
      "application/ssdl+xml": {
        source: "apache",
        compressible: true,
        extensions: ["ssdl"]
      },
      "application/ssml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["ssml"]
      },
      "application/stix+json": {
        source: "iana",
        compressible: true
      },
      "application/swid+xml": {
        source: "iana",
        compressible: true,
        extensions: ["swidtag"]
      },
      "application/tamp-apex-update": {
        source: "iana"
      },
      "application/tamp-apex-update-confirm": {
        source: "iana"
      },
      "application/tamp-community-update": {
        source: "iana"
      },
      "application/tamp-community-update-confirm": {
        source: "iana"
      },
      "application/tamp-error": {
        source: "iana"
      },
      "application/tamp-sequence-adjust": {
        source: "iana"
      },
      "application/tamp-sequence-adjust-confirm": {
        source: "iana"
      },
      "application/tamp-status-query": {
        source: "iana"
      },
      "application/tamp-status-response": {
        source: "iana"
      },
      "application/tamp-update": {
        source: "iana"
      },
      "application/tamp-update-confirm": {
        source: "iana"
      },
      "application/tar": {
        compressible: true
      },
      "application/taxii+json": {
        source: "iana",
        compressible: true
      },
      "application/td+json": {
        source: "iana",
        compressible: true
      },
      "application/tei+xml": {
        source: "iana",
        compressible: true,
        extensions: ["tei", "teicorpus"]
      },
      "application/tetra_isi": {
        source: "iana"
      },
      "application/thraud+xml": {
        source: "iana",
        compressible: true,
        extensions: ["tfi"]
      },
      "application/timestamp-query": {
        source: "iana"
      },
      "application/timestamp-reply": {
        source: "iana"
      },
      "application/timestamped-data": {
        source: "iana",
        extensions: ["tsd"]
      },
      "application/tlsrpt+gzip": {
        source: "iana"
      },
      "application/tlsrpt+json": {
        source: "iana",
        compressible: true
      },
      "application/tnauthlist": {
        source: "iana"
      },
      "application/token-introspection+jwt": {
        source: "iana"
      },
      "application/toml": {
        compressible: true,
        extensions: ["toml"]
      },
      "application/trickle-ice-sdpfrag": {
        source: "iana"
      },
      "application/trig": {
        source: "iana",
        extensions: ["trig"]
      },
      "application/ttml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["ttml"]
      },
      "application/tve-trigger": {
        source: "iana"
      },
      "application/tzif": {
        source: "iana"
      },
      "application/tzif-leap": {
        source: "iana"
      },
      "application/ubjson": {
        compressible: false,
        extensions: ["ubj"]
      },
      "application/ulpfec": {
        source: "iana"
      },
      "application/urc-grpsheet+xml": {
        source: "iana",
        compressible: true
      },
      "application/urc-ressheet+xml": {
        source: "iana",
        compressible: true,
        extensions: ["rsheet"]
      },
      "application/urc-targetdesc+xml": {
        source: "iana",
        compressible: true,
        extensions: ["td"]
      },
      "application/urc-uisocketdesc+xml": {
        source: "iana",
        compressible: true
      },
      "application/vcard+json": {
        source: "iana",
        compressible: true
      },
      "application/vcard+xml": {
        source: "iana",
        compressible: true
      },
      "application/vemmi": {
        source: "iana"
      },
      "application/vividence.scriptfile": {
        source: "apache"
      },
      "application/vnd.1000minds.decision-model+xml": {
        source: "iana",
        compressible: true,
        extensions: ["1km"]
      },
      "application/vnd.3gpp-prose+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp-prose-pc3ch+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp-v2x-local-service-information": {
        source: "iana"
      },
      "application/vnd.3gpp.5gnas": {
        source: "iana"
      },
      "application/vnd.3gpp.access-transfer-events+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.bsf+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.gmop+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.gtpc": {
        source: "iana"
      },
      "application/vnd.3gpp.interworking-data": {
        source: "iana"
      },
      "application/vnd.3gpp.lpp": {
        source: "iana"
      },
      "application/vnd.3gpp.mc-signalling-ear": {
        source: "iana"
      },
      "application/vnd.3gpp.mcdata-affiliation-command+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcdata-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcdata-payload": {
        source: "iana"
      },
      "application/vnd.3gpp.mcdata-service-config+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcdata-signalling": {
        source: "iana"
      },
      "application/vnd.3gpp.mcdata-ue-config+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcdata-user-profile+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-affiliation-command+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-floor-request+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-location-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-mbms-usage-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-service-config+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-signed+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-ue-config+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-ue-init-config+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcptt-user-profile+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-affiliation-command+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-affiliation-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-location-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-mbms-usage-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-service-config+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-transmission-request+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-ue-config+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mcvideo-user-profile+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.mid-call+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.ngap": {
        source: "iana"
      },
      "application/vnd.3gpp.pfcp": {
        source: "iana"
      },
      "application/vnd.3gpp.pic-bw-large": {
        source: "iana",
        extensions: ["plb"]
      },
      "application/vnd.3gpp.pic-bw-small": {
        source: "iana",
        extensions: ["psb"]
      },
      "application/vnd.3gpp.pic-bw-var": {
        source: "iana",
        extensions: ["pvb"]
      },
      "application/vnd.3gpp.s1ap": {
        source: "iana"
      },
      "application/vnd.3gpp.sms": {
        source: "iana"
      },
      "application/vnd.3gpp.sms+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.srvcc-ext+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.srvcc-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.state-and-event-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp.ussd+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp2.bcmcsinfo+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.3gpp2.sms": {
        source: "iana"
      },
      "application/vnd.3gpp2.tcap": {
        source: "iana",
        extensions: ["tcap"]
      },
      "application/vnd.3lightssoftware.imagescal": {
        source: "iana"
      },
      "application/vnd.3m.post-it-notes": {
        source: "iana",
        extensions: ["pwn"]
      },
      "application/vnd.accpac.simply.aso": {
        source: "iana",
        extensions: ["aso"]
      },
      "application/vnd.accpac.simply.imp": {
        source: "iana",
        extensions: ["imp"]
      },
      "application/vnd.acucobol": {
        source: "iana",
        extensions: ["acu"]
      },
      "application/vnd.acucorp": {
        source: "iana",
        extensions: ["atc", "acutc"]
      },
      "application/vnd.adobe.air-application-installer-package+zip": {
        source: "apache",
        compressible: false,
        extensions: ["air"]
      },
      "application/vnd.adobe.flash.movie": {
        source: "iana"
      },
      "application/vnd.adobe.formscentral.fcdt": {
        source: "iana",
        extensions: ["fcdt"]
      },
      "application/vnd.adobe.fxp": {
        source: "iana",
        extensions: ["fxp", "fxpl"]
      },
      "application/vnd.adobe.partial-upload": {
        source: "iana"
      },
      "application/vnd.adobe.xdp+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xdp"]
      },
      "application/vnd.adobe.xfdf": {
        source: "iana",
        extensions: ["xfdf"]
      },
      "application/vnd.aether.imp": {
        source: "iana"
      },
      "application/vnd.afpc.afplinedata": {
        source: "iana"
      },
      "application/vnd.afpc.afplinedata-pagedef": {
        source: "iana"
      },
      "application/vnd.afpc.cmoca-cmresource": {
        source: "iana"
      },
      "application/vnd.afpc.foca-charset": {
        source: "iana"
      },
      "application/vnd.afpc.foca-codedfont": {
        source: "iana"
      },
      "application/vnd.afpc.foca-codepage": {
        source: "iana"
      },
      "application/vnd.afpc.modca": {
        source: "iana"
      },
      "application/vnd.afpc.modca-cmtable": {
        source: "iana"
      },
      "application/vnd.afpc.modca-formdef": {
        source: "iana"
      },
      "application/vnd.afpc.modca-mediummap": {
        source: "iana"
      },
      "application/vnd.afpc.modca-objectcontainer": {
        source: "iana"
      },
      "application/vnd.afpc.modca-overlay": {
        source: "iana"
      },
      "application/vnd.afpc.modca-pagesegment": {
        source: "iana"
      },
      "application/vnd.age": {
        source: "iana",
        extensions: ["age"]
      },
      "application/vnd.ah-barcode": {
        source: "iana"
      },
      "application/vnd.ahead.space": {
        source: "iana",
        extensions: ["ahead"]
      },
      "application/vnd.airzip.filesecure.azf": {
        source: "iana",
        extensions: ["azf"]
      },
      "application/vnd.airzip.filesecure.azs": {
        source: "iana",
        extensions: ["azs"]
      },
      "application/vnd.amadeus+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.amazon.ebook": {
        source: "apache",
        extensions: ["azw"]
      },
      "application/vnd.amazon.mobi8-ebook": {
        source: "iana"
      },
      "application/vnd.americandynamics.acc": {
        source: "iana",
        extensions: ["acc"]
      },
      "application/vnd.amiga.ami": {
        source: "iana",
        extensions: ["ami"]
      },
      "application/vnd.amundsen.maze+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.android.ota": {
        source: "iana"
      },
      "application/vnd.android.package-archive": {
        source: "apache",
        compressible: false,
        extensions: ["apk"]
      },
      "application/vnd.anki": {
        source: "iana"
      },
      "application/vnd.anser-web-certificate-issue-initiation": {
        source: "iana",
        extensions: ["cii"]
      },
      "application/vnd.anser-web-funds-transfer-initiation": {
        source: "apache",
        extensions: ["fti"]
      },
      "application/vnd.antix.game-component": {
        source: "iana",
        extensions: ["atx"]
      },
      "application/vnd.apache.arrow.file": {
        source: "iana"
      },
      "application/vnd.apache.arrow.stream": {
        source: "iana"
      },
      "application/vnd.apache.thrift.binary": {
        source: "iana"
      },
      "application/vnd.apache.thrift.compact": {
        source: "iana"
      },
      "application/vnd.apache.thrift.json": {
        source: "iana"
      },
      "application/vnd.api+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.aplextor.warrp+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.apothekende.reservation+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.apple.installer+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mpkg"]
      },
      "application/vnd.apple.keynote": {
        source: "iana",
        extensions: ["key"]
      },
      "application/vnd.apple.mpegurl": {
        source: "iana",
        extensions: ["m3u8"]
      },
      "application/vnd.apple.numbers": {
        source: "iana",
        extensions: ["numbers"]
      },
      "application/vnd.apple.pages": {
        source: "iana",
        extensions: ["pages"]
      },
      "application/vnd.apple.pkpass": {
        compressible: false,
        extensions: ["pkpass"]
      },
      "application/vnd.arastra.swi": {
        source: "iana"
      },
      "application/vnd.aristanetworks.swi": {
        source: "iana",
        extensions: ["swi"]
      },
      "application/vnd.artisan+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.artsquare": {
        source: "iana"
      },
      "application/vnd.astraea-software.iota": {
        source: "iana",
        extensions: ["iota"]
      },
      "application/vnd.audiograph": {
        source: "iana",
        extensions: ["aep"]
      },
      "application/vnd.autopackage": {
        source: "iana"
      },
      "application/vnd.avalon+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.avistar+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.balsamiq.bmml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["bmml"]
      },
      "application/vnd.balsamiq.bmpr": {
        source: "iana"
      },
      "application/vnd.banana-accounting": {
        source: "iana"
      },
      "application/vnd.bbf.usp.error": {
        source: "iana"
      },
      "application/vnd.bbf.usp.msg": {
        source: "iana"
      },
      "application/vnd.bbf.usp.msg+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.bekitzur-stech+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.bint.med-content": {
        source: "iana"
      },
      "application/vnd.biopax.rdf+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.blink-idb-value-wrapper": {
        source: "iana"
      },
      "application/vnd.blueice.multipass": {
        source: "iana",
        extensions: ["mpm"]
      },
      "application/vnd.bluetooth.ep.oob": {
        source: "iana"
      },
      "application/vnd.bluetooth.le.oob": {
        source: "iana"
      },
      "application/vnd.bmi": {
        source: "iana",
        extensions: ["bmi"]
      },
      "application/vnd.bpf": {
        source: "iana"
      },
      "application/vnd.bpf3": {
        source: "iana"
      },
      "application/vnd.businessobjects": {
        source: "iana",
        extensions: ["rep"]
      },
      "application/vnd.byu.uapi+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.cab-jscript": {
        source: "iana"
      },
      "application/vnd.canon-cpdl": {
        source: "iana"
      },
      "application/vnd.canon-lips": {
        source: "iana"
      },
      "application/vnd.capasystems-pg+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.cendio.thinlinc.clientconf": {
        source: "iana"
      },
      "application/vnd.century-systems.tcp_stream": {
        source: "iana"
      },
      "application/vnd.chemdraw+xml": {
        source: "iana",
        compressible: true,
        extensions: ["cdxml"]
      },
      "application/vnd.chess-pgn": {
        source: "iana"
      },
      "application/vnd.chipnuts.karaoke-mmd": {
        source: "iana",
        extensions: ["mmd"]
      },
      "application/vnd.ciedi": {
        source: "iana"
      },
      "application/vnd.cinderella": {
        source: "iana",
        extensions: ["cdy"]
      },
      "application/vnd.cirpack.isdn-ext": {
        source: "iana"
      },
      "application/vnd.citationstyles.style+xml": {
        source: "iana",
        compressible: true,
        extensions: ["csl"]
      },
      "application/vnd.claymore": {
        source: "iana",
        extensions: ["cla"]
      },
      "application/vnd.cloanto.rp9": {
        source: "iana",
        extensions: ["rp9"]
      },
      "application/vnd.clonk.c4group": {
        source: "iana",
        extensions: ["c4g", "c4d", "c4f", "c4p", "c4u"]
      },
      "application/vnd.cluetrust.cartomobile-config": {
        source: "iana",
        extensions: ["c11amc"]
      },
      "application/vnd.cluetrust.cartomobile-config-pkg": {
        source: "iana",
        extensions: ["c11amz"]
      },
      "application/vnd.coffeescript": {
        source: "iana"
      },
      "application/vnd.collabio.xodocuments.document": {
        source: "iana"
      },
      "application/vnd.collabio.xodocuments.document-template": {
        source: "iana"
      },
      "application/vnd.collabio.xodocuments.presentation": {
        source: "iana"
      },
      "application/vnd.collabio.xodocuments.presentation-template": {
        source: "iana"
      },
      "application/vnd.collabio.xodocuments.spreadsheet": {
        source: "iana"
      },
      "application/vnd.collabio.xodocuments.spreadsheet-template": {
        source: "iana"
      },
      "application/vnd.collection+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.collection.doc+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.collection.next+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.comicbook+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.comicbook-rar": {
        source: "iana"
      },
      "application/vnd.commerce-battelle": {
        source: "iana"
      },
      "application/vnd.commonspace": {
        source: "iana",
        extensions: ["csp"]
      },
      "application/vnd.contact.cmsg": {
        source: "iana",
        extensions: ["cdbcmsg"]
      },
      "application/vnd.coreos.ignition+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.cosmocaller": {
        source: "iana",
        extensions: ["cmc"]
      },
      "application/vnd.crick.clicker": {
        source: "iana",
        extensions: ["clkx"]
      },
      "application/vnd.crick.clicker.keyboard": {
        source: "iana",
        extensions: ["clkk"]
      },
      "application/vnd.crick.clicker.palette": {
        source: "iana",
        extensions: ["clkp"]
      },
      "application/vnd.crick.clicker.template": {
        source: "iana",
        extensions: ["clkt"]
      },
      "application/vnd.crick.clicker.wordbank": {
        source: "iana",
        extensions: ["clkw"]
      },
      "application/vnd.criticaltools.wbs+xml": {
        source: "iana",
        compressible: true,
        extensions: ["wbs"]
      },
      "application/vnd.cryptii.pipe+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.crypto-shade-file": {
        source: "iana"
      },
      "application/vnd.cryptomator.encrypted": {
        source: "iana"
      },
      "application/vnd.cryptomator.vault": {
        source: "iana"
      },
      "application/vnd.ctc-posml": {
        source: "iana",
        extensions: ["pml"]
      },
      "application/vnd.ctct.ws+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.cups-pdf": {
        source: "iana"
      },
      "application/vnd.cups-postscript": {
        source: "iana"
      },
      "application/vnd.cups-ppd": {
        source: "iana",
        extensions: ["ppd"]
      },
      "application/vnd.cups-raster": {
        source: "iana"
      },
      "application/vnd.cups-raw": {
        source: "iana"
      },
      "application/vnd.curl": {
        source: "iana"
      },
      "application/vnd.curl.car": {
        source: "apache",
        extensions: ["car"]
      },
      "application/vnd.curl.pcurl": {
        source: "apache",
        extensions: ["pcurl"]
      },
      "application/vnd.cyan.dean.root+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.cybank": {
        source: "iana"
      },
      "application/vnd.cyclonedx+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.cyclonedx+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.d2l.coursepackage1p0+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.d3m-dataset": {
        source: "iana"
      },
      "application/vnd.d3m-problem": {
        source: "iana"
      },
      "application/vnd.dart": {
        source: "iana",
        compressible: true,
        extensions: ["dart"]
      },
      "application/vnd.data-vision.rdz": {
        source: "iana",
        extensions: ["rdz"]
      },
      "application/vnd.datapackage+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dataresource+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dbf": {
        source: "iana",
        extensions: ["dbf"]
      },
      "application/vnd.debian.binary-package": {
        source: "iana"
      },
      "application/vnd.dece.data": {
        source: "iana",
        extensions: ["uvf", "uvvf", "uvd", "uvvd"]
      },
      "application/vnd.dece.ttml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["uvt", "uvvt"]
      },
      "application/vnd.dece.unspecified": {
        source: "iana",
        extensions: ["uvx", "uvvx"]
      },
      "application/vnd.dece.zip": {
        source: "iana",
        extensions: ["uvz", "uvvz"]
      },
      "application/vnd.denovo.fcselayout-link": {
        source: "iana",
        extensions: ["fe_launch"]
      },
      "application/vnd.desmume.movie": {
        source: "iana"
      },
      "application/vnd.dir-bi.plate-dl-nosuffix": {
        source: "iana"
      },
      "application/vnd.dm.delegation+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dna": {
        source: "iana",
        extensions: ["dna"]
      },
      "application/vnd.document+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dolby.mlp": {
        source: "apache",
        extensions: ["mlp"]
      },
      "application/vnd.dolby.mobile.1": {
        source: "iana"
      },
      "application/vnd.dolby.mobile.2": {
        source: "iana"
      },
      "application/vnd.doremir.scorecloud-binary-document": {
        source: "iana"
      },
      "application/vnd.dpgraph": {
        source: "iana",
        extensions: ["dpg"]
      },
      "application/vnd.dreamfactory": {
        source: "iana",
        extensions: ["dfac"]
      },
      "application/vnd.drive+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ds-keypoint": {
        source: "apache",
        extensions: ["kpxx"]
      },
      "application/vnd.dtg.local": {
        source: "iana"
      },
      "application/vnd.dtg.local.flash": {
        source: "iana"
      },
      "application/vnd.dtg.local.html": {
        source: "iana"
      },
      "application/vnd.dvb.ait": {
        source: "iana",
        extensions: ["ait"]
      },
      "application/vnd.dvb.dvbisl+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dvb.dvbj": {
        source: "iana"
      },
      "application/vnd.dvb.esgcontainer": {
        source: "iana"
      },
      "application/vnd.dvb.ipdcdftnotifaccess": {
        source: "iana"
      },
      "application/vnd.dvb.ipdcesgaccess": {
        source: "iana"
      },
      "application/vnd.dvb.ipdcesgaccess2": {
        source: "iana"
      },
      "application/vnd.dvb.ipdcesgpdd": {
        source: "iana"
      },
      "application/vnd.dvb.ipdcroaming": {
        source: "iana"
      },
      "application/vnd.dvb.iptv.alfec-base": {
        source: "iana"
      },
      "application/vnd.dvb.iptv.alfec-enhancement": {
        source: "iana"
      },
      "application/vnd.dvb.notif-aggregate-root+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dvb.notif-container+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dvb.notif-generic+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dvb.notif-ia-msglist+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dvb.notif-ia-registration-request+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dvb.notif-ia-registration-response+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dvb.notif-init+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.dvb.pfr": {
        source: "iana"
      },
      "application/vnd.dvb.service": {
        source: "iana",
        extensions: ["svc"]
      },
      "application/vnd.dxr": {
        source: "iana"
      },
      "application/vnd.dynageo": {
        source: "iana",
        extensions: ["geo"]
      },
      "application/vnd.dzr": {
        source: "iana"
      },
      "application/vnd.easykaraoke.cdgdownload": {
        source: "iana"
      },
      "application/vnd.ecdis-update": {
        source: "iana"
      },
      "application/vnd.ecip.rlp": {
        source: "iana"
      },
      "application/vnd.eclipse.ditto+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ecowin.chart": {
        source: "iana",
        extensions: ["mag"]
      },
      "application/vnd.ecowin.filerequest": {
        source: "iana"
      },
      "application/vnd.ecowin.fileupdate": {
        source: "iana"
      },
      "application/vnd.ecowin.series": {
        source: "iana"
      },
      "application/vnd.ecowin.seriesrequest": {
        source: "iana"
      },
      "application/vnd.ecowin.seriesupdate": {
        source: "iana"
      },
      "application/vnd.efi.img": {
        source: "iana"
      },
      "application/vnd.efi.iso": {
        source: "iana"
      },
      "application/vnd.emclient.accessrequest+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.enliven": {
        source: "iana",
        extensions: ["nml"]
      },
      "application/vnd.enphase.envoy": {
        source: "iana"
      },
      "application/vnd.eprints.data+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.epson.esf": {
        source: "iana",
        extensions: ["esf"]
      },
      "application/vnd.epson.msf": {
        source: "iana",
        extensions: ["msf"]
      },
      "application/vnd.epson.quickanime": {
        source: "iana",
        extensions: ["qam"]
      },
      "application/vnd.epson.salt": {
        source: "iana",
        extensions: ["slt"]
      },
      "application/vnd.epson.ssf": {
        source: "iana",
        extensions: ["ssf"]
      },
      "application/vnd.ericsson.quickcall": {
        source: "iana"
      },
      "application/vnd.espass-espass+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.eszigno3+xml": {
        source: "iana",
        compressible: true,
        extensions: ["es3", "et3"]
      },
      "application/vnd.etsi.aoc+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.asic-e+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.etsi.asic-s+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.etsi.cug+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvcommand+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvdiscovery+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvprofile+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvsad-bc+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvsad-cod+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvsad-npvr+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvservice+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvsync+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.iptvueprofile+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.mcid+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.mheg5": {
        source: "iana"
      },
      "application/vnd.etsi.overload-control-policy-dataset+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.pstn+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.sci+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.simservs+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.timestamp-token": {
        source: "iana"
      },
      "application/vnd.etsi.tsl+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.etsi.tsl.der": {
        source: "iana"
      },
      "application/vnd.eu.kasparian.car+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.eudora.data": {
        source: "iana"
      },
      "application/vnd.evolv.ecig.profile": {
        source: "iana"
      },
      "application/vnd.evolv.ecig.settings": {
        source: "iana"
      },
      "application/vnd.evolv.ecig.theme": {
        source: "iana"
      },
      "application/vnd.exstream-empower+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.exstream-package": {
        source: "iana"
      },
      "application/vnd.ezpix-album": {
        source: "iana",
        extensions: ["ez2"]
      },
      "application/vnd.ezpix-package": {
        source: "iana",
        extensions: ["ez3"]
      },
      "application/vnd.f-secure.mobile": {
        source: "iana"
      },
      "application/vnd.familysearch.gedcom+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.fastcopy-disk-image": {
        source: "iana"
      },
      "application/vnd.fdf": {
        source: "iana",
        extensions: ["fdf"]
      },
      "application/vnd.fdsn.mseed": {
        source: "iana",
        extensions: ["mseed"]
      },
      "application/vnd.fdsn.seed": {
        source: "iana",
        extensions: ["seed", "dataless"]
      },
      "application/vnd.ffsns": {
        source: "iana"
      },
      "application/vnd.ficlab.flb+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.filmit.zfc": {
        source: "iana"
      },
      "application/vnd.fints": {
        source: "iana"
      },
      "application/vnd.firemonkeys.cloudcell": {
        source: "iana"
      },
      "application/vnd.flographit": {
        source: "iana",
        extensions: ["gph"]
      },
      "application/vnd.fluxtime.clip": {
        source: "iana",
        extensions: ["ftc"]
      },
      "application/vnd.font-fontforge-sfd": {
        source: "iana"
      },
      "application/vnd.framemaker": {
        source: "iana",
        extensions: ["fm", "frame", "maker", "book"]
      },
      "application/vnd.frogans.fnc": {
        source: "iana",
        extensions: ["fnc"]
      },
      "application/vnd.frogans.ltf": {
        source: "iana",
        extensions: ["ltf"]
      },
      "application/vnd.fsc.weblaunch": {
        source: "iana",
        extensions: ["fsc"]
      },
      "application/vnd.fujifilm.fb.docuworks": {
        source: "iana"
      },
      "application/vnd.fujifilm.fb.docuworks.binder": {
        source: "iana"
      },
      "application/vnd.fujifilm.fb.docuworks.container": {
        source: "iana"
      },
      "application/vnd.fujifilm.fb.jfi+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.fujitsu.oasys": {
        source: "iana",
        extensions: ["oas"]
      },
      "application/vnd.fujitsu.oasys2": {
        source: "iana",
        extensions: ["oa2"]
      },
      "application/vnd.fujitsu.oasys3": {
        source: "iana",
        extensions: ["oa3"]
      },
      "application/vnd.fujitsu.oasysgp": {
        source: "iana",
        extensions: ["fg5"]
      },
      "application/vnd.fujitsu.oasysprs": {
        source: "iana",
        extensions: ["bh2"]
      },
      "application/vnd.fujixerox.art-ex": {
        source: "iana"
      },
      "application/vnd.fujixerox.art4": {
        source: "iana"
      },
      "application/vnd.fujixerox.ddd": {
        source: "iana",
        extensions: ["ddd"]
      },
      "application/vnd.fujixerox.docuworks": {
        source: "iana",
        extensions: ["xdw"]
      },
      "application/vnd.fujixerox.docuworks.binder": {
        source: "iana",
        extensions: ["xbd"]
      },
      "application/vnd.fujixerox.docuworks.container": {
        source: "iana"
      },
      "application/vnd.fujixerox.hbpl": {
        source: "iana"
      },
      "application/vnd.fut-misnet": {
        source: "iana"
      },
      "application/vnd.futoin+cbor": {
        source: "iana"
      },
      "application/vnd.futoin+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.fuzzysheet": {
        source: "iana",
        extensions: ["fzs"]
      },
      "application/vnd.genomatix.tuxedo": {
        source: "iana",
        extensions: ["txd"]
      },
      "application/vnd.gentics.grd+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.geo+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.geocube+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.geogebra.file": {
        source: "iana",
        extensions: ["ggb"]
      },
      "application/vnd.geogebra.slides": {
        source: "iana"
      },
      "application/vnd.geogebra.tool": {
        source: "iana",
        extensions: ["ggt"]
      },
      "application/vnd.geometry-explorer": {
        source: "iana",
        extensions: ["gex", "gre"]
      },
      "application/vnd.geonext": {
        source: "iana",
        extensions: ["gxt"]
      },
      "application/vnd.geoplan": {
        source: "iana",
        extensions: ["g2w"]
      },
      "application/vnd.geospace": {
        source: "iana",
        extensions: ["g3w"]
      },
      "application/vnd.gerber": {
        source: "iana"
      },
      "application/vnd.globalplatform.card-content-mgt": {
        source: "iana"
      },
      "application/vnd.globalplatform.card-content-mgt-response": {
        source: "iana"
      },
      "application/vnd.gmx": {
        source: "iana",
        extensions: ["gmx"]
      },
      "application/vnd.google-apps.document": {
        compressible: false,
        extensions: ["gdoc"]
      },
      "application/vnd.google-apps.presentation": {
        compressible: false,
        extensions: ["gslides"]
      },
      "application/vnd.google-apps.spreadsheet": {
        compressible: false,
        extensions: ["gsheet"]
      },
      "application/vnd.google-earth.kml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["kml"]
      },
      "application/vnd.google-earth.kmz": {
        source: "iana",
        compressible: false,
        extensions: ["kmz"]
      },
      "application/vnd.gov.sk.e-form+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.gov.sk.e-form+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.gov.sk.xmldatacontainer+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.grafeq": {
        source: "iana",
        extensions: ["gqf", "gqs"]
      },
      "application/vnd.gridmp": {
        source: "iana"
      },
      "application/vnd.groove-account": {
        source: "iana",
        extensions: ["gac"]
      },
      "application/vnd.groove-help": {
        source: "iana",
        extensions: ["ghf"]
      },
      "application/vnd.groove-identity-message": {
        source: "iana",
        extensions: ["gim"]
      },
      "application/vnd.groove-injector": {
        source: "iana",
        extensions: ["grv"]
      },
      "application/vnd.groove-tool-message": {
        source: "iana",
        extensions: ["gtm"]
      },
      "application/vnd.groove-tool-template": {
        source: "iana",
        extensions: ["tpl"]
      },
      "application/vnd.groove-vcard": {
        source: "iana",
        extensions: ["vcg"]
      },
      "application/vnd.hal+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.hal+xml": {
        source: "iana",
        compressible: true,
        extensions: ["hal"]
      },
      "application/vnd.handheld-entertainment+xml": {
        source: "iana",
        compressible: true,
        extensions: ["zmm"]
      },
      "application/vnd.hbci": {
        source: "iana",
        extensions: ["hbci"]
      },
      "application/vnd.hc+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.hcl-bireports": {
        source: "iana"
      },
      "application/vnd.hdt": {
        source: "iana"
      },
      "application/vnd.heroku+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.hhe.lesson-player": {
        source: "iana",
        extensions: ["les"]
      },
      "application/vnd.hl7cda+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/vnd.hl7v2+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/vnd.hp-hpgl": {
        source: "iana",
        extensions: ["hpgl"]
      },
      "application/vnd.hp-hpid": {
        source: "iana",
        extensions: ["hpid"]
      },
      "application/vnd.hp-hps": {
        source: "iana",
        extensions: ["hps"]
      },
      "application/vnd.hp-jlyt": {
        source: "iana",
        extensions: ["jlt"]
      },
      "application/vnd.hp-pcl": {
        source: "iana",
        extensions: ["pcl"]
      },
      "application/vnd.hp-pclxl": {
        source: "iana",
        extensions: ["pclxl"]
      },
      "application/vnd.httphone": {
        source: "iana"
      },
      "application/vnd.hydrostatix.sof-data": {
        source: "iana",
        extensions: ["sfd-hdstx"]
      },
      "application/vnd.hyper+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.hyper-item+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.hyperdrive+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.hzn-3d-crossword": {
        source: "iana"
      },
      "application/vnd.ibm.afplinedata": {
        source: "iana"
      },
      "application/vnd.ibm.electronic-media": {
        source: "iana"
      },
      "application/vnd.ibm.minipay": {
        source: "iana",
        extensions: ["mpy"]
      },
      "application/vnd.ibm.modcap": {
        source: "iana",
        extensions: ["afp", "listafp", "list3820"]
      },
      "application/vnd.ibm.rights-management": {
        source: "iana",
        extensions: ["irm"]
      },
      "application/vnd.ibm.secure-container": {
        source: "iana",
        extensions: ["sc"]
      },
      "application/vnd.iccprofile": {
        source: "iana",
        extensions: ["icc", "icm"]
      },
      "application/vnd.ieee.1905": {
        source: "iana"
      },
      "application/vnd.igloader": {
        source: "iana",
        extensions: ["igl"]
      },
      "application/vnd.imagemeter.folder+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.imagemeter.image+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.immervision-ivp": {
        source: "iana",
        extensions: ["ivp"]
      },
      "application/vnd.immervision-ivu": {
        source: "iana",
        extensions: ["ivu"]
      },
      "application/vnd.ims.imsccv1p1": {
        source: "iana"
      },
      "application/vnd.ims.imsccv1p2": {
        source: "iana"
      },
      "application/vnd.ims.imsccv1p3": {
        source: "iana"
      },
      "application/vnd.ims.lis.v2.result+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ims.lti.v2.toolconsumerprofile+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ims.lti.v2.toolproxy+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ims.lti.v2.toolproxy.id+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ims.lti.v2.toolsettings+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ims.lti.v2.toolsettings.simple+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.informedcontrol.rms+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.informix-visionary": {
        source: "iana"
      },
      "application/vnd.infotech.project": {
        source: "iana"
      },
      "application/vnd.infotech.project+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.innopath.wamp.notification": {
        source: "iana"
      },
      "application/vnd.insors.igm": {
        source: "iana",
        extensions: ["igm"]
      },
      "application/vnd.intercon.formnet": {
        source: "iana",
        extensions: ["xpw", "xpx"]
      },
      "application/vnd.intergeo": {
        source: "iana",
        extensions: ["i2g"]
      },
      "application/vnd.intertrust.digibox": {
        source: "iana"
      },
      "application/vnd.intertrust.nncp": {
        source: "iana"
      },
      "application/vnd.intu.qbo": {
        source: "iana",
        extensions: ["qbo"]
      },
      "application/vnd.intu.qfx": {
        source: "iana",
        extensions: ["qfx"]
      },
      "application/vnd.iptc.g2.catalogitem+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.iptc.g2.conceptitem+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.iptc.g2.knowledgeitem+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.iptc.g2.newsitem+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.iptc.g2.newsmessage+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.iptc.g2.packageitem+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.iptc.g2.planningitem+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ipunplugged.rcprofile": {
        source: "iana",
        extensions: ["rcprofile"]
      },
      "application/vnd.irepository.package+xml": {
        source: "iana",
        compressible: true,
        extensions: ["irp"]
      },
      "application/vnd.is-xpr": {
        source: "iana",
        extensions: ["xpr"]
      },
      "application/vnd.isac.fcs": {
        source: "iana",
        extensions: ["fcs"]
      },
      "application/vnd.iso11783-10+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.jam": {
        source: "iana",
        extensions: ["jam"]
      },
      "application/vnd.japannet-directory-service": {
        source: "iana"
      },
      "application/vnd.japannet-jpnstore-wakeup": {
        source: "iana"
      },
      "application/vnd.japannet-payment-wakeup": {
        source: "iana"
      },
      "application/vnd.japannet-registration": {
        source: "iana"
      },
      "application/vnd.japannet-registration-wakeup": {
        source: "iana"
      },
      "application/vnd.japannet-setstore-wakeup": {
        source: "iana"
      },
      "application/vnd.japannet-verification": {
        source: "iana"
      },
      "application/vnd.japannet-verification-wakeup": {
        source: "iana"
      },
      "application/vnd.jcp.javame.midlet-rms": {
        source: "iana",
        extensions: ["rms"]
      },
      "application/vnd.jisp": {
        source: "iana",
        extensions: ["jisp"]
      },
      "application/vnd.joost.joda-archive": {
        source: "iana",
        extensions: ["joda"]
      },
      "application/vnd.jsk.isdn-ngn": {
        source: "iana"
      },
      "application/vnd.kahootz": {
        source: "iana",
        extensions: ["ktz", "ktr"]
      },
      "application/vnd.kde.karbon": {
        source: "iana",
        extensions: ["karbon"]
      },
      "application/vnd.kde.kchart": {
        source: "iana",
        extensions: ["chrt"]
      },
      "application/vnd.kde.kformula": {
        source: "iana",
        extensions: ["kfo"]
      },
      "application/vnd.kde.kivio": {
        source: "iana",
        extensions: ["flw"]
      },
      "application/vnd.kde.kontour": {
        source: "iana",
        extensions: ["kon"]
      },
      "application/vnd.kde.kpresenter": {
        source: "iana",
        extensions: ["kpr", "kpt"]
      },
      "application/vnd.kde.kspread": {
        source: "iana",
        extensions: ["ksp"]
      },
      "application/vnd.kde.kword": {
        source: "iana",
        extensions: ["kwd", "kwt"]
      },
      "application/vnd.kenameaapp": {
        source: "iana",
        extensions: ["htke"]
      },
      "application/vnd.kidspiration": {
        source: "iana",
        extensions: ["kia"]
      },
      "application/vnd.kinar": {
        source: "iana",
        extensions: ["kne", "knp"]
      },
      "application/vnd.koan": {
        source: "iana",
        extensions: ["skp", "skd", "skt", "skm"]
      },
      "application/vnd.kodak-descriptor": {
        source: "iana",
        extensions: ["sse"]
      },
      "application/vnd.las": {
        source: "iana"
      },
      "application/vnd.las.las+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.las.las+xml": {
        source: "iana",
        compressible: true,
        extensions: ["lasxml"]
      },
      "application/vnd.laszip": {
        source: "iana"
      },
      "application/vnd.leap+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.liberty-request+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.llamagraphics.life-balance.desktop": {
        source: "iana",
        extensions: ["lbd"]
      },
      "application/vnd.llamagraphics.life-balance.exchange+xml": {
        source: "iana",
        compressible: true,
        extensions: ["lbe"]
      },
      "application/vnd.logipipe.circuit+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.loom": {
        source: "iana"
      },
      "application/vnd.lotus-1-2-3": {
        source: "iana",
        extensions: ["123"]
      },
      "application/vnd.lotus-approach": {
        source: "iana",
        extensions: ["apr"]
      },
      "application/vnd.lotus-freelance": {
        source: "iana",
        extensions: ["pre"]
      },
      "application/vnd.lotus-notes": {
        source: "iana",
        extensions: ["nsf"]
      },
      "application/vnd.lotus-organizer": {
        source: "iana",
        extensions: ["org"]
      },
      "application/vnd.lotus-screencam": {
        source: "iana",
        extensions: ["scm"]
      },
      "application/vnd.lotus-wordpro": {
        source: "iana",
        extensions: ["lwp"]
      },
      "application/vnd.macports.portpkg": {
        source: "iana",
        extensions: ["portpkg"]
      },
      "application/vnd.mapbox-vector-tile": {
        source: "iana",
        extensions: ["mvt"]
      },
      "application/vnd.marlin.drm.actiontoken+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.marlin.drm.conftoken+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.marlin.drm.license+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.marlin.drm.mdcf": {
        source: "iana"
      },
      "application/vnd.mason+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.maxar.archive.3tz+zip": {
        source: "iana",
        compressible: false
      },
      "application/vnd.maxmind.maxmind-db": {
        source: "iana"
      },
      "application/vnd.mcd": {
        source: "iana",
        extensions: ["mcd"]
      },
      "application/vnd.medcalcdata": {
        source: "iana",
        extensions: ["mc1"]
      },
      "application/vnd.mediastation.cdkey": {
        source: "iana",
        extensions: ["cdkey"]
      },
      "application/vnd.meridian-slingshot": {
        source: "iana"
      },
      "application/vnd.mfer": {
        source: "iana",
        extensions: ["mwf"]
      },
      "application/vnd.mfmp": {
        source: "iana",
        extensions: ["mfm"]
      },
      "application/vnd.micro+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.micrografx.flo": {
        source: "iana",
        extensions: ["flo"]
      },
      "application/vnd.micrografx.igx": {
        source: "iana",
        extensions: ["igx"]
      },
      "application/vnd.microsoft.portable-executable": {
        source: "iana"
      },
      "application/vnd.microsoft.windows.thumbnail-cache": {
        source: "iana"
      },
      "application/vnd.miele+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.mif": {
        source: "iana",
        extensions: ["mif"]
      },
      "application/vnd.minisoft-hp3000-save": {
        source: "iana"
      },
      "application/vnd.mitsubishi.misty-guard.trustweb": {
        source: "iana"
      },
      "application/vnd.mobius.daf": {
        source: "iana",
        extensions: ["daf"]
      },
      "application/vnd.mobius.dis": {
        source: "iana",
        extensions: ["dis"]
      },
      "application/vnd.mobius.mbk": {
        source: "iana",
        extensions: ["mbk"]
      },
      "application/vnd.mobius.mqy": {
        source: "iana",
        extensions: ["mqy"]
      },
      "application/vnd.mobius.msl": {
        source: "iana",
        extensions: ["msl"]
      },
      "application/vnd.mobius.plc": {
        source: "iana",
        extensions: ["plc"]
      },
      "application/vnd.mobius.txf": {
        source: "iana",
        extensions: ["txf"]
      },
      "application/vnd.mophun.application": {
        source: "iana",
        extensions: ["mpn"]
      },
      "application/vnd.mophun.certificate": {
        source: "iana",
        extensions: ["mpc"]
      },
      "application/vnd.motorola.flexsuite": {
        source: "iana"
      },
      "application/vnd.motorola.flexsuite.adsi": {
        source: "iana"
      },
      "application/vnd.motorola.flexsuite.fis": {
        source: "iana"
      },
      "application/vnd.motorola.flexsuite.gotap": {
        source: "iana"
      },
      "application/vnd.motorola.flexsuite.kmr": {
        source: "iana"
      },
      "application/vnd.motorola.flexsuite.ttc": {
        source: "iana"
      },
      "application/vnd.motorola.flexsuite.wem": {
        source: "iana"
      },
      "application/vnd.motorola.iprm": {
        source: "iana"
      },
      "application/vnd.mozilla.xul+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xul"]
      },
      "application/vnd.ms-3mfdocument": {
        source: "iana"
      },
      "application/vnd.ms-artgalry": {
        source: "iana",
        extensions: ["cil"]
      },
      "application/vnd.ms-asf": {
        source: "iana"
      },
      "application/vnd.ms-cab-compressed": {
        source: "iana",
        extensions: ["cab"]
      },
      "application/vnd.ms-color.iccprofile": {
        source: "apache"
      },
      "application/vnd.ms-excel": {
        source: "iana",
        compressible: false,
        extensions: ["xls", "xlm", "xla", "xlc", "xlt", "xlw"]
      },
      "application/vnd.ms-excel.addin.macroenabled.12": {
        source: "iana",
        extensions: ["xlam"]
      },
      "application/vnd.ms-excel.sheet.binary.macroenabled.12": {
        source: "iana",
        extensions: ["xlsb"]
      },
      "application/vnd.ms-excel.sheet.macroenabled.12": {
        source: "iana",
        extensions: ["xlsm"]
      },
      "application/vnd.ms-excel.template.macroenabled.12": {
        source: "iana",
        extensions: ["xltm"]
      },
      "application/vnd.ms-fontobject": {
        source: "iana",
        compressible: true,
        extensions: ["eot"]
      },
      "application/vnd.ms-htmlhelp": {
        source: "iana",
        extensions: ["chm"]
      },
      "application/vnd.ms-ims": {
        source: "iana",
        extensions: ["ims"]
      },
      "application/vnd.ms-lrm": {
        source: "iana",
        extensions: ["lrm"]
      },
      "application/vnd.ms-office.activex+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ms-officetheme": {
        source: "iana",
        extensions: ["thmx"]
      },
      "application/vnd.ms-opentype": {
        source: "apache",
        compressible: true
      },
      "application/vnd.ms-outlook": {
        compressible: false,
        extensions: ["msg"]
      },
      "application/vnd.ms-package.obfuscated-opentype": {
        source: "apache"
      },
      "application/vnd.ms-pki.seccat": {
        source: "apache",
        extensions: ["cat"]
      },
      "application/vnd.ms-pki.stl": {
        source: "apache",
        extensions: ["stl"]
      },
      "application/vnd.ms-playready.initiator+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ms-powerpoint": {
        source: "iana",
        compressible: false,
        extensions: ["ppt", "pps", "pot"]
      },
      "application/vnd.ms-powerpoint.addin.macroenabled.12": {
        source: "iana",
        extensions: ["ppam"]
      },
      "application/vnd.ms-powerpoint.presentation.macroenabled.12": {
        source: "iana",
        extensions: ["pptm"]
      },
      "application/vnd.ms-powerpoint.slide.macroenabled.12": {
        source: "iana",
        extensions: ["sldm"]
      },
      "application/vnd.ms-powerpoint.slideshow.macroenabled.12": {
        source: "iana",
        extensions: ["ppsm"]
      },
      "application/vnd.ms-powerpoint.template.macroenabled.12": {
        source: "iana",
        extensions: ["potm"]
      },
      "application/vnd.ms-printdevicecapabilities+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ms-printing.printticket+xml": {
        source: "apache",
        compressible: true
      },
      "application/vnd.ms-printschematicket+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ms-project": {
        source: "iana",
        extensions: ["mpp", "mpt"]
      },
      "application/vnd.ms-tnef": {
        source: "iana"
      },
      "application/vnd.ms-windows.devicepairing": {
        source: "iana"
      },
      "application/vnd.ms-windows.nwprinting.oob": {
        source: "iana"
      },
      "application/vnd.ms-windows.printerpairing": {
        source: "iana"
      },
      "application/vnd.ms-windows.wsd.oob": {
        source: "iana"
      },
      "application/vnd.ms-wmdrm.lic-chlg-req": {
        source: "iana"
      },
      "application/vnd.ms-wmdrm.lic-resp": {
        source: "iana"
      },
      "application/vnd.ms-wmdrm.meter-chlg-req": {
        source: "iana"
      },
      "application/vnd.ms-wmdrm.meter-resp": {
        source: "iana"
      },
      "application/vnd.ms-word.document.macroenabled.12": {
        source: "iana",
        extensions: ["docm"]
      },
      "application/vnd.ms-word.template.macroenabled.12": {
        source: "iana",
        extensions: ["dotm"]
      },
      "application/vnd.ms-works": {
        source: "iana",
        extensions: ["wps", "wks", "wcm", "wdb"]
      },
      "application/vnd.ms-wpl": {
        source: "iana",
        extensions: ["wpl"]
      },
      "application/vnd.ms-xpsdocument": {
        source: "iana",
        compressible: false,
        extensions: ["xps"]
      },
      "application/vnd.msa-disk-image": {
        source: "iana"
      },
      "application/vnd.mseq": {
        source: "iana",
        extensions: ["mseq"]
      },
      "application/vnd.msign": {
        source: "iana"
      },
      "application/vnd.multiad.creator": {
        source: "iana"
      },
      "application/vnd.multiad.creator.cif": {
        source: "iana"
      },
      "application/vnd.music-niff": {
        source: "iana"
      },
      "application/vnd.musician": {
        source: "iana",
        extensions: ["mus"]
      },
      "application/vnd.muvee.style": {
        source: "iana",
        extensions: ["msty"]
      },
      "application/vnd.mynfc": {
        source: "iana",
        extensions: ["taglet"]
      },
      "application/vnd.nacamar.ybrid+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.ncd.control": {
        source: "iana"
      },
      "application/vnd.ncd.reference": {
        source: "iana"
      },
      "application/vnd.nearst.inv+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.nebumind.line": {
        source: "iana"
      },
      "application/vnd.nervana": {
        source: "iana"
      },
      "application/vnd.netfpx": {
        source: "iana"
      },
      "application/vnd.neurolanguage.nlu": {
        source: "iana",
        extensions: ["nlu"]
      },
      "application/vnd.nimn": {
        source: "iana"
      },
      "application/vnd.nintendo.nitro.rom": {
        source: "iana"
      },
      "application/vnd.nintendo.snes.rom": {
        source: "iana"
      },
      "application/vnd.nitf": {
        source: "iana",
        extensions: ["ntf", "nitf"]
      },
      "application/vnd.noblenet-directory": {
        source: "iana",
        extensions: ["nnd"]
      },
      "application/vnd.noblenet-sealer": {
        source: "iana",
        extensions: ["nns"]
      },
      "application/vnd.noblenet-web": {
        source: "iana",
        extensions: ["nnw"]
      },
      "application/vnd.nokia.catalogs": {
        source: "iana"
      },
      "application/vnd.nokia.conml+wbxml": {
        source: "iana"
      },
      "application/vnd.nokia.conml+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.nokia.iptv.config+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.nokia.isds-radio-presets": {
        source: "iana"
      },
      "application/vnd.nokia.landmark+wbxml": {
        source: "iana"
      },
      "application/vnd.nokia.landmark+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.nokia.landmarkcollection+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.nokia.n-gage.ac+xml": {
        source: "iana",
        compressible: true,
        extensions: ["ac"]
      },
      "application/vnd.nokia.n-gage.data": {
        source: "iana",
        extensions: ["ngdat"]
      },
      "application/vnd.nokia.n-gage.symbian.install": {
        source: "iana",
        extensions: ["n-gage"]
      },
      "application/vnd.nokia.ncd": {
        source: "iana"
      },
      "application/vnd.nokia.pcd+wbxml": {
        source: "iana"
      },
      "application/vnd.nokia.pcd+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.nokia.radio-preset": {
        source: "iana",
        extensions: ["rpst"]
      },
      "application/vnd.nokia.radio-presets": {
        source: "iana",
        extensions: ["rpss"]
      },
      "application/vnd.novadigm.edm": {
        source: "iana",
        extensions: ["edm"]
      },
      "application/vnd.novadigm.edx": {
        source: "iana",
        extensions: ["edx"]
      },
      "application/vnd.novadigm.ext": {
        source: "iana",
        extensions: ["ext"]
      },
      "application/vnd.ntt-local.content-share": {
        source: "iana"
      },
      "application/vnd.ntt-local.file-transfer": {
        source: "iana"
      },
      "application/vnd.ntt-local.ogw_remote-access": {
        source: "iana"
      },
      "application/vnd.ntt-local.sip-ta_remote": {
        source: "iana"
      },
      "application/vnd.ntt-local.sip-ta_tcp_stream": {
        source: "iana"
      },
      "application/vnd.oasis.opendocument.chart": {
        source: "iana",
        extensions: ["odc"]
      },
      "application/vnd.oasis.opendocument.chart-template": {
        source: "iana",
        extensions: ["otc"]
      },
      "application/vnd.oasis.opendocument.database": {
        source: "iana",
        extensions: ["odb"]
      },
      "application/vnd.oasis.opendocument.formula": {
        source: "iana",
        extensions: ["odf"]
      },
      "application/vnd.oasis.opendocument.formula-template": {
        source: "iana",
        extensions: ["odft"]
      },
      "application/vnd.oasis.opendocument.graphics": {
        source: "iana",
        compressible: false,
        extensions: ["odg"]
      },
      "application/vnd.oasis.opendocument.graphics-template": {
        source: "iana",
        extensions: ["otg"]
      },
      "application/vnd.oasis.opendocument.image": {
        source: "iana",
        extensions: ["odi"]
      },
      "application/vnd.oasis.opendocument.image-template": {
        source: "iana",
        extensions: ["oti"]
      },
      "application/vnd.oasis.opendocument.presentation": {
        source: "iana",
        compressible: false,
        extensions: ["odp"]
      },
      "application/vnd.oasis.opendocument.presentation-template": {
        source: "iana",
        extensions: ["otp"]
      },
      "application/vnd.oasis.opendocument.spreadsheet": {
        source: "iana",
        compressible: false,
        extensions: ["ods"]
      },
      "application/vnd.oasis.opendocument.spreadsheet-template": {
        source: "iana",
        extensions: ["ots"]
      },
      "application/vnd.oasis.opendocument.text": {
        source: "iana",
        compressible: false,
        extensions: ["odt"]
      },
      "application/vnd.oasis.opendocument.text-master": {
        source: "iana",
        extensions: ["odm"]
      },
      "application/vnd.oasis.opendocument.text-template": {
        source: "iana",
        extensions: ["ott"]
      },
      "application/vnd.oasis.opendocument.text-web": {
        source: "iana",
        extensions: ["oth"]
      },
      "application/vnd.obn": {
        source: "iana"
      },
      "application/vnd.ocf+cbor": {
        source: "iana"
      },
      "application/vnd.oci.image.manifest.v1+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oftn.l10n+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.contentaccessdownload+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.contentaccessstreaming+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.cspg-hexbinary": {
        source: "iana"
      },
      "application/vnd.oipf.dae.svg+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.dae.xhtml+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.mippvcontrolmessage+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.pae.gem": {
        source: "iana"
      },
      "application/vnd.oipf.spdiscovery+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.spdlist+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.ueprofile+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oipf.userprofile+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.olpc-sugar": {
        source: "iana",
        extensions: ["xo"]
      },
      "application/vnd.oma-scws-config": {
        source: "iana"
      },
      "application/vnd.oma-scws-http-request": {
        source: "iana"
      },
      "application/vnd.oma-scws-http-response": {
        source: "iana"
      },
      "application/vnd.oma.bcast.associated-procedure-parameter+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.bcast.drm-trigger+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.bcast.imd+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.bcast.ltkm": {
        source: "iana"
      },
      "application/vnd.oma.bcast.notification+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.bcast.provisioningtrigger": {
        source: "iana"
      },
      "application/vnd.oma.bcast.sgboot": {
        source: "iana"
      },
      "application/vnd.oma.bcast.sgdd+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.bcast.sgdu": {
        source: "iana"
      },
      "application/vnd.oma.bcast.simple-symbol-container": {
        source: "iana"
      },
      "application/vnd.oma.bcast.smartcard-trigger+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.bcast.sprov+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.bcast.stkm": {
        source: "iana"
      },
      "application/vnd.oma.cab-address-book+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.cab-feature-handler+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.cab-pcc+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.cab-subs-invite+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.cab-user-prefs+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.dcd": {
        source: "iana"
      },
      "application/vnd.oma.dcdc": {
        source: "iana"
      },
      "application/vnd.oma.dd2+xml": {
        source: "iana",
        compressible: true,
        extensions: ["dd2"]
      },
      "application/vnd.oma.drm.risd+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.group-usage-list+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.lwm2m+cbor": {
        source: "iana"
      },
      "application/vnd.oma.lwm2m+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.lwm2m+tlv": {
        source: "iana"
      },
      "application/vnd.oma.pal+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.poc.detailed-progress-report+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.poc.final-report+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.poc.groups+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.poc.invocation-descriptor+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.poc.optimized-progress-report+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.push": {
        source: "iana"
      },
      "application/vnd.oma.scidm.messages+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oma.xcap-directory+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.omads-email+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/vnd.omads-file+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/vnd.omads-folder+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/vnd.omaloc-supl-init": {
        source: "iana"
      },
      "application/vnd.onepager": {
        source: "iana"
      },
      "application/vnd.onepagertamp": {
        source: "iana"
      },
      "application/vnd.onepagertamx": {
        source: "iana"
      },
      "application/vnd.onepagertat": {
        source: "iana"
      },
      "application/vnd.onepagertatp": {
        source: "iana"
      },
      "application/vnd.onepagertatx": {
        source: "iana"
      },
      "application/vnd.openblox.game+xml": {
        source: "iana",
        compressible: true,
        extensions: ["obgx"]
      },
      "application/vnd.openblox.game-binary": {
        source: "iana"
      },
      "application/vnd.openeye.oeb": {
        source: "iana"
      },
      "application/vnd.openofficeorg.extension": {
        source: "apache",
        extensions: ["oxt"]
      },
      "application/vnd.openstreetmap.data+xml": {
        source: "iana",
        compressible: true,
        extensions: ["osm"]
      },
      "application/vnd.opentimestamps.ots": {
        source: "iana"
      },
      "application/vnd.openxmlformats-officedocument.custom-properties+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.customxmlproperties+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.drawing+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.drawingml.chart+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.drawingml.chartshapes+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.drawingml.diagramcolors+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.drawingml.diagramdata+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.drawingml.diagramlayout+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.drawingml.diagramstyle+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.extended-properties+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.commentauthors+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.comments+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.handoutmaster+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.notesmaster+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.notesslide+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.presentation": {
        source: "iana",
        compressible: false,
        extensions: ["pptx"]
      },
      "application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.presprops+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.slide": {
        source: "iana",
        extensions: ["sldx"]
      },
      "application/vnd.openxmlformats-officedocument.presentationml.slide+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.slidelayout+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.slidemaster+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.slideshow": {
        source: "iana",
        extensions: ["ppsx"]
      },
      "application/vnd.openxmlformats-officedocument.presentationml.slideshow.main+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.slideupdateinfo+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.tablestyles+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.tags+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.template": {
        source: "iana",
        extensions: ["potx"]
      },
      "application/vnd.openxmlformats-officedocument.presentationml.template.main+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.presentationml.viewprops+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.calcchain+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.chartsheet+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.connections+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.dialogsheet+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.externallink+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotcachedefinition+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotcacherecords+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.pivottable+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.querytable+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.revisionheaders+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.revisionlog+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedstrings+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": {
        source: "iana",
        compressible: false,
        extensions: ["xlsx"]
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheetmetadata+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.tablesinglecells+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.template": {
        source: "iana",
        extensions: ["xltx"]
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.template.main+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.usernames+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.volatiledependencies+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.theme+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.themeoverride+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.vmldrawing": {
        source: "iana"
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document": {
        source: "iana",
        compressible: false,
        extensions: ["docx"]
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document.glossary+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.endnotes+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.fonttable+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.template": {
        source: "iana",
        extensions: ["dotx"]
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-officedocument.wordprocessingml.websettings+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-package.core-properties+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-package.digital-signature-xmlsignature+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.openxmlformats-package.relationships+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oracle.resource+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.orange.indata": {
        source: "iana"
      },
      "application/vnd.osa.netdeploy": {
        source: "iana"
      },
      "application/vnd.osgeo.mapguide.package": {
        source: "iana",
        extensions: ["mgp"]
      },
      "application/vnd.osgi.bundle": {
        source: "iana"
      },
      "application/vnd.osgi.dp": {
        source: "iana",
        extensions: ["dp"]
      },
      "application/vnd.osgi.subsystem": {
        source: "iana",
        extensions: ["esa"]
      },
      "application/vnd.otps.ct-kip+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.oxli.countgraph": {
        source: "iana"
      },
      "application/vnd.pagerduty+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.palm": {
        source: "iana",
        extensions: ["pdb", "pqa", "oprc"]
      },
      "application/vnd.panoply": {
        source: "iana"
      },
      "application/vnd.paos.xml": {
        source: "iana"
      },
      "application/vnd.patentdive": {
        source: "iana"
      },
      "application/vnd.patientecommsdoc": {
        source: "iana"
      },
      "application/vnd.pawaafile": {
        source: "iana",
        extensions: ["paw"]
      },
      "application/vnd.pcos": {
        source: "iana"
      },
      "application/vnd.pg.format": {
        source: "iana",
        extensions: ["str"]
      },
      "application/vnd.pg.osasli": {
        source: "iana",
        extensions: ["ei6"]
      },
      "application/vnd.piaccess.application-licence": {
        source: "iana"
      },
      "application/vnd.picsel": {
        source: "iana",
        extensions: ["efif"]
      },
      "application/vnd.pmi.widget": {
        source: "iana",
        extensions: ["wg"]
      },
      "application/vnd.poc.group-advertisement+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.pocketlearn": {
        source: "iana",
        extensions: ["plf"]
      },
      "application/vnd.powerbuilder6": {
        source: "iana",
        extensions: ["pbd"]
      },
      "application/vnd.powerbuilder6-s": {
        source: "iana"
      },
      "application/vnd.powerbuilder7": {
        source: "iana"
      },
      "application/vnd.powerbuilder7-s": {
        source: "iana"
      },
      "application/vnd.powerbuilder75": {
        source: "iana"
      },
      "application/vnd.powerbuilder75-s": {
        source: "iana"
      },
      "application/vnd.preminet": {
        source: "iana"
      },
      "application/vnd.previewsystems.box": {
        source: "iana",
        extensions: ["box"]
      },
      "application/vnd.proteus.magazine": {
        source: "iana",
        extensions: ["mgz"]
      },
      "application/vnd.psfs": {
        source: "iana"
      },
      "application/vnd.publishare-delta-tree": {
        source: "iana",
        extensions: ["qps"]
      },
      "application/vnd.pvi.ptid1": {
        source: "iana",
        extensions: ["ptid"]
      },
      "application/vnd.pwg-multiplexed": {
        source: "iana"
      },
      "application/vnd.pwg-xhtml-print+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.qualcomm.brew-app-res": {
        source: "iana"
      },
      "application/vnd.quarantainenet": {
        source: "iana"
      },
      "application/vnd.quark.quarkxpress": {
        source: "iana",
        extensions: ["qxd", "qxt", "qwd", "qwt", "qxl", "qxb"]
      },
      "application/vnd.quobject-quoxdocument": {
        source: "iana"
      },
      "application/vnd.radisys.moml+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-audit+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-audit-conf+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-audit-conn+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-audit-dialog+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-audit-stream+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-conf+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-dialog+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-dialog-base+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-dialog-fax-detect+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-dialog-fax-sendrecv+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-dialog-group+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-dialog-speech+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.radisys.msml-dialog-transform+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.rainstor.data": {
        source: "iana"
      },
      "application/vnd.rapid": {
        source: "iana"
      },
      "application/vnd.rar": {
        source: "iana",
        extensions: ["rar"]
      },
      "application/vnd.realvnc.bed": {
        source: "iana",
        extensions: ["bed"]
      },
      "application/vnd.recordare.musicxml": {
        source: "iana",
        extensions: ["mxl"]
      },
      "application/vnd.recordare.musicxml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["musicxml"]
      },
      "application/vnd.renlearn.rlprint": {
        source: "iana"
      },
      "application/vnd.resilient.logic": {
        source: "iana"
      },
      "application/vnd.restful+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.rig.cryptonote": {
        source: "iana",
        extensions: ["cryptonote"]
      },
      "application/vnd.rim.cod": {
        source: "apache",
        extensions: ["cod"]
      },
      "application/vnd.rn-realmedia": {
        source: "apache",
        extensions: ["rm"]
      },
      "application/vnd.rn-realmedia-vbr": {
        source: "apache",
        extensions: ["rmvb"]
      },
      "application/vnd.route66.link66+xml": {
        source: "iana",
        compressible: true,
        extensions: ["link66"]
      },
      "application/vnd.rs-274x": {
        source: "iana"
      },
      "application/vnd.ruckus.download": {
        source: "iana"
      },
      "application/vnd.s3sms": {
        source: "iana"
      },
      "application/vnd.sailingtracker.track": {
        source: "iana",
        extensions: ["st"]
      },
      "application/vnd.sar": {
        source: "iana"
      },
      "application/vnd.sbm.cid": {
        source: "iana"
      },
      "application/vnd.sbm.mid2": {
        source: "iana"
      },
      "application/vnd.scribus": {
        source: "iana"
      },
      "application/vnd.sealed.3df": {
        source: "iana"
      },
      "application/vnd.sealed.csf": {
        source: "iana"
      },
      "application/vnd.sealed.doc": {
        source: "iana"
      },
      "application/vnd.sealed.eml": {
        source: "iana"
      },
      "application/vnd.sealed.mht": {
        source: "iana"
      },
      "application/vnd.sealed.net": {
        source: "iana"
      },
      "application/vnd.sealed.ppt": {
        source: "iana"
      },
      "application/vnd.sealed.tiff": {
        source: "iana"
      },
      "application/vnd.sealed.xls": {
        source: "iana"
      },
      "application/vnd.sealedmedia.softseal.html": {
        source: "iana"
      },
      "application/vnd.sealedmedia.softseal.pdf": {
        source: "iana"
      },
      "application/vnd.seemail": {
        source: "iana",
        extensions: ["see"]
      },
      "application/vnd.seis+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.sema": {
        source: "iana",
        extensions: ["sema"]
      },
      "application/vnd.semd": {
        source: "iana",
        extensions: ["semd"]
      },
      "application/vnd.semf": {
        source: "iana",
        extensions: ["semf"]
      },
      "application/vnd.shade-save-file": {
        source: "iana"
      },
      "application/vnd.shana.informed.formdata": {
        source: "iana",
        extensions: ["ifm"]
      },
      "application/vnd.shana.informed.formtemplate": {
        source: "iana",
        extensions: ["itp"]
      },
      "application/vnd.shana.informed.interchange": {
        source: "iana",
        extensions: ["iif"]
      },
      "application/vnd.shana.informed.package": {
        source: "iana",
        extensions: ["ipk"]
      },
      "application/vnd.shootproof+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.shopkick+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.shp": {
        source: "iana"
      },
      "application/vnd.shx": {
        source: "iana"
      },
      "application/vnd.sigrok.session": {
        source: "iana"
      },
      "application/vnd.simtech-mindmapper": {
        source: "iana",
        extensions: ["twd", "twds"]
      },
      "application/vnd.siren+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.smaf": {
        source: "iana",
        extensions: ["mmf"]
      },
      "application/vnd.smart.notebook": {
        source: "iana"
      },
      "application/vnd.smart.teacher": {
        source: "iana",
        extensions: ["teacher"]
      },
      "application/vnd.snesdev-page-table": {
        source: "iana"
      },
      "application/vnd.software602.filler.form+xml": {
        source: "iana",
        compressible: true,
        extensions: ["fo"]
      },
      "application/vnd.software602.filler.form-xml-zip": {
        source: "iana"
      },
      "application/vnd.solent.sdkm+xml": {
        source: "iana",
        compressible: true,
        extensions: ["sdkm", "sdkd"]
      },
      "application/vnd.spotfire.dxp": {
        source: "iana",
        extensions: ["dxp"]
      },
      "application/vnd.spotfire.sfs": {
        source: "iana",
        extensions: ["sfs"]
      },
      "application/vnd.sqlite3": {
        source: "iana"
      },
      "application/vnd.sss-cod": {
        source: "iana"
      },
      "application/vnd.sss-dtf": {
        source: "iana"
      },
      "application/vnd.sss-ntf": {
        source: "iana"
      },
      "application/vnd.stardivision.calc": {
        source: "apache",
        extensions: ["sdc"]
      },
      "application/vnd.stardivision.draw": {
        source: "apache",
        extensions: ["sda"]
      },
      "application/vnd.stardivision.impress": {
        source: "apache",
        extensions: ["sdd"]
      },
      "application/vnd.stardivision.math": {
        source: "apache",
        extensions: ["smf"]
      },
      "application/vnd.stardivision.writer": {
        source: "apache",
        extensions: ["sdw", "vor"]
      },
      "application/vnd.stardivision.writer-global": {
        source: "apache",
        extensions: ["sgl"]
      },
      "application/vnd.stepmania.package": {
        source: "iana",
        extensions: ["smzip"]
      },
      "application/vnd.stepmania.stepchart": {
        source: "iana",
        extensions: ["sm"]
      },
      "application/vnd.street-stream": {
        source: "iana"
      },
      "application/vnd.sun.wadl+xml": {
        source: "iana",
        compressible: true,
        extensions: ["wadl"]
      },
      "application/vnd.sun.xml.calc": {
        source: "apache",
        extensions: ["sxc"]
      },
      "application/vnd.sun.xml.calc.template": {
        source: "apache",
        extensions: ["stc"]
      },
      "application/vnd.sun.xml.draw": {
        source: "apache",
        extensions: ["sxd"]
      },
      "application/vnd.sun.xml.draw.template": {
        source: "apache",
        extensions: ["std"]
      },
      "application/vnd.sun.xml.impress": {
        source: "apache",
        extensions: ["sxi"]
      },
      "application/vnd.sun.xml.impress.template": {
        source: "apache",
        extensions: ["sti"]
      },
      "application/vnd.sun.xml.math": {
        source: "apache",
        extensions: ["sxm"]
      },
      "application/vnd.sun.xml.writer": {
        source: "apache",
        extensions: ["sxw"]
      },
      "application/vnd.sun.xml.writer.global": {
        source: "apache",
        extensions: ["sxg"]
      },
      "application/vnd.sun.xml.writer.template": {
        source: "apache",
        extensions: ["stw"]
      },
      "application/vnd.sus-calendar": {
        source: "iana",
        extensions: ["sus", "susp"]
      },
      "application/vnd.svd": {
        source: "iana",
        extensions: ["svd"]
      },
      "application/vnd.swiftview-ics": {
        source: "iana"
      },
      "application/vnd.sycle+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.syft+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.symbian.install": {
        source: "apache",
        extensions: ["sis", "sisx"]
      },
      "application/vnd.syncml+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["xsm"]
      },
      "application/vnd.syncml.dm+wbxml": {
        source: "iana",
        charset: "UTF-8",
        extensions: ["bdm"]
      },
      "application/vnd.syncml.dm+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["xdm"]
      },
      "application/vnd.syncml.dm.notification": {
        source: "iana"
      },
      "application/vnd.syncml.dmddf+wbxml": {
        source: "iana"
      },
      "application/vnd.syncml.dmddf+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["ddf"]
      },
      "application/vnd.syncml.dmtnds+wbxml": {
        source: "iana"
      },
      "application/vnd.syncml.dmtnds+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: true
      },
      "application/vnd.syncml.ds.notification": {
        source: "iana"
      },
      "application/vnd.tableschema+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.tao.intent-module-archive": {
        source: "iana",
        extensions: ["tao"]
      },
      "application/vnd.tcpdump.pcap": {
        source: "iana",
        extensions: ["pcap", "cap", "dmp"]
      },
      "application/vnd.think-cell.ppttc+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.tmd.mediaflex.api+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.tml": {
        source: "iana"
      },
      "application/vnd.tmobile-livetv": {
        source: "iana",
        extensions: ["tmo"]
      },
      "application/vnd.tri.onesource": {
        source: "iana"
      },
      "application/vnd.trid.tpt": {
        source: "iana",
        extensions: ["tpt"]
      },
      "application/vnd.triscape.mxs": {
        source: "iana",
        extensions: ["mxs"]
      },
      "application/vnd.trueapp": {
        source: "iana",
        extensions: ["tra"]
      },
      "application/vnd.truedoc": {
        source: "iana"
      },
      "application/vnd.ubisoft.webplayer": {
        source: "iana"
      },
      "application/vnd.ufdl": {
        source: "iana",
        extensions: ["ufd", "ufdl"]
      },
      "application/vnd.uiq.theme": {
        source: "iana",
        extensions: ["utz"]
      },
      "application/vnd.umajin": {
        source: "iana",
        extensions: ["umj"]
      },
      "application/vnd.unity": {
        source: "iana",
        extensions: ["unityweb"]
      },
      "application/vnd.uoml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["uoml"]
      },
      "application/vnd.uplanet.alert": {
        source: "iana"
      },
      "application/vnd.uplanet.alert-wbxml": {
        source: "iana"
      },
      "application/vnd.uplanet.bearer-choice": {
        source: "iana"
      },
      "application/vnd.uplanet.bearer-choice-wbxml": {
        source: "iana"
      },
      "application/vnd.uplanet.cacheop": {
        source: "iana"
      },
      "application/vnd.uplanet.cacheop-wbxml": {
        source: "iana"
      },
      "application/vnd.uplanet.channel": {
        source: "iana"
      },
      "application/vnd.uplanet.channel-wbxml": {
        source: "iana"
      },
      "application/vnd.uplanet.list": {
        source: "iana"
      },
      "application/vnd.uplanet.list-wbxml": {
        source: "iana"
      },
      "application/vnd.uplanet.listcmd": {
        source: "iana"
      },
      "application/vnd.uplanet.listcmd-wbxml": {
        source: "iana"
      },
      "application/vnd.uplanet.signal": {
        source: "iana"
      },
      "application/vnd.uri-map": {
        source: "iana"
      },
      "application/vnd.valve.source.material": {
        source: "iana"
      },
      "application/vnd.vcx": {
        source: "iana",
        extensions: ["vcx"]
      },
      "application/vnd.vd-study": {
        source: "iana"
      },
      "application/vnd.vectorworks": {
        source: "iana"
      },
      "application/vnd.vel+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.verimatrix.vcas": {
        source: "iana"
      },
      "application/vnd.veritone.aion+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.veryant.thin": {
        source: "iana"
      },
      "application/vnd.ves.encrypted": {
        source: "iana"
      },
      "application/vnd.vidsoft.vidconference": {
        source: "iana"
      },
      "application/vnd.visio": {
        source: "iana",
        extensions: ["vsd", "vst", "vss", "vsw"]
      },
      "application/vnd.visionary": {
        source: "iana",
        extensions: ["vis"]
      },
      "application/vnd.vividence.scriptfile": {
        source: "iana"
      },
      "application/vnd.vsf": {
        source: "iana",
        extensions: ["vsf"]
      },
      "application/vnd.wap.sic": {
        source: "iana"
      },
      "application/vnd.wap.slc": {
        source: "iana"
      },
      "application/vnd.wap.wbxml": {
        source: "iana",
        charset: "UTF-8",
        extensions: ["wbxml"]
      },
      "application/vnd.wap.wmlc": {
        source: "iana",
        extensions: ["wmlc"]
      },
      "application/vnd.wap.wmlscriptc": {
        source: "iana",
        extensions: ["wmlsc"]
      },
      "application/vnd.webturbo": {
        source: "iana",
        extensions: ["wtb"]
      },
      "application/vnd.wfa.dpp": {
        source: "iana"
      },
      "application/vnd.wfa.p2p": {
        source: "iana"
      },
      "application/vnd.wfa.wsc": {
        source: "iana"
      },
      "application/vnd.windows.devicepairing": {
        source: "iana"
      },
      "application/vnd.wmc": {
        source: "iana"
      },
      "application/vnd.wmf.bootstrap": {
        source: "iana"
      },
      "application/vnd.wolfram.mathematica": {
        source: "iana"
      },
      "application/vnd.wolfram.mathematica.package": {
        source: "iana"
      },
      "application/vnd.wolfram.player": {
        source: "iana",
        extensions: ["nbp"]
      },
      "application/vnd.wordperfect": {
        source: "iana",
        extensions: ["wpd"]
      },
      "application/vnd.wqd": {
        source: "iana",
        extensions: ["wqd"]
      },
      "application/vnd.wrq-hp3000-labelled": {
        source: "iana"
      },
      "application/vnd.wt.stf": {
        source: "iana",
        extensions: ["stf"]
      },
      "application/vnd.wv.csp+wbxml": {
        source: "iana"
      },
      "application/vnd.wv.csp+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.wv.ssp+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.xacml+json": {
        source: "iana",
        compressible: true
      },
      "application/vnd.xara": {
        source: "iana",
        extensions: ["xar"]
      },
      "application/vnd.xfdl": {
        source: "iana",
        extensions: ["xfdl"]
      },
      "application/vnd.xfdl.webform": {
        source: "iana"
      },
      "application/vnd.xmi+xml": {
        source: "iana",
        compressible: true
      },
      "application/vnd.xmpie.cpkg": {
        source: "iana"
      },
      "application/vnd.xmpie.dpkg": {
        source: "iana"
      },
      "application/vnd.xmpie.plan": {
        source: "iana"
      },
      "application/vnd.xmpie.ppkg": {
        source: "iana"
      },
      "application/vnd.xmpie.xlim": {
        source: "iana"
      },
      "application/vnd.yamaha.hv-dic": {
        source: "iana",
        extensions: ["hvd"]
      },
      "application/vnd.yamaha.hv-script": {
        source: "iana",
        extensions: ["hvs"]
      },
      "application/vnd.yamaha.hv-voice": {
        source: "iana",
        extensions: ["hvp"]
      },
      "application/vnd.yamaha.openscoreformat": {
        source: "iana",
        extensions: ["osf"]
      },
      "application/vnd.yamaha.openscoreformat.osfpvg+xml": {
        source: "iana",
        compressible: true,
        extensions: ["osfpvg"]
      },
      "application/vnd.yamaha.remote-setup": {
        source: "iana"
      },
      "application/vnd.yamaha.smaf-audio": {
        source: "iana",
        extensions: ["saf"]
      },
      "application/vnd.yamaha.smaf-phrase": {
        source: "iana",
        extensions: ["spf"]
      },
      "application/vnd.yamaha.through-ngn": {
        source: "iana"
      },
      "application/vnd.yamaha.tunnel-udpencap": {
        source: "iana"
      },
      "application/vnd.yaoweme": {
        source: "iana"
      },
      "application/vnd.yellowriver-custom-menu": {
        source: "iana",
        extensions: ["cmp"]
      },
      "application/vnd.youtube.yt": {
        source: "iana"
      },
      "application/vnd.zul": {
        source: "iana",
        extensions: ["zir", "zirz"]
      },
      "application/vnd.zzazz.deck+xml": {
        source: "iana",
        compressible: true,
        extensions: ["zaz"]
      },
      "application/voicexml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["vxml"]
      },
      "application/voucher-cms+json": {
        source: "iana",
        compressible: true
      },
      "application/vq-rtcpxr": {
        source: "iana"
      },
      "application/wasm": {
        source: "iana",
        compressible: true,
        extensions: ["wasm"]
      },
      "application/watcherinfo+xml": {
        source: "iana",
        compressible: true,
        extensions: ["wif"]
      },
      "application/webpush-options+json": {
        source: "iana",
        compressible: true
      },
      "application/whoispp-query": {
        source: "iana"
      },
      "application/whoispp-response": {
        source: "iana"
      },
      "application/widget": {
        source: "iana",
        extensions: ["wgt"]
      },
      "application/winhlp": {
        source: "apache",
        extensions: ["hlp"]
      },
      "application/wita": {
        source: "iana"
      },
      "application/wordperfect5.1": {
        source: "iana"
      },
      "application/wsdl+xml": {
        source: "iana",
        compressible: true,
        extensions: ["wsdl"]
      },
      "application/wspolicy+xml": {
        source: "iana",
        compressible: true,
        extensions: ["wspolicy"]
      },
      "application/x-7z-compressed": {
        source: "apache",
        compressible: false,
        extensions: ["7z"]
      },
      "application/x-abiword": {
        source: "apache",
        extensions: ["abw"]
      },
      "application/x-ace-compressed": {
        source: "apache",
        extensions: ["ace"]
      },
      "application/x-amf": {
        source: "apache"
      },
      "application/x-apple-diskimage": {
        source: "apache",
        extensions: ["dmg"]
      },
      "application/x-arj": {
        compressible: false,
        extensions: ["arj"]
      },
      "application/x-authorware-bin": {
        source: "apache",
        extensions: ["aab", "x32", "u32", "vox"]
      },
      "application/x-authorware-map": {
        source: "apache",
        extensions: ["aam"]
      },
      "application/x-authorware-seg": {
        source: "apache",
        extensions: ["aas"]
      },
      "application/x-bcpio": {
        source: "apache",
        extensions: ["bcpio"]
      },
      "application/x-bdoc": {
        compressible: false,
        extensions: ["bdoc"]
      },
      "application/x-bittorrent": {
        source: "apache",
        extensions: ["torrent"]
      },
      "application/x-blorb": {
        source: "apache",
        extensions: ["blb", "blorb"]
      },
      "application/x-bzip": {
        source: "apache",
        compressible: false,
        extensions: ["bz"]
      },
      "application/x-bzip2": {
        source: "apache",
        compressible: false,
        extensions: ["bz2", "boz"]
      },
      "application/x-cbr": {
        source: "apache",
        extensions: ["cbr", "cba", "cbt", "cbz", "cb7"]
      },
      "application/x-cdlink": {
        source: "apache",
        extensions: ["vcd"]
      },
      "application/x-cfs-compressed": {
        source: "apache",
        extensions: ["cfs"]
      },
      "application/x-chat": {
        source: "apache",
        extensions: ["chat"]
      },
      "application/x-chess-pgn": {
        source: "apache",
        extensions: ["pgn"]
      },
      "application/x-chrome-extension": {
        extensions: ["crx"]
      },
      "application/x-cocoa": {
        source: "nginx",
        extensions: ["cco"]
      },
      "application/x-compress": {
        source: "apache"
      },
      "application/x-conference": {
        source: "apache",
        extensions: ["nsc"]
      },
      "application/x-cpio": {
        source: "apache",
        extensions: ["cpio"]
      },
      "application/x-csh": {
        source: "apache",
        extensions: ["csh"]
      },
      "application/x-deb": {
        compressible: false
      },
      "application/x-debian-package": {
        source: "apache",
        extensions: ["deb", "udeb"]
      },
      "application/x-dgc-compressed": {
        source: "apache",
        extensions: ["dgc"]
      },
      "application/x-director": {
        source: "apache",
        extensions: ["dir", "dcr", "dxr", "cst", "cct", "cxt", "w3d", "fgd", "swa"]
      },
      "application/x-doom": {
        source: "apache",
        extensions: ["wad"]
      },
      "application/x-dtbncx+xml": {
        source: "apache",
        compressible: true,
        extensions: ["ncx"]
      },
      "application/x-dtbook+xml": {
        source: "apache",
        compressible: true,
        extensions: ["dtb"]
      },
      "application/x-dtbresource+xml": {
        source: "apache",
        compressible: true,
        extensions: ["res"]
      },
      "application/x-dvi": {
        source: "apache",
        compressible: false,
        extensions: ["dvi"]
      },
      "application/x-envoy": {
        source: "apache",
        extensions: ["evy"]
      },
      "application/x-eva": {
        source: "apache",
        extensions: ["eva"]
      },
      "application/x-font-bdf": {
        source: "apache",
        extensions: ["bdf"]
      },
      "application/x-font-dos": {
        source: "apache"
      },
      "application/x-font-framemaker": {
        source: "apache"
      },
      "application/x-font-ghostscript": {
        source: "apache",
        extensions: ["gsf"]
      },
      "application/x-font-libgrx": {
        source: "apache"
      },
      "application/x-font-linux-psf": {
        source: "apache",
        extensions: ["psf"]
      },
      "application/x-font-pcf": {
        source: "apache",
        extensions: ["pcf"]
      },
      "application/x-font-snf": {
        source: "apache",
        extensions: ["snf"]
      },
      "application/x-font-speedo": {
        source: "apache"
      },
      "application/x-font-sunos-news": {
        source: "apache"
      },
      "application/x-font-type1": {
        source: "apache",
        extensions: ["pfa", "pfb", "pfm", "afm"]
      },
      "application/x-font-vfont": {
        source: "apache"
      },
      "application/x-freearc": {
        source: "apache",
        extensions: ["arc"]
      },
      "application/x-futuresplash": {
        source: "apache",
        extensions: ["spl"]
      },
      "application/x-gca-compressed": {
        source: "apache",
        extensions: ["gca"]
      },
      "application/x-glulx": {
        source: "apache",
        extensions: ["ulx"]
      },
      "application/x-gnumeric": {
        source: "apache",
        extensions: ["gnumeric"]
      },
      "application/x-gramps-xml": {
        source: "apache",
        extensions: ["gramps"]
      },
      "application/x-gtar": {
        source: "apache",
        extensions: ["gtar"]
      },
      "application/x-gzip": {
        source: "apache"
      },
      "application/x-hdf": {
        source: "apache",
        extensions: ["hdf"]
      },
      "application/x-httpd-php": {
        compressible: true,
        extensions: ["php"]
      },
      "application/x-install-instructions": {
        source: "apache",
        extensions: ["install"]
      },
      "application/x-iso9660-image": {
        source: "apache",
        extensions: ["iso"]
      },
      "application/x-iwork-keynote-sffkey": {
        extensions: ["key"]
      },
      "application/x-iwork-numbers-sffnumbers": {
        extensions: ["numbers"]
      },
      "application/x-iwork-pages-sffpages": {
        extensions: ["pages"]
      },
      "application/x-java-archive-diff": {
        source: "nginx",
        extensions: ["jardiff"]
      },
      "application/x-java-jnlp-file": {
        source: "apache",
        compressible: false,
        extensions: ["jnlp"]
      },
      "application/x-javascript": {
        compressible: true
      },
      "application/x-keepass2": {
        extensions: ["kdbx"]
      },
      "application/x-latex": {
        source: "apache",
        compressible: false,
        extensions: ["latex"]
      },
      "application/x-lua-bytecode": {
        extensions: ["luac"]
      },
      "application/x-lzh-compressed": {
        source: "apache",
        extensions: ["lzh", "lha"]
      },
      "application/x-makeself": {
        source: "nginx",
        extensions: ["run"]
      },
      "application/x-mie": {
        source: "apache",
        extensions: ["mie"]
      },
      "application/x-mobipocket-ebook": {
        source: "apache",
        extensions: ["prc", "mobi"]
      },
      "application/x-mpegurl": {
        compressible: false
      },
      "application/x-ms-application": {
        source: "apache",
        extensions: ["application"]
      },
      "application/x-ms-shortcut": {
        source: "apache",
        extensions: ["lnk"]
      },
      "application/x-ms-wmd": {
        source: "apache",
        extensions: ["wmd"]
      },
      "application/x-ms-wmz": {
        source: "apache",
        extensions: ["wmz"]
      },
      "application/x-ms-xbap": {
        source: "apache",
        extensions: ["xbap"]
      },
      "application/x-msaccess": {
        source: "apache",
        extensions: ["mdb"]
      },
      "application/x-msbinder": {
        source: "apache",
        extensions: ["obd"]
      },
      "application/x-mscardfile": {
        source: "apache",
        extensions: ["crd"]
      },
      "application/x-msclip": {
        source: "apache",
        extensions: ["clp"]
      },
      "application/x-msdos-program": {
        extensions: ["exe"]
      },
      "application/x-msdownload": {
        source: "apache",
        extensions: ["exe", "dll", "com", "bat", "msi"]
      },
      "application/x-msmediaview": {
        source: "apache",
        extensions: ["mvb", "m13", "m14"]
      },
      "application/x-msmetafile": {
        source: "apache",
        extensions: ["wmf", "wmz", "emf", "emz"]
      },
      "application/x-msmoney": {
        source: "apache",
        extensions: ["mny"]
      },
      "application/x-mspublisher": {
        source: "apache",
        extensions: ["pub"]
      },
      "application/x-msschedule": {
        source: "apache",
        extensions: ["scd"]
      },
      "application/x-msterminal": {
        source: "apache",
        extensions: ["trm"]
      },
      "application/x-mswrite": {
        source: "apache",
        extensions: ["wri"]
      },
      "application/x-netcdf": {
        source: "apache",
        extensions: ["nc", "cdf"]
      },
      "application/x-ns-proxy-autoconfig": {
        compressible: true,
        extensions: ["pac"]
      },
      "application/x-nzb": {
        source: "apache",
        extensions: ["nzb"]
      },
      "application/x-perl": {
        source: "nginx",
        extensions: ["pl", "pm"]
      },
      "application/x-pilot": {
        source: "nginx",
        extensions: ["prc", "pdb"]
      },
      "application/x-pkcs12": {
        source: "apache",
        compressible: false,
        extensions: ["p12", "pfx"]
      },
      "application/x-pkcs7-certificates": {
        source: "apache",
        extensions: ["p7b", "spc"]
      },
      "application/x-pkcs7-certreqresp": {
        source: "apache",
        extensions: ["p7r"]
      },
      "application/x-pki-message": {
        source: "iana"
      },
      "application/x-rar-compressed": {
        source: "apache",
        compressible: false,
        extensions: ["rar"]
      },
      "application/x-redhat-package-manager": {
        source: "nginx",
        extensions: ["rpm"]
      },
      "application/x-research-info-systems": {
        source: "apache",
        extensions: ["ris"]
      },
      "application/x-sea": {
        source: "nginx",
        extensions: ["sea"]
      },
      "application/x-sh": {
        source: "apache",
        compressible: true,
        extensions: ["sh"]
      },
      "application/x-shar": {
        source: "apache",
        extensions: ["shar"]
      },
      "application/x-shockwave-flash": {
        source: "apache",
        compressible: false,
        extensions: ["swf"]
      },
      "application/x-silverlight-app": {
        source: "apache",
        extensions: ["xap"]
      },
      "application/x-sql": {
        source: "apache",
        extensions: ["sql"]
      },
      "application/x-stuffit": {
        source: "apache",
        compressible: false,
        extensions: ["sit"]
      },
      "application/x-stuffitx": {
        source: "apache",
        extensions: ["sitx"]
      },
      "application/x-subrip": {
        source: "apache",
        extensions: ["srt"]
      },
      "application/x-sv4cpio": {
        source: "apache",
        extensions: ["sv4cpio"]
      },
      "application/x-sv4crc": {
        source: "apache",
        extensions: ["sv4crc"]
      },
      "application/x-t3vm-image": {
        source: "apache",
        extensions: ["t3"]
      },
      "application/x-tads": {
        source: "apache",
        extensions: ["gam"]
      },
      "application/x-tar": {
        source: "apache",
        compressible: true,
        extensions: ["tar"]
      },
      "application/x-tcl": {
        source: "apache",
        extensions: ["tcl", "tk"]
      },
      "application/x-tex": {
        source: "apache",
        extensions: ["tex"]
      },
      "application/x-tex-tfm": {
        source: "apache",
        extensions: ["tfm"]
      },
      "application/x-texinfo": {
        source: "apache",
        extensions: ["texinfo", "texi"]
      },
      "application/x-tgif": {
        source: "apache",
        extensions: ["obj"]
      },
      "application/x-ustar": {
        source: "apache",
        extensions: ["ustar"]
      },
      "application/x-virtualbox-hdd": {
        compressible: true,
        extensions: ["hdd"]
      },
      "application/x-virtualbox-ova": {
        compressible: true,
        extensions: ["ova"]
      },
      "application/x-virtualbox-ovf": {
        compressible: true,
        extensions: ["ovf"]
      },
      "application/x-virtualbox-vbox": {
        compressible: true,
        extensions: ["vbox"]
      },
      "application/x-virtualbox-vbox-extpack": {
        compressible: false,
        extensions: ["vbox-extpack"]
      },
      "application/x-virtualbox-vdi": {
        compressible: true,
        extensions: ["vdi"]
      },
      "application/x-virtualbox-vhd": {
        compressible: true,
        extensions: ["vhd"]
      },
      "application/x-virtualbox-vmdk": {
        compressible: true,
        extensions: ["vmdk"]
      },
      "application/x-wais-source": {
        source: "apache",
        extensions: ["src"]
      },
      "application/x-web-app-manifest+json": {
        compressible: true,
        extensions: ["webapp"]
      },
      "application/x-www-form-urlencoded": {
        source: "iana",
        compressible: true
      },
      "application/x-x509-ca-cert": {
        source: "iana",
        extensions: ["der", "crt", "pem"]
      },
      "application/x-x509-ca-ra-cert": {
        source: "iana"
      },
      "application/x-x509-next-ca-cert": {
        source: "iana"
      },
      "application/x-xfig": {
        source: "apache",
        extensions: ["fig"]
      },
      "application/x-xliff+xml": {
        source: "apache",
        compressible: true,
        extensions: ["xlf"]
      },
      "application/x-xpinstall": {
        source: "apache",
        compressible: false,
        extensions: ["xpi"]
      },
      "application/x-xz": {
        source: "apache",
        extensions: ["xz"]
      },
      "application/x-zmachine": {
        source: "apache",
        extensions: ["z1", "z2", "z3", "z4", "z5", "z6", "z7", "z8"]
      },
      "application/x400-bp": {
        source: "iana"
      },
      "application/xacml+xml": {
        source: "iana",
        compressible: true
      },
      "application/xaml+xml": {
        source: "apache",
        compressible: true,
        extensions: ["xaml"]
      },
      "application/xcap-att+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xav"]
      },
      "application/xcap-caps+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xca"]
      },
      "application/xcap-diff+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xdf"]
      },
      "application/xcap-el+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xel"]
      },
      "application/xcap-error+xml": {
        source: "iana",
        compressible: true
      },
      "application/xcap-ns+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xns"]
      },
      "application/xcon-conference-info+xml": {
        source: "iana",
        compressible: true
      },
      "application/xcon-conference-info-diff+xml": {
        source: "iana",
        compressible: true
      },
      "application/xenc+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xenc"]
      },
      "application/xhtml+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xhtml", "xht"]
      },
      "application/xhtml-voice+xml": {
        source: "apache",
        compressible: true
      },
      "application/xliff+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xlf"]
      },
      "application/xml": {
        source: "iana",
        compressible: true,
        extensions: ["xml", "xsl", "xsd", "rng"]
      },
      "application/xml-dtd": {
        source: "iana",
        compressible: true,
        extensions: ["dtd"]
      },
      "application/xml-external-parsed-entity": {
        source: "iana"
      },
      "application/xml-patch+xml": {
        source: "iana",
        compressible: true
      },
      "application/xmpp+xml": {
        source: "iana",
        compressible: true
      },
      "application/xop+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xop"]
      },
      "application/xproc+xml": {
        source: "apache",
        compressible: true,
        extensions: ["xpl"]
      },
      "application/xslt+xml": {
        source: "iana",
        compressible: true,
        extensions: ["xsl", "xslt"]
      },
      "application/xspf+xml": {
        source: "apache",
        compressible: true,
        extensions: ["xspf"]
      },
      "application/xv+xml": {
        source: "iana",
        compressible: true,
        extensions: ["mxml", "xhvml", "xvml", "xvm"]
      },
      "application/yang": {
        source: "iana",
        extensions: ["yang"]
      },
      "application/yang-data+json": {
        source: "iana",
        compressible: true
      },
      "application/yang-data+xml": {
        source: "iana",
        compressible: true
      },
      "application/yang-patch+json": {
        source: "iana",
        compressible: true
      },
      "application/yang-patch+xml": {
        source: "iana",
        compressible: true
      },
      "application/yin+xml": {
        source: "iana",
        compressible: true,
        extensions: ["yin"]
      },
      "application/zip": {
        source: "iana",
        compressible: false,
        extensions: ["zip"]
      },
      "application/zlib": {
        source: "iana"
      },
      "application/zstd": {
        source: "iana"
      },
      "audio/1d-interleaved-parityfec": {
        source: "iana"
      },
      "audio/32kadpcm": {
        source: "iana"
      },
      "audio/3gpp": {
        source: "iana",
        compressible: false,
        extensions: ["3gpp"]
      },
      "audio/3gpp2": {
        source: "iana"
      },
      "audio/aac": {
        source: "iana"
      },
      "audio/ac3": {
        source: "iana"
      },
      "audio/adpcm": {
        source: "apache",
        extensions: ["adp"]
      },
      "audio/amr": {
        source: "iana",
        extensions: ["amr"]
      },
      "audio/amr-wb": {
        source: "iana"
      },
      "audio/amr-wb+": {
        source: "iana"
      },
      "audio/aptx": {
        source: "iana"
      },
      "audio/asc": {
        source: "iana"
      },
      "audio/atrac-advanced-lossless": {
        source: "iana"
      },
      "audio/atrac-x": {
        source: "iana"
      },
      "audio/atrac3": {
        source: "iana"
      },
      "audio/basic": {
        source: "iana",
        compressible: false,
        extensions: ["au", "snd"]
      },
      "audio/bv16": {
        source: "iana"
      },
      "audio/bv32": {
        source: "iana"
      },
      "audio/clearmode": {
        source: "iana"
      },
      "audio/cn": {
        source: "iana"
      },
      "audio/dat12": {
        source: "iana"
      },
      "audio/dls": {
        source: "iana"
      },
      "audio/dsr-es201108": {
        source: "iana"
      },
      "audio/dsr-es202050": {
        source: "iana"
      },
      "audio/dsr-es202211": {
        source: "iana"
      },
      "audio/dsr-es202212": {
        source: "iana"
      },
      "audio/dv": {
        source: "iana"
      },
      "audio/dvi4": {
        source: "iana"
      },
      "audio/eac3": {
        source: "iana"
      },
      "audio/encaprtp": {
        source: "iana"
      },
      "audio/evrc": {
        source: "iana"
      },
      "audio/evrc-qcp": {
        source: "iana"
      },
      "audio/evrc0": {
        source: "iana"
      },
      "audio/evrc1": {
        source: "iana"
      },
      "audio/evrcb": {
        source: "iana"
      },
      "audio/evrcb0": {
        source: "iana"
      },
      "audio/evrcb1": {
        source: "iana"
      },
      "audio/evrcnw": {
        source: "iana"
      },
      "audio/evrcnw0": {
        source: "iana"
      },
      "audio/evrcnw1": {
        source: "iana"
      },
      "audio/evrcwb": {
        source: "iana"
      },
      "audio/evrcwb0": {
        source: "iana"
      },
      "audio/evrcwb1": {
        source: "iana"
      },
      "audio/evs": {
        source: "iana"
      },
      "audio/flexfec": {
        source: "iana"
      },
      "audio/fwdred": {
        source: "iana"
      },
      "audio/g711-0": {
        source: "iana"
      },
      "audio/g719": {
        source: "iana"
      },
      "audio/g722": {
        source: "iana"
      },
      "audio/g7221": {
        source: "iana"
      },
      "audio/g723": {
        source: "iana"
      },
      "audio/g726-16": {
        source: "iana"
      },
      "audio/g726-24": {
        source: "iana"
      },
      "audio/g726-32": {
        source: "iana"
      },
      "audio/g726-40": {
        source: "iana"
      },
      "audio/g728": {
        source: "iana"
      },
      "audio/g729": {
        source: "iana"
      },
      "audio/g7291": {
        source: "iana"
      },
      "audio/g729d": {
        source: "iana"
      },
      "audio/g729e": {
        source: "iana"
      },
      "audio/gsm": {
        source: "iana"
      },
      "audio/gsm-efr": {
        source: "iana"
      },
      "audio/gsm-hr-08": {
        source: "iana"
      },
      "audio/ilbc": {
        source: "iana"
      },
      "audio/ip-mr_v2.5": {
        source: "iana"
      },
      "audio/isac": {
        source: "apache"
      },
      "audio/l16": {
        source: "iana"
      },
      "audio/l20": {
        source: "iana"
      },
      "audio/l24": {
        source: "iana",
        compressible: false
      },
      "audio/l8": {
        source: "iana"
      },
      "audio/lpc": {
        source: "iana"
      },
      "audio/melp": {
        source: "iana"
      },
      "audio/melp1200": {
        source: "iana"
      },
      "audio/melp2400": {
        source: "iana"
      },
      "audio/melp600": {
        source: "iana"
      },
      "audio/mhas": {
        source: "iana"
      },
      "audio/midi": {
        source: "apache",
        extensions: ["mid", "midi", "kar", "rmi"]
      },
      "audio/mobile-xmf": {
        source: "iana",
        extensions: ["mxmf"]
      },
      "audio/mp3": {
        compressible: false,
        extensions: ["mp3"]
      },
      "audio/mp4": {
        source: "iana",
        compressible: false,
        extensions: ["m4a", "mp4a"]
      },
      "audio/mp4a-latm": {
        source: "iana"
      },
      "audio/mpa": {
        source: "iana"
      },
      "audio/mpa-robust": {
        source: "iana"
      },
      "audio/mpeg": {
        source: "iana",
        compressible: false,
        extensions: ["mpga", "mp2", "mp2a", "mp3", "m2a", "m3a"]
      },
      "audio/mpeg4-generic": {
        source: "iana"
      },
      "audio/musepack": {
        source: "apache"
      },
      "audio/ogg": {
        source: "iana",
        compressible: false,
        extensions: ["oga", "ogg", "spx", "opus"]
      },
      "audio/opus": {
        source: "iana"
      },
      "audio/parityfec": {
        source: "iana"
      },
      "audio/pcma": {
        source: "iana"
      },
      "audio/pcma-wb": {
        source: "iana"
      },
      "audio/pcmu": {
        source: "iana"
      },
      "audio/pcmu-wb": {
        source: "iana"
      },
      "audio/prs.sid": {
        source: "iana"
      },
      "audio/qcelp": {
        source: "iana"
      },
      "audio/raptorfec": {
        source: "iana"
      },
      "audio/red": {
        source: "iana"
      },
      "audio/rtp-enc-aescm128": {
        source: "iana"
      },
      "audio/rtp-midi": {
        source: "iana"
      },
      "audio/rtploopback": {
        source: "iana"
      },
      "audio/rtx": {
        source: "iana"
      },
      "audio/s3m": {
        source: "apache",
        extensions: ["s3m"]
      },
      "audio/scip": {
        source: "iana"
      },
      "audio/silk": {
        source: "apache",
        extensions: ["sil"]
      },
      "audio/smv": {
        source: "iana"
      },
      "audio/smv-qcp": {
        source: "iana"
      },
      "audio/smv0": {
        source: "iana"
      },
      "audio/sofa": {
        source: "iana"
      },
      "audio/sp-midi": {
        source: "iana"
      },
      "audio/speex": {
        source: "iana"
      },
      "audio/t140c": {
        source: "iana"
      },
      "audio/t38": {
        source: "iana"
      },
      "audio/telephone-event": {
        source: "iana"
      },
      "audio/tetra_acelp": {
        source: "iana"
      },
      "audio/tetra_acelp_bb": {
        source: "iana"
      },
      "audio/tone": {
        source: "iana"
      },
      "audio/tsvcis": {
        source: "iana"
      },
      "audio/uemclip": {
        source: "iana"
      },
      "audio/ulpfec": {
        source: "iana"
      },
      "audio/usac": {
        source: "iana"
      },
      "audio/vdvi": {
        source: "iana"
      },
      "audio/vmr-wb": {
        source: "iana"
      },
      "audio/vnd.3gpp.iufp": {
        source: "iana"
      },
      "audio/vnd.4sb": {
        source: "iana"
      },
      "audio/vnd.audiokoz": {
        source: "iana"
      },
      "audio/vnd.celp": {
        source: "iana"
      },
      "audio/vnd.cisco.nse": {
        source: "iana"
      },
      "audio/vnd.cmles.radio-events": {
        source: "iana"
      },
      "audio/vnd.cns.anp1": {
        source: "iana"
      },
      "audio/vnd.cns.inf1": {
        source: "iana"
      },
      "audio/vnd.dece.audio": {
        source: "iana",
        extensions: ["uva", "uvva"]
      },
      "audio/vnd.digital-winds": {
        source: "iana",
        extensions: ["eol"]
      },
      "audio/vnd.dlna.adts": {
        source: "iana"
      },
      "audio/vnd.dolby.heaac.1": {
        source: "iana"
      },
      "audio/vnd.dolby.heaac.2": {
        source: "iana"
      },
      "audio/vnd.dolby.mlp": {
        source: "iana"
      },
      "audio/vnd.dolby.mps": {
        source: "iana"
      },
      "audio/vnd.dolby.pl2": {
        source: "iana"
      },
      "audio/vnd.dolby.pl2x": {
        source: "iana"
      },
      "audio/vnd.dolby.pl2z": {
        source: "iana"
      },
      "audio/vnd.dolby.pulse.1": {
        source: "iana"
      },
      "audio/vnd.dra": {
        source: "iana",
        extensions: ["dra"]
      },
      "audio/vnd.dts": {
        source: "iana",
        extensions: ["dts"]
      },
      "audio/vnd.dts.hd": {
        source: "iana",
        extensions: ["dtshd"]
      },
      "audio/vnd.dts.uhd": {
        source: "iana"
      },
      "audio/vnd.dvb.file": {
        source: "iana"
      },
      "audio/vnd.everad.plj": {
        source: "iana"
      },
      "audio/vnd.hns.audio": {
        source: "iana"
      },
      "audio/vnd.lucent.voice": {
        source: "iana",
        extensions: ["lvp"]
      },
      "audio/vnd.ms-playready.media.pya": {
        source: "iana",
        extensions: ["pya"]
      },
      "audio/vnd.nokia.mobile-xmf": {
        source: "iana"
      },
      "audio/vnd.nortel.vbk": {
        source: "iana"
      },
      "audio/vnd.nuera.ecelp4800": {
        source: "iana",
        extensions: ["ecelp4800"]
      },
      "audio/vnd.nuera.ecelp7470": {
        source: "iana",
        extensions: ["ecelp7470"]
      },
      "audio/vnd.nuera.ecelp9600": {
        source: "iana",
        extensions: ["ecelp9600"]
      },
      "audio/vnd.octel.sbc": {
        source: "iana"
      },
      "audio/vnd.presonus.multitrack": {
        source: "iana"
      },
      "audio/vnd.qcelp": {
        source: "iana"
      },
      "audio/vnd.rhetorex.32kadpcm": {
        source: "iana"
      },
      "audio/vnd.rip": {
        source: "iana",
        extensions: ["rip"]
      },
      "audio/vnd.rn-realaudio": {
        compressible: false
      },
      "audio/vnd.sealedmedia.softseal.mpeg": {
        source: "iana"
      },
      "audio/vnd.vmx.cvsd": {
        source: "iana"
      },
      "audio/vnd.wave": {
        compressible: false
      },
      "audio/vorbis": {
        source: "iana",
        compressible: false
      },
      "audio/vorbis-config": {
        source: "iana"
      },
      "audio/wav": {
        compressible: false,
        extensions: ["wav"]
      },
      "audio/wave": {
        compressible: false,
        extensions: ["wav"]
      },
      "audio/webm": {
        source: "apache",
        compressible: false,
        extensions: ["weba"]
      },
      "audio/x-aac": {
        source: "apache",
        compressible: false,
        extensions: ["aac"]
      },
      "audio/x-aiff": {
        source: "apache",
        extensions: ["aif", "aiff", "aifc"]
      },
      "audio/x-caf": {
        source: "apache",
        compressible: false,
        extensions: ["caf"]
      },
      "audio/x-flac": {
        source: "apache",
        extensions: ["flac"]
      },
      "audio/x-m4a": {
        source: "nginx",
        extensions: ["m4a"]
      },
      "audio/x-matroska": {
        source: "apache",
        extensions: ["mka"]
      },
      "audio/x-mpegurl": {
        source: "apache",
        extensions: ["m3u"]
      },
      "audio/x-ms-wax": {
        source: "apache",
        extensions: ["wax"]
      },
      "audio/x-ms-wma": {
        source: "apache",
        extensions: ["wma"]
      },
      "audio/x-pn-realaudio": {
        source: "apache",
        extensions: ["ram", "ra"]
      },
      "audio/x-pn-realaudio-plugin": {
        source: "apache",
        extensions: ["rmp"]
      },
      "audio/x-realaudio": {
        source: "nginx",
        extensions: ["ra"]
      },
      "audio/x-tta": {
        source: "apache"
      },
      "audio/x-wav": {
        source: "apache",
        extensions: ["wav"]
      },
      "audio/xm": {
        source: "apache",
        extensions: ["xm"]
      },
      "chemical/x-cdx": {
        source: "apache",
        extensions: ["cdx"]
      },
      "chemical/x-cif": {
        source: "apache",
        extensions: ["cif"]
      },
      "chemical/x-cmdf": {
        source: "apache",
        extensions: ["cmdf"]
      },
      "chemical/x-cml": {
        source: "apache",
        extensions: ["cml"]
      },
      "chemical/x-csml": {
        source: "apache",
        extensions: ["csml"]
      },
      "chemical/x-pdb": {
        source: "apache"
      },
      "chemical/x-xyz": {
        source: "apache",
        extensions: ["xyz"]
      },
      "font/collection": {
        source: "iana",
        extensions: ["ttc"]
      },
      "font/otf": {
        source: "iana",
        compressible: true,
        extensions: ["otf"]
      },
      "font/sfnt": {
        source: "iana"
      },
      "font/ttf": {
        source: "iana",
        compressible: true,
        extensions: ["ttf"]
      },
      "font/woff": {
        source: "iana",
        extensions: ["woff"]
      },
      "font/woff2": {
        source: "iana",
        extensions: ["woff2"]
      },
      "image/aces": {
        source: "iana",
        extensions: ["exr"]
      },
      "image/apng": {
        compressible: false,
        extensions: ["apng"]
      },
      "image/avci": {
        source: "iana",
        extensions: ["avci"]
      },
      "image/avcs": {
        source: "iana",
        extensions: ["avcs"]
      },
      "image/avif": {
        source: "iana",
        compressible: false,
        extensions: ["avif"]
      },
      "image/bmp": {
        source: "iana",
        compressible: true,
        extensions: ["bmp"]
      },
      "image/cgm": {
        source: "iana",
        extensions: ["cgm"]
      },
      "image/dicom-rle": {
        source: "iana",
        extensions: ["drle"]
      },
      "image/emf": {
        source: "iana",
        extensions: ["emf"]
      },
      "image/fits": {
        source: "iana",
        extensions: ["fits"]
      },
      "image/g3fax": {
        source: "iana",
        extensions: ["g3"]
      },
      "image/gif": {
        source: "iana",
        compressible: false,
        extensions: ["gif"]
      },
      "image/heic": {
        source: "iana",
        extensions: ["heic"]
      },
      "image/heic-sequence": {
        source: "iana",
        extensions: ["heics"]
      },
      "image/heif": {
        source: "iana",
        extensions: ["heif"]
      },
      "image/heif-sequence": {
        source: "iana",
        extensions: ["heifs"]
      },
      "image/hej2k": {
        source: "iana",
        extensions: ["hej2"]
      },
      "image/hsj2": {
        source: "iana",
        extensions: ["hsj2"]
      },
      "image/ief": {
        source: "iana",
        extensions: ["ief"]
      },
      "image/jls": {
        source: "iana",
        extensions: ["jls"]
      },
      "image/jp2": {
        source: "iana",
        compressible: false,
        extensions: ["jp2", "jpg2"]
      },
      "image/jpeg": {
        source: "iana",
        compressible: false,
        extensions: ["jpeg", "jpg", "jpe"]
      },
      "image/jph": {
        source: "iana",
        extensions: ["jph"]
      },
      "image/jphc": {
        source: "iana",
        extensions: ["jhc"]
      },
      "image/jpm": {
        source: "iana",
        compressible: false,
        extensions: ["jpm"]
      },
      "image/jpx": {
        source: "iana",
        compressible: false,
        extensions: ["jpx", "jpf"]
      },
      "image/jxr": {
        source: "iana",
        extensions: ["jxr"]
      },
      "image/jxra": {
        source: "iana",
        extensions: ["jxra"]
      },
      "image/jxrs": {
        source: "iana",
        extensions: ["jxrs"]
      },
      "image/jxs": {
        source: "iana",
        extensions: ["jxs"]
      },
      "image/jxsc": {
        source: "iana",
        extensions: ["jxsc"]
      },
      "image/jxsi": {
        source: "iana",
        extensions: ["jxsi"]
      },
      "image/jxss": {
        source: "iana",
        extensions: ["jxss"]
      },
      "image/ktx": {
        source: "iana",
        extensions: ["ktx"]
      },
      "image/ktx2": {
        source: "iana",
        extensions: ["ktx2"]
      },
      "image/naplps": {
        source: "iana"
      },
      "image/pjpeg": {
        compressible: false
      },
      "image/png": {
        source: "iana",
        compressible: false,
        extensions: ["png"]
      },
      "image/prs.btif": {
        source: "iana",
        extensions: ["btif"]
      },
      "image/prs.pti": {
        source: "iana",
        extensions: ["pti"]
      },
      "image/pwg-raster": {
        source: "iana"
      },
      "image/sgi": {
        source: "apache",
        extensions: ["sgi"]
      },
      "image/svg+xml": {
        source: "iana",
        compressible: true,
        extensions: ["svg", "svgz"]
      },
      "image/t38": {
        source: "iana",
        extensions: ["t38"]
      },
      "image/tiff": {
        source: "iana",
        compressible: false,
        extensions: ["tif", "tiff"]
      },
      "image/tiff-fx": {
        source: "iana",
        extensions: ["tfx"]
      },
      "image/vnd.adobe.photoshop": {
        source: "iana",
        compressible: true,
        extensions: ["psd"]
      },
      "image/vnd.airzip.accelerator.azv": {
        source: "iana",
        extensions: ["azv"]
      },
      "image/vnd.cns.inf2": {
        source: "iana"
      },
      "image/vnd.dece.graphic": {
        source: "iana",
        extensions: ["uvi", "uvvi", "uvg", "uvvg"]
      },
      "image/vnd.djvu": {
        source: "iana",
        extensions: ["djvu", "djv"]
      },
      "image/vnd.dvb.subtitle": {
        source: "iana",
        extensions: ["sub"]
      },
      "image/vnd.dwg": {
        source: "iana",
        extensions: ["dwg"]
      },
      "image/vnd.dxf": {
        source: "iana",
        extensions: ["dxf"]
      },
      "image/vnd.fastbidsheet": {
        source: "iana",
        extensions: ["fbs"]
      },
      "image/vnd.fpx": {
        source: "iana",
        extensions: ["fpx"]
      },
      "image/vnd.fst": {
        source: "iana",
        extensions: ["fst"]
      },
      "image/vnd.fujixerox.edmics-mmr": {
        source: "iana",
        extensions: ["mmr"]
      },
      "image/vnd.fujixerox.edmics-rlc": {
        source: "iana",
        extensions: ["rlc"]
      },
      "image/vnd.globalgraphics.pgb": {
        source: "iana"
      },
      "image/vnd.microsoft.icon": {
        source: "iana",
        compressible: true,
        extensions: ["ico"]
      },
      "image/vnd.mix": {
        source: "iana"
      },
      "image/vnd.mozilla.apng": {
        source: "iana"
      },
      "image/vnd.ms-dds": {
        compressible: true,
        extensions: ["dds"]
      },
      "image/vnd.ms-modi": {
        source: "iana",
        extensions: ["mdi"]
      },
      "image/vnd.ms-photo": {
        source: "apache",
        extensions: ["wdp"]
      },
      "image/vnd.net-fpx": {
        source: "iana",
        extensions: ["npx"]
      },
      "image/vnd.pco.b16": {
        source: "iana",
        extensions: ["b16"]
      },
      "image/vnd.radiance": {
        source: "iana"
      },
      "image/vnd.sealed.png": {
        source: "iana"
      },
      "image/vnd.sealedmedia.softseal.gif": {
        source: "iana"
      },
      "image/vnd.sealedmedia.softseal.jpg": {
        source: "iana"
      },
      "image/vnd.svf": {
        source: "iana"
      },
      "image/vnd.tencent.tap": {
        source: "iana",
        extensions: ["tap"]
      },
      "image/vnd.valve.source.texture": {
        source: "iana",
        extensions: ["vtf"]
      },
      "image/vnd.wap.wbmp": {
        source: "iana",
        extensions: ["wbmp"]
      },
      "image/vnd.xiff": {
        source: "iana",
        extensions: ["xif"]
      },
      "image/vnd.zbrush.pcx": {
        source: "iana",
        extensions: ["pcx"]
      },
      "image/webp": {
        source: "apache",
        extensions: ["webp"]
      },
      "image/wmf": {
        source: "iana",
        extensions: ["wmf"]
      },
      "image/x-3ds": {
        source: "apache",
        extensions: ["3ds"]
      },
      "image/x-cmu-raster": {
        source: "apache",
        extensions: ["ras"]
      },
      "image/x-cmx": {
        source: "apache",
        extensions: ["cmx"]
      },
      "image/x-freehand": {
        source: "apache",
        extensions: ["fh", "fhc", "fh4", "fh5", "fh7"]
      },
      "image/x-icon": {
        source: "apache",
        compressible: true,
        extensions: ["ico"]
      },
      "image/x-jng": {
        source: "nginx",
        extensions: ["jng"]
      },
      "image/x-mrsid-image": {
        source: "apache",
        extensions: ["sid"]
      },
      "image/x-ms-bmp": {
        source: "nginx",
        compressible: true,
        extensions: ["bmp"]
      },
      "image/x-pcx": {
        source: "apache",
        extensions: ["pcx"]
      },
      "image/x-pict": {
        source: "apache",
        extensions: ["pic", "pct"]
      },
      "image/x-portable-anymap": {
        source: "apache",
        extensions: ["pnm"]
      },
      "image/x-portable-bitmap": {
        source: "apache",
        extensions: ["pbm"]
      },
      "image/x-portable-graymap": {
        source: "apache",
        extensions: ["pgm"]
      },
      "image/x-portable-pixmap": {
        source: "apache",
        extensions: ["ppm"]
      },
      "image/x-rgb": {
        source: "apache",
        extensions: ["rgb"]
      },
      "image/x-tga": {
        source: "apache",
        extensions: ["tga"]
      },
      "image/x-xbitmap": {
        source: "apache",
        extensions: ["xbm"]
      },
      "image/x-xcf": {
        compressible: false
      },
      "image/x-xpixmap": {
        source: "apache",
        extensions: ["xpm"]
      },
      "image/x-xwindowdump": {
        source: "apache",
        extensions: ["xwd"]
      },
      "message/cpim": {
        source: "iana"
      },
      "message/delivery-status": {
        source: "iana"
      },
      "message/disposition-notification": {
        source: "iana",
        extensions: [
          "disposition-notification"
        ]
      },
      "message/external-body": {
        source: "iana"
      },
      "message/feedback-report": {
        source: "iana"
      },
      "message/global": {
        source: "iana",
        extensions: ["u8msg"]
      },
      "message/global-delivery-status": {
        source: "iana",
        extensions: ["u8dsn"]
      },
      "message/global-disposition-notification": {
        source: "iana",
        extensions: ["u8mdn"]
      },
      "message/global-headers": {
        source: "iana",
        extensions: ["u8hdr"]
      },
      "message/http": {
        source: "iana",
        compressible: false
      },
      "message/imdn+xml": {
        source: "iana",
        compressible: true
      },
      "message/news": {
        source: "iana"
      },
      "message/partial": {
        source: "iana",
        compressible: false
      },
      "message/rfc822": {
        source: "iana",
        compressible: true,
        extensions: ["eml", "mime"]
      },
      "message/s-http": {
        source: "iana"
      },
      "message/sip": {
        source: "iana"
      },
      "message/sipfrag": {
        source: "iana"
      },
      "message/tracking-status": {
        source: "iana"
      },
      "message/vnd.si.simp": {
        source: "iana"
      },
      "message/vnd.wfa.wsc": {
        source: "iana",
        extensions: ["wsc"]
      },
      "model/3mf": {
        source: "iana",
        extensions: ["3mf"]
      },
      "model/e57": {
        source: "iana"
      },
      "model/gltf+json": {
        source: "iana",
        compressible: true,
        extensions: ["gltf"]
      },
      "model/gltf-binary": {
        source: "iana",
        compressible: true,
        extensions: ["glb"]
      },
      "model/iges": {
        source: "iana",
        compressible: false,
        extensions: ["igs", "iges"]
      },
      "model/mesh": {
        source: "iana",
        compressible: false,
        extensions: ["msh", "mesh", "silo"]
      },
      "model/mtl": {
        source: "iana",
        extensions: ["mtl"]
      },
      "model/obj": {
        source: "iana",
        extensions: ["obj"]
      },
      "model/step": {
        source: "iana"
      },
      "model/step+xml": {
        source: "iana",
        compressible: true,
        extensions: ["stpx"]
      },
      "model/step+zip": {
        source: "iana",
        compressible: false,
        extensions: ["stpz"]
      },
      "model/step-xml+zip": {
        source: "iana",
        compressible: false,
        extensions: ["stpxz"]
      },
      "model/stl": {
        source: "iana",
        extensions: ["stl"]
      },
      "model/vnd.collada+xml": {
        source: "iana",
        compressible: true,
        extensions: ["dae"]
      },
      "model/vnd.dwf": {
        source: "iana",
        extensions: ["dwf"]
      },
      "model/vnd.flatland.3dml": {
        source: "iana"
      },
      "model/vnd.gdl": {
        source: "iana",
        extensions: ["gdl"]
      },
      "model/vnd.gs-gdl": {
        source: "apache"
      },
      "model/vnd.gs.gdl": {
        source: "iana"
      },
      "model/vnd.gtw": {
        source: "iana",
        extensions: ["gtw"]
      },
      "model/vnd.moml+xml": {
        source: "iana",
        compressible: true
      },
      "model/vnd.mts": {
        source: "iana",
        extensions: ["mts"]
      },
      "model/vnd.opengex": {
        source: "iana",
        extensions: ["ogex"]
      },
      "model/vnd.parasolid.transmit.binary": {
        source: "iana",
        extensions: ["x_b"]
      },
      "model/vnd.parasolid.transmit.text": {
        source: "iana",
        extensions: ["x_t"]
      },
      "model/vnd.pytha.pyox": {
        source: "iana"
      },
      "model/vnd.rosette.annotated-data-model": {
        source: "iana"
      },
      "model/vnd.sap.vds": {
        source: "iana",
        extensions: ["vds"]
      },
      "model/vnd.usdz+zip": {
        source: "iana",
        compressible: false,
        extensions: ["usdz"]
      },
      "model/vnd.valve.source.compiled-map": {
        source: "iana",
        extensions: ["bsp"]
      },
      "model/vnd.vtu": {
        source: "iana",
        extensions: ["vtu"]
      },
      "model/vrml": {
        source: "iana",
        compressible: false,
        extensions: ["wrl", "vrml"]
      },
      "model/x3d+binary": {
        source: "apache",
        compressible: false,
        extensions: ["x3db", "x3dbz"]
      },
      "model/x3d+fastinfoset": {
        source: "iana",
        extensions: ["x3db"]
      },
      "model/x3d+vrml": {
        source: "apache",
        compressible: false,
        extensions: ["x3dv", "x3dvz"]
      },
      "model/x3d+xml": {
        source: "iana",
        compressible: true,
        extensions: ["x3d", "x3dz"]
      },
      "model/x3d-vrml": {
        source: "iana",
        extensions: ["x3dv"]
      },
      "multipart/alternative": {
        source: "iana",
        compressible: false
      },
      "multipart/appledouble": {
        source: "iana"
      },
      "multipart/byteranges": {
        source: "iana"
      },
      "multipart/digest": {
        source: "iana"
      },
      "multipart/encrypted": {
        source: "iana",
        compressible: false
      },
      "multipart/form-data": {
        source: "iana",
        compressible: false
      },
      "multipart/header-set": {
        source: "iana"
      },
      "multipart/mixed": {
        source: "iana"
      },
      "multipart/multilingual": {
        source: "iana"
      },
      "multipart/parallel": {
        source: "iana"
      },
      "multipart/related": {
        source: "iana",
        compressible: false
      },
      "multipart/report": {
        source: "iana"
      },
      "multipart/signed": {
        source: "iana",
        compressible: false
      },
      "multipart/vnd.bint.med-plus": {
        source: "iana"
      },
      "multipart/voice-message": {
        source: "iana"
      },
      "multipart/x-mixed-replace": {
        source: "iana"
      },
      "text/1d-interleaved-parityfec": {
        source: "iana"
      },
      "text/cache-manifest": {
        source: "iana",
        compressible: true,
        extensions: ["appcache", "manifest"]
      },
      "text/calendar": {
        source: "iana",
        extensions: ["ics", "ifb"]
      },
      "text/calender": {
        compressible: true
      },
      "text/cmd": {
        compressible: true
      },
      "text/coffeescript": {
        extensions: ["coffee", "litcoffee"]
      },
      "text/cql": {
        source: "iana"
      },
      "text/cql-expression": {
        source: "iana"
      },
      "text/cql-identifier": {
        source: "iana"
      },
      "text/css": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["css"]
      },
      "text/csv": {
        source: "iana",
        compressible: true,
        extensions: ["csv"]
      },
      "text/csv-schema": {
        source: "iana"
      },
      "text/directory": {
        source: "iana"
      },
      "text/dns": {
        source: "iana"
      },
      "text/ecmascript": {
        source: "iana"
      },
      "text/encaprtp": {
        source: "iana"
      },
      "text/enriched": {
        source: "iana"
      },
      "text/fhirpath": {
        source: "iana"
      },
      "text/flexfec": {
        source: "iana"
      },
      "text/fwdred": {
        source: "iana"
      },
      "text/gff3": {
        source: "iana"
      },
      "text/grammar-ref-list": {
        source: "iana"
      },
      "text/html": {
        source: "iana",
        compressible: true,
        extensions: ["html", "htm", "shtml"]
      },
      "text/jade": {
        extensions: ["jade"]
      },
      "text/javascript": {
        source: "iana",
        compressible: true
      },
      "text/jcr-cnd": {
        source: "iana"
      },
      "text/jsx": {
        compressible: true,
        extensions: ["jsx"]
      },
      "text/less": {
        compressible: true,
        extensions: ["less"]
      },
      "text/markdown": {
        source: "iana",
        compressible: true,
        extensions: ["markdown", "md"]
      },
      "text/mathml": {
        source: "nginx",
        extensions: ["mml"]
      },
      "text/mdx": {
        compressible: true,
        extensions: ["mdx"]
      },
      "text/mizar": {
        source: "iana"
      },
      "text/n3": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["n3"]
      },
      "text/parameters": {
        source: "iana",
        charset: "UTF-8"
      },
      "text/parityfec": {
        source: "iana"
      },
      "text/plain": {
        source: "iana",
        compressible: true,
        extensions: ["txt", "text", "conf", "def", "list", "log", "in", "ini"]
      },
      "text/provenance-notation": {
        source: "iana",
        charset: "UTF-8"
      },
      "text/prs.fallenstein.rst": {
        source: "iana"
      },
      "text/prs.lines.tag": {
        source: "iana",
        extensions: ["dsc"]
      },
      "text/prs.prop.logic": {
        source: "iana"
      },
      "text/raptorfec": {
        source: "iana"
      },
      "text/red": {
        source: "iana"
      },
      "text/rfc822-headers": {
        source: "iana"
      },
      "text/richtext": {
        source: "iana",
        compressible: true,
        extensions: ["rtx"]
      },
      "text/rtf": {
        source: "iana",
        compressible: true,
        extensions: ["rtf"]
      },
      "text/rtp-enc-aescm128": {
        source: "iana"
      },
      "text/rtploopback": {
        source: "iana"
      },
      "text/rtx": {
        source: "iana"
      },
      "text/sgml": {
        source: "iana",
        extensions: ["sgml", "sgm"]
      },
      "text/shaclc": {
        source: "iana"
      },
      "text/shex": {
        source: "iana",
        extensions: ["shex"]
      },
      "text/slim": {
        extensions: ["slim", "slm"]
      },
      "text/spdx": {
        source: "iana",
        extensions: ["spdx"]
      },
      "text/strings": {
        source: "iana"
      },
      "text/stylus": {
        extensions: ["stylus", "styl"]
      },
      "text/t140": {
        source: "iana"
      },
      "text/tab-separated-values": {
        source: "iana",
        compressible: true,
        extensions: ["tsv"]
      },
      "text/troff": {
        source: "iana",
        extensions: ["t", "tr", "roff", "man", "me", "ms"]
      },
      "text/turtle": {
        source: "iana",
        charset: "UTF-8",
        extensions: ["ttl"]
      },
      "text/ulpfec": {
        source: "iana"
      },
      "text/uri-list": {
        source: "iana",
        compressible: true,
        extensions: ["uri", "uris", "urls"]
      },
      "text/vcard": {
        source: "iana",
        compressible: true,
        extensions: ["vcard"]
      },
      "text/vnd.a": {
        source: "iana"
      },
      "text/vnd.abc": {
        source: "iana"
      },
      "text/vnd.ascii-art": {
        source: "iana"
      },
      "text/vnd.curl": {
        source: "iana",
        extensions: ["curl"]
      },
      "text/vnd.curl.dcurl": {
        source: "apache",
        extensions: ["dcurl"]
      },
      "text/vnd.curl.mcurl": {
        source: "apache",
        extensions: ["mcurl"]
      },
      "text/vnd.curl.scurl": {
        source: "apache",
        extensions: ["scurl"]
      },
      "text/vnd.debian.copyright": {
        source: "iana",
        charset: "UTF-8"
      },
      "text/vnd.dmclientscript": {
        source: "iana"
      },
      "text/vnd.dvb.subtitle": {
        source: "iana",
        extensions: ["sub"]
      },
      "text/vnd.esmertec.theme-descriptor": {
        source: "iana",
        charset: "UTF-8"
      },
      "text/vnd.familysearch.gedcom": {
        source: "iana",
        extensions: ["ged"]
      },
      "text/vnd.ficlab.flt": {
        source: "iana"
      },
      "text/vnd.fly": {
        source: "iana",
        extensions: ["fly"]
      },
      "text/vnd.fmi.flexstor": {
        source: "iana",
        extensions: ["flx"]
      },
      "text/vnd.gml": {
        source: "iana"
      },
      "text/vnd.graphviz": {
        source: "iana",
        extensions: ["gv"]
      },
      "text/vnd.hans": {
        source: "iana"
      },
      "text/vnd.hgl": {
        source: "iana"
      },
      "text/vnd.in3d.3dml": {
        source: "iana",
        extensions: ["3dml"]
      },
      "text/vnd.in3d.spot": {
        source: "iana",
        extensions: ["spot"]
      },
      "text/vnd.iptc.newsml": {
        source: "iana"
      },
      "text/vnd.iptc.nitf": {
        source: "iana"
      },
      "text/vnd.latex-z": {
        source: "iana"
      },
      "text/vnd.motorola.reflex": {
        source: "iana"
      },
      "text/vnd.ms-mediapackage": {
        source: "iana"
      },
      "text/vnd.net2phone.commcenter.command": {
        source: "iana"
      },
      "text/vnd.radisys.msml-basic-layout": {
        source: "iana"
      },
      "text/vnd.senx.warpscript": {
        source: "iana"
      },
      "text/vnd.si.uricatalogue": {
        source: "iana"
      },
      "text/vnd.sosi": {
        source: "iana"
      },
      "text/vnd.sun.j2me.app-descriptor": {
        source: "iana",
        charset: "UTF-8",
        extensions: ["jad"]
      },
      "text/vnd.trolltech.linguist": {
        source: "iana",
        charset: "UTF-8"
      },
      "text/vnd.wap.si": {
        source: "iana"
      },
      "text/vnd.wap.sl": {
        source: "iana"
      },
      "text/vnd.wap.wml": {
        source: "iana",
        extensions: ["wml"]
      },
      "text/vnd.wap.wmlscript": {
        source: "iana",
        extensions: ["wmls"]
      },
      "text/vtt": {
        source: "iana",
        charset: "UTF-8",
        compressible: true,
        extensions: ["vtt"]
      },
      "text/x-asm": {
        source: "apache",
        extensions: ["s", "asm"]
      },
      "text/x-c": {
        source: "apache",
        extensions: ["c", "cc", "cxx", "cpp", "h", "hh", "dic"]
      },
      "text/x-component": {
        source: "nginx",
        extensions: ["htc"]
      },
      "text/x-fortran": {
        source: "apache",
        extensions: ["f", "for", "f77", "f90"]
      },
      "text/x-gwt-rpc": {
        compressible: true
      },
      "text/x-handlebars-template": {
        extensions: ["hbs"]
      },
      "text/x-java-source": {
        source: "apache",
        extensions: ["java"]
      },
      "text/x-jquery-tmpl": {
        compressible: true
      },
      "text/x-lua": {
        extensions: ["lua"]
      },
      "text/x-markdown": {
        compressible: true,
        extensions: ["mkd"]
      },
      "text/x-nfo": {
        source: "apache",
        extensions: ["nfo"]
      },
      "text/x-opml": {
        source: "apache",
        extensions: ["opml"]
      },
      "text/x-org": {
        compressible: true,
        extensions: ["org"]
      },
      "text/x-pascal": {
        source: "apache",
        extensions: ["p", "pas"]
      },
      "text/x-processing": {
        compressible: true,
        extensions: ["pde"]
      },
      "text/x-sass": {
        extensions: ["sass"]
      },
      "text/x-scss": {
        extensions: ["scss"]
      },
      "text/x-setext": {
        source: "apache",
        extensions: ["etx"]
      },
      "text/x-sfv": {
        source: "apache",
        extensions: ["sfv"]
      },
      "text/x-suse-ymp": {
        compressible: true,
        extensions: ["ymp"]
      },
      "text/x-uuencode": {
        source: "apache",
        extensions: ["uu"]
      },
      "text/x-vcalendar": {
        source: "apache",
        extensions: ["vcs"]
      },
      "text/x-vcard": {
        source: "apache",
        extensions: ["vcf"]
      },
      "text/xml": {
        source: "iana",
        compressible: true,
        extensions: ["xml"]
      },
      "text/xml-external-parsed-entity": {
        source: "iana"
      },
      "text/yaml": {
        compressible: true,
        extensions: ["yaml", "yml"]
      },
      "video/1d-interleaved-parityfec": {
        source: "iana"
      },
      "video/3gpp": {
        source: "iana",
        extensions: ["3gp", "3gpp"]
      },
      "video/3gpp-tt": {
        source: "iana"
      },
      "video/3gpp2": {
        source: "iana",
        extensions: ["3g2"]
      },
      "video/av1": {
        source: "iana"
      },
      "video/bmpeg": {
        source: "iana"
      },
      "video/bt656": {
        source: "iana"
      },
      "video/celb": {
        source: "iana"
      },
      "video/dv": {
        source: "iana"
      },
      "video/encaprtp": {
        source: "iana"
      },
      "video/ffv1": {
        source: "iana"
      },
      "video/flexfec": {
        source: "iana"
      },
      "video/h261": {
        source: "iana",
        extensions: ["h261"]
      },
      "video/h263": {
        source: "iana",
        extensions: ["h263"]
      },
      "video/h263-1998": {
        source: "iana"
      },
      "video/h263-2000": {
        source: "iana"
      },
      "video/h264": {
        source: "iana",
        extensions: ["h264"]
      },
      "video/h264-rcdo": {
        source: "iana"
      },
      "video/h264-svc": {
        source: "iana"
      },
      "video/h265": {
        source: "iana"
      },
      "video/iso.segment": {
        source: "iana",
        extensions: ["m4s"]
      },
      "video/jpeg": {
        source: "iana",
        extensions: ["jpgv"]
      },
      "video/jpeg2000": {
        source: "iana"
      },
      "video/jpm": {
        source: "apache",
        extensions: ["jpm", "jpgm"]
      },
      "video/jxsv": {
        source: "iana"
      },
      "video/mj2": {
        source: "iana",
        extensions: ["mj2", "mjp2"]
      },
      "video/mp1s": {
        source: "iana"
      },
      "video/mp2p": {
        source: "iana"
      },
      "video/mp2t": {
        source: "iana",
        extensions: ["ts"]
      },
      "video/mp4": {
        source: "iana",
        compressible: false,
        extensions: ["mp4", "mp4v", "mpg4"]
      },
      "video/mp4v-es": {
        source: "iana"
      },
      "video/mpeg": {
        source: "iana",
        compressible: false,
        extensions: ["mpeg", "mpg", "mpe", "m1v", "m2v"]
      },
      "video/mpeg4-generic": {
        source: "iana"
      },
      "video/mpv": {
        source: "iana"
      },
      "video/nv": {
        source: "iana"
      },
      "video/ogg": {
        source: "iana",
        compressible: false,
        extensions: ["ogv"]
      },
      "video/parityfec": {
        source: "iana"
      },
      "video/pointer": {
        source: "iana"
      },
      "video/quicktime": {
        source: "iana",
        compressible: false,
        extensions: ["qt", "mov"]
      },
      "video/raptorfec": {
        source: "iana"
      },
      "video/raw": {
        source: "iana"
      },
      "video/rtp-enc-aescm128": {
        source: "iana"
      },
      "video/rtploopback": {
        source: "iana"
      },
      "video/rtx": {
        source: "iana"
      },
      "video/scip": {
        source: "iana"
      },
      "video/smpte291": {
        source: "iana"
      },
      "video/smpte292m": {
        source: "iana"
      },
      "video/ulpfec": {
        source: "iana"
      },
      "video/vc1": {
        source: "iana"
      },
      "video/vc2": {
        source: "iana"
      },
      "video/vnd.cctv": {
        source: "iana"
      },
      "video/vnd.dece.hd": {
        source: "iana",
        extensions: ["uvh", "uvvh"]
      },
      "video/vnd.dece.mobile": {
        source: "iana",
        extensions: ["uvm", "uvvm"]
      },
      "video/vnd.dece.mp4": {
        source: "iana"
      },
      "video/vnd.dece.pd": {
        source: "iana",
        extensions: ["uvp", "uvvp"]
      },
      "video/vnd.dece.sd": {
        source: "iana",
        extensions: ["uvs", "uvvs"]
      },
      "video/vnd.dece.video": {
        source: "iana",
        extensions: ["uvv", "uvvv"]
      },
      "video/vnd.directv.mpeg": {
        source: "iana"
      },
      "video/vnd.directv.mpeg-tts": {
        source: "iana"
      },
      "video/vnd.dlna.mpeg-tts": {
        source: "iana"
      },
      "video/vnd.dvb.file": {
        source: "iana",
        extensions: ["dvb"]
      },
      "video/vnd.fvt": {
        source: "iana",
        extensions: ["fvt"]
      },
      "video/vnd.hns.video": {
        source: "iana"
      },
      "video/vnd.iptvforum.1dparityfec-1010": {
        source: "iana"
      },
      "video/vnd.iptvforum.1dparityfec-2005": {
        source: "iana"
      },
      "video/vnd.iptvforum.2dparityfec-1010": {
        source: "iana"
      },
      "video/vnd.iptvforum.2dparityfec-2005": {
        source: "iana"
      },
      "video/vnd.iptvforum.ttsavc": {
        source: "iana"
      },
      "video/vnd.iptvforum.ttsmpeg2": {
        source: "iana"
      },
      "video/vnd.motorola.video": {
        source: "iana"
      },
      "video/vnd.motorola.videop": {
        source: "iana"
      },
      "video/vnd.mpegurl": {
        source: "iana",
        extensions: ["mxu", "m4u"]
      },
      "video/vnd.ms-playready.media.pyv": {
        source: "iana",
        extensions: ["pyv"]
      },
      "video/vnd.nokia.interleaved-multimedia": {
        source: "iana"
      },
      "video/vnd.nokia.mp4vr": {
        source: "iana"
      },
      "video/vnd.nokia.videovoip": {
        source: "iana"
      },
      "video/vnd.objectvideo": {
        source: "iana"
      },
      "video/vnd.radgamettools.bink": {
        source: "iana"
      },
      "video/vnd.radgamettools.smacker": {
        source: "iana"
      },
      "video/vnd.sealed.mpeg1": {
        source: "iana"
      },
      "video/vnd.sealed.mpeg4": {
        source: "iana"
      },
      "video/vnd.sealed.swf": {
        source: "iana"
      },
      "video/vnd.sealedmedia.softseal.mov": {
        source: "iana"
      },
      "video/vnd.uvvu.mp4": {
        source: "iana",
        extensions: ["uvu", "uvvu"]
      },
      "video/vnd.vivo": {
        source: "iana",
        extensions: ["viv"]
      },
      "video/vnd.youtube.yt": {
        source: "iana"
      },
      "video/vp8": {
        source: "iana"
      },
      "video/vp9": {
        source: "iana"
      },
      "video/webm": {
        source: "apache",
        compressible: false,
        extensions: ["webm"]
      },
      "video/x-f4v": {
        source: "apache",
        extensions: ["f4v"]
      },
      "video/x-fli": {
        source: "apache",
        extensions: ["fli"]
      },
      "video/x-flv": {
        source: "apache",
        compressible: false,
        extensions: ["flv"]
      },
      "video/x-m4v": {
        source: "apache",
        extensions: ["m4v"]
      },
      "video/x-matroska": {
        source: "apache",
        compressible: false,
        extensions: ["mkv", "mk3d", "mks"]
      },
      "video/x-mng": {
        source: "apache",
        extensions: ["mng"]
      },
      "video/x-ms-asf": {
        source: "apache",
        extensions: ["asf", "asx"]
      },
      "video/x-ms-vob": {
        source: "apache",
        extensions: ["vob"]
      },
      "video/x-ms-wm": {
        source: "apache",
        extensions: ["wm"]
      },
      "video/x-ms-wmv": {
        source: "apache",
        compressible: false,
        extensions: ["wmv"]
      },
      "video/x-ms-wmx": {
        source: "apache",
        extensions: ["wmx"]
      },
      "video/x-ms-wvx": {
        source: "apache",
        extensions: ["wvx"]
      },
      "video/x-msvideo": {
        source: "apache",
        extensions: ["avi"]
      },
      "video/x-sgi-movie": {
        source: "apache",
        extensions: ["movie"]
      },
      "video/x-smv": {
        source: "apache",
        extensions: ["smv"]
      },
      "x-conference/x-cooltalk": {
        source: "apache",
        extensions: ["ice"]
      },
      "x-shader/x-fragment": {
        compressible: true
      },
      "x-shader/x-vertex": {
        compressible: true
      }
    };
  }
});

// netlify/functions/node_modules/mime-db/index.js
var require_mime_db = __commonJS({
  "netlify/functions/node_modules/mime-db/index.js"(exports2, module2) {
    module2.exports = require_db();
  }
});

// netlify/functions/node_modules/mime-types/index.js
var require_mime_types = __commonJS({
  "netlify/functions/node_modules/mime-types/index.js"(exports2) {
    "use strict";
    var db = require_mime_db();
    var extname = require("path").extname;
    var EXTRACT_TYPE_REGEXP = /^\s*([^;\s]*)(?:;|\s|$)/;
    var TEXT_TYPE_REGEXP = /^text\//i;
    exports2.charset = charset;
    exports2.charsets = { lookup: charset };
    exports2.contentType = contentType;
    exports2.extension = extension;
    exports2.extensions = /* @__PURE__ */ Object.create(null);
    exports2.lookup = lookup;
    exports2.types = /* @__PURE__ */ Object.create(null);
    populateMaps(exports2.extensions, exports2.types);
    function charset(type) {
      if (!type || typeof type !== "string") {
        return false;
      }
      var match = EXTRACT_TYPE_REGEXP.exec(type);
      var mime = match && db[match[1].toLowerCase()];
      if (mime && mime.charset) {
        return mime.charset;
      }
      if (match && TEXT_TYPE_REGEXP.test(match[1])) {
        return "UTF-8";
      }
      return false;
    }
    function contentType(str) {
      if (!str || typeof str !== "string") {
        return false;
      }
      var mime = str.indexOf("/") === -1 ? exports2.lookup(str) : str;
      if (!mime) {
        return false;
      }
      if (mime.indexOf("charset") === -1) {
        var charset2 = exports2.charset(mime);
        if (charset2) mime += "; charset=" + charset2.toLowerCase();
      }
      return mime;
    }
    function extension(type) {
      if (!type || typeof type !== "string") {
        return false;
      }
      var match = EXTRACT_TYPE_REGEXP.exec(type);
      var exts = match && exports2.extensions[match[1].toLowerCase()];
      if (!exts || !exts.length) {
        return false;
      }
      return exts[0];
    }
    function lookup(path) {
      if (!path || typeof path !== "string") {
        return false;
      }
      var extension2 = extname("x." + path).toLowerCase().substr(1);
      if (!extension2) {
        return false;
      }
      return exports2.types[extension2] || false;
    }
    function populateMaps(extensions, types) {
      var preference = ["nginx", "apache", void 0, "iana"];
      Object.keys(db).forEach(function forEachMimeType(type) {
        var mime = db[type];
        var exts = mime.extensions;
        if (!exts || !exts.length) {
          return;
        }
        extensions[type] = exts;
        for (var i2 = 0; i2 < exts.length; i2++) {
          var extension2 = exts[i2];
          if (types[extension2]) {
            var from = preference.indexOf(db[types[extension2]].source);
            var to2 = preference.indexOf(mime.source);
            if (types[extension2] !== "application/octet-stream" && (from > to2 || from === to2 && types[extension2].substr(0, 12) === "application/")) {
              continue;
            }
          }
          types[extension2] = type;
        }
      });
    }
  }
});

// netlify/functions/node_modules/asynckit/lib/defer.js
var require_defer = __commonJS({
  "netlify/functions/node_modules/asynckit/lib/defer.js"(exports2, module2) {
    module2.exports = defer;
    function defer(fn2) {
      var nextTick = typeof setImmediate == "function" ? setImmediate : typeof process == "object" && typeof process.nextTick == "function" ? process.nextTick : null;
      if (nextTick) {
        nextTick(fn2);
      } else {
        setTimeout(fn2, 0);
      }
    }
  }
});

// netlify/functions/node_modules/asynckit/lib/async.js
var require_async = __commonJS({
  "netlify/functions/node_modules/asynckit/lib/async.js"(exports2, module2) {
    var defer = require_defer();
    module2.exports = async;
    function async(callback) {
      var isAsync = false;
      defer(function() {
        isAsync = true;
      });
      return function async_callback(err, result) {
        if (isAsync) {
          callback(err, result);
        } else {
          defer(function nextTick_callback() {
            callback(err, result);
          });
        }
      };
    }
  }
});

// netlify/functions/node_modules/asynckit/lib/abort.js
var require_abort = __commonJS({
  "netlify/functions/node_modules/asynckit/lib/abort.js"(exports2, module2) {
    module2.exports = abort;
    function abort(state) {
      Object.keys(state.jobs).forEach(clean.bind(state));
      state.jobs = {};
    }
    function clean(key) {
      if (typeof this.jobs[key] == "function") {
        this.jobs[key]();
      }
    }
  }
});

// netlify/functions/node_modules/asynckit/lib/iterate.js
var require_iterate = __commonJS({
  "netlify/functions/node_modules/asynckit/lib/iterate.js"(exports2, module2) {
    var async = require_async();
    var abort = require_abort();
    module2.exports = iterate;
    function iterate(list, iterator, state, callback) {
      var key = state["keyedList"] ? state["keyedList"][state.index] : state.index;
      state.jobs[key] = runJob(iterator, key, list[key], function(error, output) {
        if (!(key in state.jobs)) {
          return;
        }
        delete state.jobs[key];
        if (error) {
          abort(state);
        } else {
          state.results[key] = output;
        }
        callback(error, state.results);
      });
    }
    function runJob(iterator, key, item, callback) {
      var aborter;
      if (iterator.length == 2) {
        aborter = iterator(item, async(callback));
      } else {
        aborter = iterator(item, key, async(callback));
      }
      return aborter;
    }
  }
});

// netlify/functions/node_modules/asynckit/lib/state.js
var require_state = __commonJS({
  "netlify/functions/node_modules/asynckit/lib/state.js"(exports2, module2) {
    module2.exports = state;
    function state(list, sortMethod) {
      var isNamedList = !Array.isArray(list), initState = {
        index: 0,
        keyedList: isNamedList || sortMethod ? Object.keys(list) : null,
        jobs: {},
        results: isNamedList ? {} : [],
        size: isNamedList ? Object.keys(list).length : list.length
      };
      if (sortMethod) {
        initState.keyedList.sort(isNamedList ? sortMethod : function(a2, b2) {
          return sortMethod(list[a2], list[b2]);
        });
      }
      return initState;
    }
  }
});

// netlify/functions/node_modules/asynckit/lib/terminator.js
var require_terminator = __commonJS({
  "netlify/functions/node_modules/asynckit/lib/terminator.js"(exports2, module2) {
    var abort = require_abort();
    var async = require_async();
    module2.exports = terminator;
    function terminator(callback) {
      if (!Object.keys(this.jobs).length) {
        return;
      }
      this.index = this.size;
      abort(this);
      async(callback)(null, this.results);
    }
  }
});

// netlify/functions/node_modules/asynckit/parallel.js
var require_parallel = __commonJS({
  "netlify/functions/node_modules/asynckit/parallel.js"(exports2, module2) {
    var iterate = require_iterate();
    var initState = require_state();
    var terminator = require_terminator();
    module2.exports = parallel;
    function parallel(list, iterator, callback) {
      var state = initState(list);
      while (state.index < (state["keyedList"] || list).length) {
        iterate(list, iterator, state, function(error, result) {
          if (error) {
            callback(error, result);
            return;
          }
          if (Object.keys(state.jobs).length === 0) {
            callback(null, state.results);
            return;
          }
        });
        state.index++;
      }
      return terminator.bind(state, callback);
    }
  }
});

// netlify/functions/node_modules/asynckit/serialOrdered.js
var require_serialOrdered = __commonJS({
  "netlify/functions/node_modules/asynckit/serialOrdered.js"(exports2, module2) {
    var iterate = require_iterate();
    var initState = require_state();
    var terminator = require_terminator();
    module2.exports = serialOrdered;
    module2.exports.ascending = ascending;
    module2.exports.descending = descending;
    function serialOrdered(list, iterator, sortMethod, callback) {
      var state = initState(list, sortMethod);
      iterate(list, iterator, state, function iteratorHandler(error, result) {
        if (error) {
          callback(error, result);
          return;
        }
        state.index++;
        if (state.index < (state["keyedList"] || list).length) {
          iterate(list, iterator, state, iteratorHandler);
          return;
        }
        callback(null, state.results);
      });
      return terminator.bind(state, callback);
    }
    function ascending(a2, b2) {
      return a2 < b2 ? -1 : a2 > b2 ? 1 : 0;
    }
    function descending(a2, b2) {
      return -1 * ascending(a2, b2);
    }
  }
});

// netlify/functions/node_modules/asynckit/serial.js
var require_serial = __commonJS({
  "netlify/functions/node_modules/asynckit/serial.js"(exports2, module2) {
    var serialOrdered = require_serialOrdered();
    module2.exports = serial;
    function serial(list, iterator, callback) {
      return serialOrdered(list, iterator, null, callback);
    }
  }
});

// netlify/functions/node_modules/asynckit/index.js
var require_asynckit = __commonJS({
  "netlify/functions/node_modules/asynckit/index.js"(exports2, module2) {
    module2.exports = {
      parallel: require_parallel(),
      serial: require_serial(),
      serialOrdered: require_serialOrdered()
    };
  }
});

// netlify/functions/node_modules/es-object-atoms/index.js
var require_es_object_atoms = __commonJS({
  "netlify/functions/node_modules/es-object-atoms/index.js"(exports2, module2) {
    "use strict";
    module2.exports = Object;
  }
});

// netlify/functions/node_modules/es-errors/index.js
var require_es_errors = __commonJS({
  "netlify/functions/node_modules/es-errors/index.js"(exports2, module2) {
    "use strict";
    module2.exports = Error;
  }
});

// netlify/functions/node_modules/es-errors/eval.js
var require_eval = __commonJS({
  "netlify/functions/node_modules/es-errors/eval.js"(exports2, module2) {
    "use strict";
    module2.exports = EvalError;
  }
});

// netlify/functions/node_modules/es-errors/range.js
var require_range = __commonJS({
  "netlify/functions/node_modules/es-errors/range.js"(exports2, module2) {
    "use strict";
    module2.exports = RangeError;
  }
});

// netlify/functions/node_modules/es-errors/ref.js
var require_ref = __commonJS({
  "netlify/functions/node_modules/es-errors/ref.js"(exports2, module2) {
    "use strict";
    module2.exports = ReferenceError;
  }
});

// netlify/functions/node_modules/es-errors/syntax.js
var require_syntax = __commonJS({
  "netlify/functions/node_modules/es-errors/syntax.js"(exports2, module2) {
    "use strict";
    module2.exports = SyntaxError;
  }
});

// netlify/functions/node_modules/es-errors/type.js
var require_type = __commonJS({
  "netlify/functions/node_modules/es-errors/type.js"(exports2, module2) {
    "use strict";
    module2.exports = TypeError;
  }
});

// netlify/functions/node_modules/es-errors/uri.js
var require_uri = __commonJS({
  "netlify/functions/node_modules/es-errors/uri.js"(exports2, module2) {
    "use strict";
    module2.exports = URIError;
  }
});

// netlify/functions/node_modules/math-intrinsics/abs.js
var require_abs = __commonJS({
  "netlify/functions/node_modules/math-intrinsics/abs.js"(exports2, module2) {
    "use strict";
    module2.exports = Math.abs;
  }
});

// netlify/functions/node_modules/math-intrinsics/floor.js
var require_floor = __commonJS({
  "netlify/functions/node_modules/math-intrinsics/floor.js"(exports2, module2) {
    "use strict";
    module2.exports = Math.floor;
  }
});

// netlify/functions/node_modules/math-intrinsics/max.js
var require_max = __commonJS({
  "netlify/functions/node_modules/math-intrinsics/max.js"(exports2, module2) {
    "use strict";
    module2.exports = Math.max;
  }
});

// netlify/functions/node_modules/math-intrinsics/min.js
var require_min = __commonJS({
  "netlify/functions/node_modules/math-intrinsics/min.js"(exports2, module2) {
    "use strict";
    module2.exports = Math.min;
  }
});

// netlify/functions/node_modules/math-intrinsics/pow.js
var require_pow = __commonJS({
  "netlify/functions/node_modules/math-intrinsics/pow.js"(exports2, module2) {
    "use strict";
    module2.exports = Math.pow;
  }
});

// netlify/functions/node_modules/math-intrinsics/round.js
var require_round = __commonJS({
  "netlify/functions/node_modules/math-intrinsics/round.js"(exports2, module2) {
    "use strict";
    module2.exports = Math.round;
  }
});

// netlify/functions/node_modules/math-intrinsics/isNaN.js
var require_isNaN = __commonJS({
  "netlify/functions/node_modules/math-intrinsics/isNaN.js"(exports2, module2) {
    "use strict";
    module2.exports = Number.isNaN || function isNaN2(a2) {
      return a2 !== a2;
    };
  }
});

// netlify/functions/node_modules/math-intrinsics/sign.js
var require_sign = __commonJS({
  "netlify/functions/node_modules/math-intrinsics/sign.js"(exports2, module2) {
    "use strict";
    var $isNaN = require_isNaN();
    module2.exports = function sign(number) {
      if ($isNaN(number) || number === 0) {
        return number;
      }
      return number < 0 ? -1 : 1;
    };
  }
});

// netlify/functions/node_modules/gopd/gOPD.js
var require_gOPD = __commonJS({
  "netlify/functions/node_modules/gopd/gOPD.js"(exports2, module2) {
    "use strict";
    module2.exports = Object.getOwnPropertyDescriptor;
  }
});

// netlify/functions/node_modules/gopd/index.js
var require_gopd = __commonJS({
  "netlify/functions/node_modules/gopd/index.js"(exports2, module2) {
    "use strict";
    var $gOPD = require_gOPD();
    if ($gOPD) {
      try {
        $gOPD([], "length");
      } catch (e5) {
        $gOPD = null;
      }
    }
    module2.exports = $gOPD;
  }
});

// netlify/functions/node_modules/es-define-property/index.js
var require_es_define_property = __commonJS({
  "netlify/functions/node_modules/es-define-property/index.js"(exports2, module2) {
    "use strict";
    var $defineProperty = Object.defineProperty || false;
    if ($defineProperty) {
      try {
        $defineProperty({}, "a", { value: 1 });
      } catch (e5) {
        $defineProperty = false;
      }
    }
    module2.exports = $defineProperty;
  }
});

// netlify/functions/node_modules/has-symbols/shams.js
var require_shams = __commonJS({
  "netlify/functions/node_modules/has-symbols/shams.js"(exports2, module2) {
    "use strict";
    module2.exports = function hasSymbols() {
      if (typeof Symbol !== "function" || typeof Object.getOwnPropertySymbols !== "function") {
        return false;
      }
      if (typeof Symbol.iterator === "symbol") {
        return true;
      }
      var obj = {};
      var sym = Symbol("test");
      var symObj = Object(sym);
      if (typeof sym === "string") {
        return false;
      }
      if (Object.prototype.toString.call(sym) !== "[object Symbol]") {
        return false;
      }
      if (Object.prototype.toString.call(symObj) !== "[object Symbol]") {
        return false;
      }
      var symVal = 42;
      obj[sym] = symVal;
      for (var _2 in obj) {
        return false;
      }
      if (typeof Object.keys === "function" && Object.keys(obj).length !== 0) {
        return false;
      }
      if (typeof Object.getOwnPropertyNames === "function" && Object.getOwnPropertyNames(obj).length !== 0) {
        return false;
      }
      var syms = Object.getOwnPropertySymbols(obj);
      if (syms.length !== 1 || syms[0] !== sym) {
        return false;
      }
      if (!Object.prototype.propertyIsEnumerable.call(obj, sym)) {
        return false;
      }
      if (typeof Object.getOwnPropertyDescriptor === "function") {
        var descriptor = (
          /** @type {PropertyDescriptor} */
          Object.getOwnPropertyDescriptor(obj, sym)
        );
        if (descriptor.value !== symVal || descriptor.enumerable !== true) {
          return false;
        }
      }
      return true;
    };
  }
});

// netlify/functions/node_modules/has-symbols/index.js
var require_has_symbols = __commonJS({
  "netlify/functions/node_modules/has-symbols/index.js"(exports2, module2) {
    "use strict";
    var origSymbol = typeof Symbol !== "undefined" && Symbol;
    var hasSymbolSham = require_shams();
    module2.exports = function hasNativeSymbols() {
      if (typeof origSymbol !== "function") {
        return false;
      }
      if (typeof Symbol !== "function") {
        return false;
      }
      if (typeof origSymbol("foo") !== "symbol") {
        return false;
      }
      if (typeof Symbol("bar") !== "symbol") {
        return false;
      }
      return hasSymbolSham();
    };
  }
});

// netlify/functions/node_modules/get-proto/Reflect.getPrototypeOf.js
var require_Reflect_getPrototypeOf = __commonJS({
  "netlify/functions/node_modules/get-proto/Reflect.getPrototypeOf.js"(exports2, module2) {
    "use strict";
    module2.exports = typeof Reflect !== "undefined" && Reflect.getPrototypeOf || null;
  }
});

// netlify/functions/node_modules/get-proto/Object.getPrototypeOf.js
var require_Object_getPrototypeOf = __commonJS({
  "netlify/functions/node_modules/get-proto/Object.getPrototypeOf.js"(exports2, module2) {
    "use strict";
    var $Object = require_es_object_atoms();
    module2.exports = $Object.getPrototypeOf || null;
  }
});

// netlify/functions/node_modules/function-bind/implementation.js
var require_implementation = __commonJS({
  "netlify/functions/node_modules/function-bind/implementation.js"(exports2, module2) {
    "use strict";
    var ERROR_MESSAGE = "Function.prototype.bind called on incompatible ";
    var toStr = Object.prototype.toString;
    var max = Math.max;
    var funcType = "[object Function]";
    var concatty = function concatty2(a2, b2) {
      var arr = [];
      for (var i2 = 0; i2 < a2.length; i2 += 1) {
        arr[i2] = a2[i2];
      }
      for (var j2 = 0; j2 < b2.length; j2 += 1) {
        arr[j2 + a2.length] = b2[j2];
      }
      return arr;
    };
    var slicy = function slicy2(arrLike, offset) {
      var arr = [];
      for (var i2 = offset || 0, j2 = 0; i2 < arrLike.length; i2 += 1, j2 += 1) {
        arr[j2] = arrLike[i2];
      }
      return arr;
    };
    var joiny = function(arr, joiner) {
      var str = "";
      for (var i2 = 0; i2 < arr.length; i2 += 1) {
        str += arr[i2];
        if (i2 + 1 < arr.length) {
          str += joiner;
        }
      }
      return str;
    };
    module2.exports = function bind(that) {
      var target = this;
      if (typeof target !== "function" || toStr.apply(target) !== funcType) {
        throw new TypeError(ERROR_MESSAGE + target);
      }
      var args = slicy(arguments, 1);
      var bound;
      var binder = function() {
        if (this instanceof bound) {
          var result = target.apply(
            this,
            concatty(args, arguments)
          );
          if (Object(result) === result) {
            return result;
          }
          return this;
        }
        return target.apply(
          that,
          concatty(args, arguments)
        );
      };
      var boundLength = max(0, target.length - args.length);
      var boundArgs = [];
      for (var i2 = 0; i2 < boundLength; i2++) {
        boundArgs[i2] = "$" + i2;
      }
      bound = Function("binder", "return function (" + joiny(boundArgs, ",") + "){ return binder.apply(this,arguments); }")(binder);
      if (target.prototype) {
        var Empty = function Empty2() {
        };
        Empty.prototype = target.prototype;
        bound.prototype = new Empty();
        Empty.prototype = null;
      }
      return bound;
    };
  }
});

// netlify/functions/node_modules/function-bind/index.js
var require_function_bind = __commonJS({
  "netlify/functions/node_modules/function-bind/index.js"(exports2, module2) {
    "use strict";
    var implementation = require_implementation();
    module2.exports = Function.prototype.bind || implementation;
  }
});

// netlify/functions/node_modules/call-bind-apply-helpers/functionCall.js
var require_functionCall = __commonJS({
  "netlify/functions/node_modules/call-bind-apply-helpers/functionCall.js"(exports2, module2) {
    "use strict";
    module2.exports = Function.prototype.call;
  }
});

// netlify/functions/node_modules/call-bind-apply-helpers/functionApply.js
var require_functionApply = __commonJS({
  "netlify/functions/node_modules/call-bind-apply-helpers/functionApply.js"(exports2, module2) {
    "use strict";
    module2.exports = Function.prototype.apply;
  }
});

// netlify/functions/node_modules/call-bind-apply-helpers/reflectApply.js
var require_reflectApply = __commonJS({
  "netlify/functions/node_modules/call-bind-apply-helpers/reflectApply.js"(exports2, module2) {
    "use strict";
    module2.exports = typeof Reflect !== "undefined" && Reflect && Reflect.apply;
  }
});

// netlify/functions/node_modules/call-bind-apply-helpers/actualApply.js
var require_actualApply = __commonJS({
  "netlify/functions/node_modules/call-bind-apply-helpers/actualApply.js"(exports2, module2) {
    "use strict";
    var bind = require_function_bind();
    var $apply = require_functionApply();
    var $call = require_functionCall();
    var $reflectApply = require_reflectApply();
    module2.exports = $reflectApply || bind.call($call, $apply);
  }
});

// netlify/functions/node_modules/call-bind-apply-helpers/index.js
var require_call_bind_apply_helpers = __commonJS({
  "netlify/functions/node_modules/call-bind-apply-helpers/index.js"(exports2, module2) {
    "use strict";
    var bind = require_function_bind();
    var $TypeError = require_type();
    var $call = require_functionCall();
    var $actualApply = require_actualApply();
    module2.exports = function callBindBasic(args) {
      if (args.length < 1 || typeof args[0] !== "function") {
        throw new $TypeError("a function is required");
      }
      return $actualApply(bind, $call, args);
    };
  }
});

// netlify/functions/node_modules/dunder-proto/get.js
var require_get = __commonJS({
  "netlify/functions/node_modules/dunder-proto/get.js"(exports2, module2) {
    "use strict";
    var callBind = require_call_bind_apply_helpers();
    var gOPD = require_gopd();
    var hasProtoAccessor;
    try {
      hasProtoAccessor = /** @type {{ __proto__?: typeof Array.prototype }} */
      [].__proto__ === Array.prototype;
    } catch (e5) {
      if (!e5 || typeof e5 !== "object" || !("code" in e5) || e5.code !== "ERR_PROTO_ACCESS") {
        throw e5;
      }
    }
    var desc = !!hasProtoAccessor && gOPD && gOPD(
      Object.prototype,
      /** @type {keyof typeof Object.prototype} */
      "__proto__"
    );
    var $Object = Object;
    var $getPrototypeOf = $Object.getPrototypeOf;
    module2.exports = desc && typeof desc.get === "function" ? callBind([desc.get]) : typeof $getPrototypeOf === "function" ? (
      /** @type {import('./get')} */
      function getDunder(value) {
        return $getPrototypeOf(value == null ? value : $Object(value));
      }
    ) : false;
  }
});

// netlify/functions/node_modules/get-proto/index.js
var require_get_proto = __commonJS({
  "netlify/functions/node_modules/get-proto/index.js"(exports2, module2) {
    "use strict";
    var reflectGetProto = require_Reflect_getPrototypeOf();
    var originalGetProto = require_Object_getPrototypeOf();
    var getDunderProto = require_get();
    module2.exports = reflectGetProto ? function getProto(O2) {
      return reflectGetProto(O2);
    } : originalGetProto ? function getProto(O2) {
      if (!O2 || typeof O2 !== "object" && typeof O2 !== "function") {
        throw new TypeError("getProto: not an object");
      }
      return originalGetProto(O2);
    } : getDunderProto ? function getProto(O2) {
      return getDunderProto(O2);
    } : null;
  }
});

// netlify/functions/node_modules/hasown/index.js
var require_hasown = __commonJS({
  "netlify/functions/node_modules/hasown/index.js"(exports2, module2) {
    "use strict";
    var call = Function.prototype.call;
    var $hasOwn = Object.prototype.hasOwnProperty;
    var bind = require_function_bind();
    module2.exports = bind.call(call, $hasOwn);
  }
});

// netlify/functions/node_modules/get-intrinsic/index.js
var require_get_intrinsic = __commonJS({
  "netlify/functions/node_modules/get-intrinsic/index.js"(exports2, module2) {
    "use strict";
    var undefined2;
    var $Object = require_es_object_atoms();
    var $Error = require_es_errors();
    var $EvalError = require_eval();
    var $RangeError = require_range();
    var $ReferenceError = require_ref();
    var $SyntaxError = require_syntax();
    var $TypeError = require_type();
    var $URIError = require_uri();
    var abs = require_abs();
    var floor = require_floor();
    var max = require_max();
    var min = require_min();
    var pow = require_pow();
    var round = require_round();
    var sign = require_sign();
    var $Function = Function;
    var getEvalledConstructor = function(expressionSyntax) {
      try {
        return $Function('"use strict"; return (' + expressionSyntax + ").constructor;")();
      } catch (e5) {
      }
    };
    var $gOPD = require_gopd();
    var $defineProperty = require_es_define_property();
    var throwTypeError = function() {
      throw new $TypeError();
    };
    var ThrowTypeError = $gOPD ? function() {
      try {
        arguments.callee;
        return throwTypeError;
      } catch (calleeThrows) {
        try {
          return $gOPD(arguments, "callee").get;
        } catch (gOPDthrows) {
          return throwTypeError;
        }
      }
    }() : throwTypeError;
    var hasSymbols = require_has_symbols()();
    var getProto = require_get_proto();
    var $ObjectGPO = require_Object_getPrototypeOf();
    var $ReflectGPO = require_Reflect_getPrototypeOf();
    var $apply = require_functionApply();
    var $call = require_functionCall();
    var needsEval = {};
    var TypedArray = typeof Uint8Array === "undefined" || !getProto ? undefined2 : getProto(Uint8Array);
    var INTRINSICS = {
      __proto__: null,
      "%AggregateError%": typeof AggregateError === "undefined" ? undefined2 : AggregateError,
      "%Array%": Array,
      "%ArrayBuffer%": typeof ArrayBuffer === "undefined" ? undefined2 : ArrayBuffer,
      "%ArrayIteratorPrototype%": hasSymbols && getProto ? getProto([][Symbol.iterator]()) : undefined2,
      "%AsyncFromSyncIteratorPrototype%": undefined2,
      "%AsyncFunction%": needsEval,
      "%AsyncGenerator%": needsEval,
      "%AsyncGeneratorFunction%": needsEval,
      "%AsyncIteratorPrototype%": needsEval,
      "%Atomics%": typeof Atomics === "undefined" ? undefined2 : Atomics,
      "%BigInt%": typeof BigInt === "undefined" ? undefined2 : BigInt,
      "%BigInt64Array%": typeof BigInt64Array === "undefined" ? undefined2 : BigInt64Array,
      "%BigUint64Array%": typeof BigUint64Array === "undefined" ? undefined2 : BigUint64Array,
      "%Boolean%": Boolean,
      "%DataView%": typeof DataView === "undefined" ? undefined2 : DataView,
      "%Date%": Date,
      "%decodeURI%": decodeURI,
      "%decodeURIComponent%": decodeURIComponent,
      "%encodeURI%": encodeURI,
      "%encodeURIComponent%": encodeURIComponent,
      "%Error%": $Error,
      "%eval%": eval,
      // eslint-disable-line no-eval
      "%EvalError%": $EvalError,
      "%Float16Array%": typeof Float16Array === "undefined" ? undefined2 : Float16Array,
      "%Float32Array%": typeof Float32Array === "undefined" ? undefined2 : Float32Array,
      "%Float64Array%": typeof Float64Array === "undefined" ? undefined2 : Float64Array,
      "%FinalizationRegistry%": typeof FinalizationRegistry === "undefined" ? undefined2 : FinalizationRegistry,
      "%Function%": $Function,
      "%GeneratorFunction%": needsEval,
      "%Int8Array%": typeof Int8Array === "undefined" ? undefined2 : Int8Array,
      "%Int16Array%": typeof Int16Array === "undefined" ? undefined2 : Int16Array,
      "%Int32Array%": typeof Int32Array === "undefined" ? undefined2 : Int32Array,
      "%isFinite%": isFinite,
      "%isNaN%": isNaN,
      "%IteratorPrototype%": hasSymbols && getProto ? getProto(getProto([][Symbol.iterator]())) : undefined2,
      "%JSON%": typeof JSON === "object" ? JSON : undefined2,
      "%Map%": typeof Map === "undefined" ? undefined2 : Map,
      "%MapIteratorPrototype%": typeof Map === "undefined" || !hasSymbols || !getProto ? undefined2 : getProto((/* @__PURE__ */ new Map())[Symbol.iterator]()),
      "%Math%": Math,
      "%Number%": Number,
      "%Object%": $Object,
      "%Object.getOwnPropertyDescriptor%": $gOPD,
      "%parseFloat%": parseFloat,
      "%parseInt%": parseInt,
      "%Promise%": typeof Promise === "undefined" ? undefined2 : Promise,
      "%Proxy%": typeof Proxy === "undefined" ? undefined2 : Proxy,
      "%RangeError%": $RangeError,
      "%ReferenceError%": $ReferenceError,
      "%Reflect%": typeof Reflect === "undefined" ? undefined2 : Reflect,
      "%RegExp%": RegExp,
      "%Set%": typeof Set === "undefined" ? undefined2 : Set,
      "%SetIteratorPrototype%": typeof Set === "undefined" || !hasSymbols || !getProto ? undefined2 : getProto((/* @__PURE__ */ new Set())[Symbol.iterator]()),
      "%SharedArrayBuffer%": typeof SharedArrayBuffer === "undefined" ? undefined2 : SharedArrayBuffer,
      "%String%": String,
      "%StringIteratorPrototype%": hasSymbols && getProto ? getProto(""[Symbol.iterator]()) : undefined2,
      "%Symbol%": hasSymbols ? Symbol : undefined2,
      "%SyntaxError%": $SyntaxError,
      "%ThrowTypeError%": ThrowTypeError,
      "%TypedArray%": TypedArray,
      "%TypeError%": $TypeError,
      "%Uint8Array%": typeof Uint8Array === "undefined" ? undefined2 : Uint8Array,
      "%Uint8ClampedArray%": typeof Uint8ClampedArray === "undefined" ? undefined2 : Uint8ClampedArray,
      "%Uint16Array%": typeof Uint16Array === "undefined" ? undefined2 : Uint16Array,
      "%Uint32Array%": typeof Uint32Array === "undefined" ? undefined2 : Uint32Array,
      "%URIError%": $URIError,
      "%WeakMap%": typeof WeakMap === "undefined" ? undefined2 : WeakMap,
      "%WeakRef%": typeof WeakRef === "undefined" ? undefined2 : WeakRef,
      "%WeakSet%": typeof WeakSet === "undefined" ? undefined2 : WeakSet,
      "%Function.prototype.call%": $call,
      "%Function.prototype.apply%": $apply,
      "%Object.defineProperty%": $defineProperty,
      "%Object.getPrototypeOf%": $ObjectGPO,
      "%Math.abs%": abs,
      "%Math.floor%": floor,
      "%Math.max%": max,
      "%Math.min%": min,
      "%Math.pow%": pow,
      "%Math.round%": round,
      "%Math.sign%": sign,
      "%Reflect.getPrototypeOf%": $ReflectGPO
    };
    if (getProto) {
      try {
        null.error;
      } catch (e5) {
        errorProto = getProto(getProto(e5));
        INTRINSICS["%Error.prototype%"] = errorProto;
      }
    }
    var errorProto;
    var doEval = function doEval2(name) {
      var value;
      if (name === "%AsyncFunction%") {
        value = getEvalledConstructor("async function () {}");
      } else if (name === "%GeneratorFunction%") {
        value = getEvalledConstructor("function* () {}");
      } else if (name === "%AsyncGeneratorFunction%") {
        value = getEvalledConstructor("async function* () {}");
      } else if (name === "%AsyncGenerator%") {
        var fn2 = doEval2("%AsyncGeneratorFunction%");
        if (fn2) {
          value = fn2.prototype;
        }
      } else if (name === "%AsyncIteratorPrototype%") {
        var gen = doEval2("%AsyncGenerator%");
        if (gen && getProto) {
          value = getProto(gen.prototype);
        }
      }
      INTRINSICS[name] = value;
      return value;
    };
    var LEGACY_ALIASES = {
      __proto__: null,
      "%ArrayBufferPrototype%": ["ArrayBuffer", "prototype"],
      "%ArrayPrototype%": ["Array", "prototype"],
      "%ArrayProto_entries%": ["Array", "prototype", "entries"],
      "%ArrayProto_forEach%": ["Array", "prototype", "forEach"],
      "%ArrayProto_keys%": ["Array", "prototype", "keys"],
      "%ArrayProto_values%": ["Array", "prototype", "values"],
      "%AsyncFunctionPrototype%": ["AsyncFunction", "prototype"],
      "%AsyncGenerator%": ["AsyncGeneratorFunction", "prototype"],
      "%AsyncGeneratorPrototype%": ["AsyncGeneratorFunction", "prototype", "prototype"],
      "%BooleanPrototype%": ["Boolean", "prototype"],
      "%DataViewPrototype%": ["DataView", "prototype"],
      "%DatePrototype%": ["Date", "prototype"],
      "%ErrorPrototype%": ["Error", "prototype"],
      "%EvalErrorPrototype%": ["EvalError", "prototype"],
      "%Float32ArrayPrototype%": ["Float32Array", "prototype"],
      "%Float64ArrayPrototype%": ["Float64Array", "prototype"],
      "%FunctionPrototype%": ["Function", "prototype"],
      "%Generator%": ["GeneratorFunction", "prototype"],
      "%GeneratorPrototype%": ["GeneratorFunction", "prototype", "prototype"],
      "%Int8ArrayPrototype%": ["Int8Array", "prototype"],
      "%Int16ArrayPrototype%": ["Int16Array", "prototype"],
      "%Int32ArrayPrototype%": ["Int32Array", "prototype"],
      "%JSONParse%": ["JSON", "parse"],
      "%JSONStringify%": ["JSON", "stringify"],
      "%MapPrototype%": ["Map", "prototype"],
      "%NumberPrototype%": ["Number", "prototype"],
      "%ObjectPrototype%": ["Object", "prototype"],
      "%ObjProto_toString%": ["Object", "prototype", "toString"],
      "%ObjProto_valueOf%": ["Object", "prototype", "valueOf"],
      "%PromisePrototype%": ["Promise", "prototype"],
      "%PromiseProto_then%": ["Promise", "prototype", "then"],
      "%Promise_all%": ["Promise", "all"],
      "%Promise_reject%": ["Promise", "reject"],
      "%Promise_resolve%": ["Promise", "resolve"],
      "%RangeErrorPrototype%": ["RangeError", "prototype"],
      "%ReferenceErrorPrototype%": ["ReferenceError", "prototype"],
      "%RegExpPrototype%": ["RegExp", "prototype"],
      "%SetPrototype%": ["Set", "prototype"],
      "%SharedArrayBufferPrototype%": ["SharedArrayBuffer", "prototype"],
      "%StringPrototype%": ["String", "prototype"],
      "%SymbolPrototype%": ["Symbol", "prototype"],
      "%SyntaxErrorPrototype%": ["SyntaxError", "prototype"],
      "%TypedArrayPrototype%": ["TypedArray", "prototype"],
      "%TypeErrorPrototype%": ["TypeError", "prototype"],
      "%Uint8ArrayPrototype%": ["Uint8Array", "prototype"],
      "%Uint8ClampedArrayPrototype%": ["Uint8ClampedArray", "prototype"],
      "%Uint16ArrayPrototype%": ["Uint16Array", "prototype"],
      "%Uint32ArrayPrototype%": ["Uint32Array", "prototype"],
      "%URIErrorPrototype%": ["URIError", "prototype"],
      "%WeakMapPrototype%": ["WeakMap", "prototype"],
      "%WeakSetPrototype%": ["WeakSet", "prototype"]
    };
    var bind = require_function_bind();
    var hasOwn = require_hasown();
    var $concat = bind.call($call, Array.prototype.concat);
    var $spliceApply = bind.call($apply, Array.prototype.splice);
    var $replace = bind.call($call, String.prototype.replace);
    var $strSlice = bind.call($call, String.prototype.slice);
    var $exec = bind.call($call, RegExp.prototype.exec);
    var rePropName = /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g;
    var reEscapeChar = /\\(\\)?/g;
    var stringToPath = function stringToPath2(string) {
      var first = $strSlice(string, 0, 1);
      var last = $strSlice(string, -1);
      if (first === "%" && last !== "%") {
        throw new $SyntaxError("invalid intrinsic syntax, expected closing `%`");
      } else if (last === "%" && first !== "%") {
        throw new $SyntaxError("invalid intrinsic syntax, expected opening `%`");
      }
      var result = [];
      $replace(string, rePropName, function(match, number, quote, subString) {
        result[result.length] = quote ? $replace(subString, reEscapeChar, "$1") : number || match;
      });
      return result;
    };
    var getBaseIntrinsic = function getBaseIntrinsic2(name, allowMissing) {
      var intrinsicName = name;
      var alias;
      if (hasOwn(LEGACY_ALIASES, intrinsicName)) {
        alias = LEGACY_ALIASES[intrinsicName];
        intrinsicName = "%" + alias[0] + "%";
      }
      if (hasOwn(INTRINSICS, intrinsicName)) {
        var value = INTRINSICS[intrinsicName];
        if (value === needsEval) {
          value = doEval(intrinsicName);
        }
        if (typeof value === "undefined" && !allowMissing) {
          throw new $TypeError("intrinsic " + name + " exists, but is not available. Please file an issue!");
        }
        return {
          alias,
          name: intrinsicName,
          value
        };
      }
      throw new $SyntaxError("intrinsic " + name + " does not exist!");
    };
    module2.exports = function GetIntrinsic(name, allowMissing) {
      if (typeof name !== "string" || name.length === 0) {
        throw new $TypeError("intrinsic name must be a non-empty string");
      }
      if (arguments.length > 1 && typeof allowMissing !== "boolean") {
        throw new $TypeError('"allowMissing" argument must be a boolean');
      }
      if ($exec(/^%?[^%]*%?$/, name) === null) {
        throw new $SyntaxError("`%` may not be present anywhere but at the beginning and end of the intrinsic name");
      }
      var parts = stringToPath(name);
      var intrinsicBaseName = parts.length > 0 ? parts[0] : "";
      var intrinsic = getBaseIntrinsic("%" + intrinsicBaseName + "%", allowMissing);
      var intrinsicRealName = intrinsic.name;
      var value = intrinsic.value;
      var skipFurtherCaching = false;
      var alias = intrinsic.alias;
      if (alias) {
        intrinsicBaseName = alias[0];
        $spliceApply(parts, $concat([0, 1], alias));
      }
      for (var i2 = 1, isOwn = true; i2 < parts.length; i2 += 1) {
        var part = parts[i2];
        var first = $strSlice(part, 0, 1);
        var last = $strSlice(part, -1);
        if ((first === '"' || first === "'" || first === "`" || (last === '"' || last === "'" || last === "`")) && first !== last) {
          throw new $SyntaxError("property names with quotes must have matching quotes");
        }
        if (part === "constructor" || !isOwn) {
          skipFurtherCaching = true;
        }
        intrinsicBaseName += "." + part;
        intrinsicRealName = "%" + intrinsicBaseName + "%";
        if (hasOwn(INTRINSICS, intrinsicRealName)) {
          value = INTRINSICS[intrinsicRealName];
        } else if (value != null) {
          if (!(part in value)) {
            if (!allowMissing) {
              throw new $TypeError("base intrinsic for " + name + " exists, but the property is not available.");
            }
            return void undefined2;
          }
          if ($gOPD && i2 + 1 >= parts.length) {
            var desc = $gOPD(value, part);
            isOwn = !!desc;
            if (isOwn && "get" in desc && !("originalValue" in desc.get)) {
              value = desc.get;
            } else {
              value = value[part];
            }
          } else {
            isOwn = hasOwn(value, part);
            value = value[part];
          }
          if (isOwn && !skipFurtherCaching) {
            INTRINSICS[intrinsicRealName] = value;
          }
        }
      }
      return value;
    };
  }
});

// netlify/functions/node_modules/has-tostringtag/shams.js
var require_shams2 = __commonJS({
  "netlify/functions/node_modules/has-tostringtag/shams.js"(exports2, module2) {
    "use strict";
    var hasSymbols = require_shams();
    module2.exports = function hasToStringTagShams() {
      return hasSymbols() && !!Symbol.toStringTag;
    };
  }
});

// netlify/functions/node_modules/es-set-tostringtag/index.js
var require_es_set_tostringtag = __commonJS({
  "netlify/functions/node_modules/es-set-tostringtag/index.js"(exports2, module2) {
    "use strict";
    var GetIntrinsic = require_get_intrinsic();
    var $defineProperty = GetIntrinsic("%Object.defineProperty%", true);
    var hasToStringTag = require_shams2()();
    var hasOwn = require_hasown();
    var $TypeError = require_type();
    var toStringTag = hasToStringTag ? Symbol.toStringTag : null;
    module2.exports = function setToStringTag(object, value) {
      var overrideIfSet = arguments.length > 2 && !!arguments[2] && arguments[2].force;
      var nonConfigurable = arguments.length > 2 && !!arguments[2] && arguments[2].nonConfigurable;
      if (typeof overrideIfSet !== "undefined" && typeof overrideIfSet !== "boolean" || typeof nonConfigurable !== "undefined" && typeof nonConfigurable !== "boolean") {
        throw new $TypeError("if provided, the `overrideIfSet` and `nonConfigurable` options must be booleans");
      }
      if (toStringTag && (overrideIfSet || !hasOwn(object, toStringTag))) {
        if ($defineProperty) {
          $defineProperty(object, toStringTag, {
            configurable: !nonConfigurable,
            enumerable: false,
            value,
            writable: false
          });
        } else {
          object[toStringTag] = value;
        }
      }
    };
  }
});

// netlify/functions/node_modules/form-data/lib/populate.js
var require_populate = __commonJS({
  "netlify/functions/node_modules/form-data/lib/populate.js"(exports2, module2) {
    module2.exports = function(dst, src) {
      Object.keys(src).forEach(function(prop) {
        dst[prop] = dst[prop] || src[prop];
      });
      return dst;
    };
  }
});

// netlify/functions/node_modules/form-data/lib/form_data.js
var require_form_data = __commonJS({
  "netlify/functions/node_modules/form-data/lib/form_data.js"(exports2, module2) {
    var CombinedStream = require_combined_stream();
    var util = require("util");
    var path = require("path");
    var http = require("http");
    var https = require("https");
    var parseUrl = require("url").parse;
    var fs2 = require("fs");
    var Stream = require("stream").Stream;
    var mime = require_mime_types();
    var asynckit = require_asynckit();
    var setToStringTag = require_es_set_tostringtag();
    var populate = require_populate();
    module2.exports = FormData3;
    util.inherits(FormData3, CombinedStream);
    function FormData3(options) {
      if (!(this instanceof FormData3)) {
        return new FormData3(options);
      }
      this._overheadLength = 0;
      this._valueLength = 0;
      this._valuesToMeasure = [];
      CombinedStream.call(this);
      options = options || {};
      for (var option in options) {
        this[option] = options[option];
      }
    }
    FormData3.LINE_BREAK = "\r\n";
    FormData3.DEFAULT_CONTENT_TYPE = "application/octet-stream";
    FormData3.prototype.append = function(field, value, options) {
      options = options || {};
      if (typeof options == "string") {
        options = { filename: options };
      }
      var append = CombinedStream.prototype.append.bind(this);
      if (typeof value == "number") {
        value = "" + value;
      }
      if (Array.isArray(value)) {
        this._error(new Error("Arrays are not supported."));
        return;
      }
      var header = this._multiPartHeader(field, value, options);
      var footer = this._multiPartFooter();
      append(header);
      append(value);
      append(footer);
      this._trackLength(header, value, options);
    };
    FormData3.prototype._trackLength = function(header, value, options) {
      var valueLength = 0;
      if (options.knownLength != null) {
        valueLength += +options.knownLength;
      } else if (Buffer.isBuffer(value)) {
        valueLength = value.length;
      } else if (typeof value === "string") {
        valueLength = Buffer.byteLength(value);
      }
      this._valueLength += valueLength;
      this._overheadLength += Buffer.byteLength(header) + FormData3.LINE_BREAK.length;
      if (!value || !value.path && !(value.readable && Object.prototype.hasOwnProperty.call(value, "httpVersion")) && !(value instanceof Stream)) {
        return;
      }
      if (!options.knownLength) {
        this._valuesToMeasure.push(value);
      }
    };
    FormData3.prototype._lengthRetriever = function(value, callback) {
      if (Object.prototype.hasOwnProperty.call(value, "fd")) {
        if (value.end != void 0 && value.end != Infinity && value.start != void 0) {
          callback(null, value.end + 1 - (value.start ? value.start : 0));
        } else {
          fs2.stat(value.path, function(err, stat) {
            var fileSize;
            if (err) {
              callback(err);
              return;
            }
            fileSize = stat.size - (value.start ? value.start : 0);
            callback(null, fileSize);
          });
        }
      } else if (Object.prototype.hasOwnProperty.call(value, "httpVersion")) {
        callback(null, +value.headers["content-length"]);
      } else if (Object.prototype.hasOwnProperty.call(value, "httpModule")) {
        value.on("response", function(response) {
          value.pause();
          callback(null, +response.headers["content-length"]);
        });
        value.resume();
      } else {
        callback("Unknown stream");
      }
    };
    FormData3.prototype._multiPartHeader = function(field, value, options) {
      if (typeof options.header == "string") {
        return options.header;
      }
      var contentDisposition = this._getContentDisposition(value, options);
      var contentType = this._getContentType(value, options);
      var contents = "";
      var headers = {
        // add custom disposition as third element or keep it two elements if not
        "Content-Disposition": ["form-data", 'name="' + field + '"'].concat(contentDisposition || []),
        // if no content type. allow it to be empty array
        "Content-Type": [].concat(contentType || [])
      };
      if (typeof options.header == "object") {
        populate(headers, options.header);
      }
      var header;
      for (var prop in headers) {
        if (Object.prototype.hasOwnProperty.call(headers, prop)) {
          header = headers[prop];
          if (header == null) {
            continue;
          }
          if (!Array.isArray(header)) {
            header = [header];
          }
          if (header.length) {
            contents += prop + ": " + header.join("; ") + FormData3.LINE_BREAK;
          }
        }
      }
      return "--" + this.getBoundary() + FormData3.LINE_BREAK + contents + FormData3.LINE_BREAK;
    };
    FormData3.prototype._getContentDisposition = function(value, options) {
      var filename, contentDisposition;
      if (typeof options.filepath === "string") {
        filename = path.normalize(options.filepath).replace(/\\/g, "/");
      } else if (options.filename || value.name || value.path) {
        filename = path.basename(options.filename || value.name || value.path);
      } else if (value.readable && Object.prototype.hasOwnProperty.call(value, "httpVersion")) {
        filename = path.basename(value.client._httpMessage.path || "");
      }
      if (filename) {
        contentDisposition = 'filename="' + filename + '"';
      }
      return contentDisposition;
    };
    FormData3.prototype._getContentType = function(value, options) {
      var contentType = options.contentType;
      if (!contentType && value.name) {
        contentType = mime.lookup(value.name);
      }
      if (!contentType && value.path) {
        contentType = mime.lookup(value.path);
      }
      if (!contentType && value.readable && Object.prototype.hasOwnProperty.call(value, "httpVersion")) {
        contentType = value.headers["content-type"];
      }
      if (!contentType && (options.filepath || options.filename)) {
        contentType = mime.lookup(options.filepath || options.filename);
      }
      if (!contentType && typeof value == "object") {
        contentType = FormData3.DEFAULT_CONTENT_TYPE;
      }
      return contentType;
    };
    FormData3.prototype._multiPartFooter = function() {
      return function(next) {
        var footer = FormData3.LINE_BREAK;
        var lastPart = this._streams.length === 0;
        if (lastPart) {
          footer += this._lastBoundary();
        }
        next(footer);
      }.bind(this);
    };
    FormData3.prototype._lastBoundary = function() {
      return "--" + this.getBoundary() + "--" + FormData3.LINE_BREAK;
    };
    FormData3.prototype.getHeaders = function(userHeaders) {
      var header;
      var formHeaders = {
        "content-type": "multipart/form-data; boundary=" + this.getBoundary()
      };
      for (header in userHeaders) {
        if (Object.prototype.hasOwnProperty.call(userHeaders, header)) {
          formHeaders[header.toLowerCase()] = userHeaders[header];
        }
      }
      return formHeaders;
    };
    FormData3.prototype.setBoundary = function(boundary) {
      this._boundary = boundary;
    };
    FormData3.prototype.getBoundary = function() {
      if (!this._boundary) {
        this._generateBoundary();
      }
      return this._boundary;
    };
    FormData3.prototype.getBuffer = function() {
      var dataBuffer = new Buffer.alloc(0);
      var boundary = this.getBoundary();
      for (var i2 = 0, len = this._streams.length; i2 < len; i2++) {
        if (typeof this._streams[i2] !== "function") {
          if (Buffer.isBuffer(this._streams[i2])) {
            dataBuffer = Buffer.concat([dataBuffer, this._streams[i2]]);
          } else {
            dataBuffer = Buffer.concat([dataBuffer, Buffer.from(this._streams[i2])]);
          }
          if (typeof this._streams[i2] !== "string" || this._streams[i2].substring(2, boundary.length + 2) !== boundary) {
            dataBuffer = Buffer.concat([dataBuffer, Buffer.from(FormData3.LINE_BREAK)]);
          }
        }
      }
      return Buffer.concat([dataBuffer, Buffer.from(this._lastBoundary())]);
    };
    FormData3.prototype._generateBoundary = function() {
      var boundary = "--------------------------";
      for (var i2 = 0; i2 < 24; i2++) {
        boundary += Math.floor(Math.random() * 10).toString(16);
      }
      this._boundary = boundary;
    };
    FormData3.prototype.getLengthSync = function() {
      var knownLength = this._overheadLength + this._valueLength;
      if (this._streams.length) {
        knownLength += this._lastBoundary().length;
      }
      if (!this.hasKnownLength()) {
        this._error(new Error("Cannot calculate proper length in synchronous way."));
      }
      return knownLength;
    };
    FormData3.prototype.hasKnownLength = function() {
      var hasKnownLength = true;
      if (this._valuesToMeasure.length) {
        hasKnownLength = false;
      }
      return hasKnownLength;
    };
    FormData3.prototype.getLength = function(cb) {
      var knownLength = this._overheadLength + this._valueLength;
      if (this._streams.length) {
        knownLength += this._lastBoundary().length;
      }
      if (!this._valuesToMeasure.length) {
        process.nextTick(cb.bind(this, null, knownLength));
        return;
      }
      asynckit.parallel(this._valuesToMeasure, this._lengthRetriever, function(err, values) {
        if (err) {
          cb(err);
          return;
        }
        values.forEach(function(length) {
          knownLength += length;
        });
        cb(null, knownLength);
      });
    };
    FormData3.prototype.submit = function(params, cb) {
      var request, options, defaults = { method: "post" };
      if (typeof params == "string") {
        params = parseUrl(params);
        options = populate({
          port: params.port,
          path: params.pathname,
          host: params.hostname,
          protocol: params.protocol
        }, defaults);
      } else {
        options = populate(params, defaults);
        if (!options.port) {
          options.port = options.protocol == "https:" ? 443 : 80;
        }
      }
      options.headers = this.getHeaders(params.headers);
      if (options.protocol == "https:") {
        request = https.request(options);
      } else {
        request = http.request(options);
      }
      this.getLength(function(err, length) {
        if (err && err !== "Unknown stream") {
          this._error(err);
          return;
        }
        if (length) {
          request.setHeader("Content-Length", length);
        }
        this.pipe(request);
        if (cb) {
          var onResponse;
          var callback = function(error, responce) {
            request.removeListener("error", callback);
            request.removeListener("response", onResponse);
            return cb.call(this, error, responce);
          };
          onResponse = callback.bind(this, null);
          request.on("error", callback);
          request.on("response", onResponse);
        }
      }.bind(this));
      return request;
    };
    FormData3.prototype._error = function(err) {
      if (!this.error) {
        this.error = err;
        this.pause();
        this.emit("error", err);
      }
    };
    FormData3.prototype.toString = function() {
      return "[object FormData]";
    };
    setToStringTag(FormData3, "FormData");
  }
});

// netlify/functions/sendEmail.js
var sendEmail_exports = {};
__export(sendEmail_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(sendEmail_exports);
var import_form_data = __toESM(require_form_data(), 1);

// netlify/functions/node_modules/mailgun.js/ESM/mailgun.node.js
var import_util = __toESM(require("util"), 1);
var import_stream = __toESM(require("stream"), 1);
var import_path = __toESM(require("path"), 1);
var import_http = __toESM(require("http"), 1);
var import_https = __toESM(require("https"), 1);
var import_url = __toESM(require("url"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_assert = __toESM(require("assert"), 1);
var import_tty = __toESM(require("tty"), 1);
var import_os = __toESM(require("os"), 1);
var import_zlib = __toESM(require("zlib"), 1);
var import_events = require("events");
var m = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
function h(e5) {
  return e5 && e5.__esModule && Object.prototype.hasOwnProperty.call(e5, "default") ? e5.default : e5;
}
var f;
var x = { exports: {} };
var v;
var b;
var g;
var y = (f || (f = 1, v = x, b = x.exports, function(e5) {
  var a2 = b, n2 = v && v.exports == a2 && v, t2 = "object" == typeof m && m;
  t2.global !== t2 && t2.window !== t2 || (e5 = t2);
  var s2 = function(e6) {
    this.message = e6;
  };
  (s2.prototype = new Error()).name = "InvalidCharacterError";
  var i2 = function(e6) {
    throw new s2(e6);
  }, o2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", r2 = /[\t\n\f\r ]/g, c2 = { encode: function(e6) {
    e6 = String(e6), /[^\0-\xFF]/.test(e6) && i2("The string to be encoded contains characters outside of the Latin1 range.");
    for (var a3, n3, t3, s3, r3 = e6.length % 3, c3 = "", p3 = -1, l2 = e6.length - r3; ++p3 < l2; ) a3 = e6.charCodeAt(p3) << 16, n3 = e6.charCodeAt(++p3) << 8, t3 = e6.charCodeAt(++p3), c3 += o2.charAt((s3 = a3 + n3 + t3) >> 18 & 63) + o2.charAt(s3 >> 12 & 63) + o2.charAt(s3 >> 6 & 63) + o2.charAt(63 & s3);
    return 2 == r3 ? (a3 = e6.charCodeAt(p3) << 8, n3 = e6.charCodeAt(++p3), c3 += o2.charAt((s3 = a3 + n3) >> 10) + o2.charAt(s3 >> 4 & 63) + o2.charAt(s3 << 2 & 63) + "=") : 1 == r3 && (s3 = e6.charCodeAt(p3), c3 += o2.charAt(s3 >> 2) + o2.charAt(s3 << 4 & 63) + "=="), c3;
  }, decode: function(e6) {
    var a3 = (e6 = String(e6).replace(r2, "")).length;
    a3 % 4 == 0 && (a3 = (e6 = e6.replace(/==?$/, "")).length), (a3 % 4 == 1 || /[^+a-zA-Z0-9/]/.test(e6)) && i2("Invalid character: the string to be decoded is not correctly encoded.");
    for (var n3, t3, s3 = 0, c3 = "", p3 = -1; ++p3 < a3; ) t3 = o2.indexOf(e6.charAt(p3)), n3 = s3 % 4 ? 64 * n3 + t3 : t3, s3++ % 4 && (c3 += String.fromCharCode(255 & n3 >> (-2 * s3 & 6)));
    return c3;
  }, version: "1.0.0" };
  if (a2 && !a2.nodeType) if (n2) n2.exports = c2;
  else for (var p2 in c2) c2.hasOwnProperty(p2) && (a2[p2] = c2[p2]);
  else e5.base64 = c2;
}(x.exports)), x.exports);
var w = { exports: {} };
var _ = w.exports;
var k = (g || (g = 1, function(e5) {
  var a2, n2;
  a2 = _, n2 = function() {
    return function() {
      return function(e6) {
        var a3 = [];
        if (0 === e6.length) return "";
        if ("string" != typeof e6[0]) throw new TypeError("Url must be a string. Received " + e6[0]);
        if (e6[0].match(/^[^/:]+:\/*$/) && e6.length > 1) {
          var n3 = e6.shift();
          e6[0] = n3 + e6[0];
        }
        e6[0].match(/^file:\/\/\//) ? e6[0] = e6[0].replace(/^([^/:]+):\/*/, "$1:///") : e6[0] = e6[0].replace(/^([^/:]+):\/*/, "$1://");
        for (var t2 = 0; t2 < e6.length; t2++) {
          var s2 = e6[t2];
          if ("string" != typeof s2) throw new TypeError("Url must be a string. Received " + s2);
          "" !== s2 && (t2 > 0 && (s2 = s2.replace(/^[\/]+/, "")), s2 = t2 < e6.length - 1 ? s2.replace(/[\/]+$/, "") : s2.replace(/[\/]+$/, "/"), a3.push(s2));
        }
        var i2 = a3.join("/"), o2 = (i2 = i2.replace(/\/(\?|&|#[^!])/g, "$1")).split("?");
        return o2.shift() + (o2.length > 0 ? "?" : "") + o2.join("&");
      }("object" == typeof arguments[0] ? arguments[0] : [].slice.call(arguments));
    };
  }, e5.exports ? e5.exports = n2() : a2.urljoin = n2();
}(w)), w.exports);
var j = h(k);
function R(e5, a2) {
  return function() {
    return e5.apply(a2, arguments);
  };
}
var { toString: S } = Object.prototype;
var { getPrototypeOf: E } = Object;
var T = (q = /* @__PURE__ */ Object.create(null), (e5) => {
  const a2 = S.call(e5);
  return q[a2] || (q[a2] = a2.slice(8, -1).toLowerCase());
});
var q;
var C = (e5) => (e5 = e5.toLowerCase(), (a2) => T(a2) === e5);
var A = (e5) => (a2) => typeof a2 === e5;
var { isArray: O } = Array;
var F = A("undefined");
var D = C("ArrayBuffer");
var P = A("string");
var B = A("function");
var L = A("number");
var U = (e5) => null !== e5 && "object" == typeof e5;
var z = (e5) => {
  if ("object" !== T(e5)) return false;
  const a2 = E(e5);
  return !(null !== a2 && a2 !== Object.prototype && null !== Object.getPrototypeOf(a2) || Symbol.toStringTag in e5 || Symbol.iterator in e5);
};
var I = C("Date");
var N = C("File");
var M = C("Blob");
var $ = C("FileList");
var W = C("URLSearchParams");
var [H, V, G, J] = ["ReadableStream", "Request", "Response", "Headers"].map(C);
function K(e5, a2, { allOwnKeys: n2 = false } = {}) {
  if (null == e5) return;
  let t2, s2;
  if ("object" != typeof e5 && (e5 = [e5]), O(e5)) for (t2 = 0, s2 = e5.length; t2 < s2; t2++) a2.call(null, e5[t2], t2, e5);
  else {
    const s3 = n2 ? Object.getOwnPropertyNames(e5) : Object.keys(e5), i2 = s3.length;
    let o2;
    for (t2 = 0; t2 < i2; t2++) o2 = s3[t2], a2.call(null, e5[o2], o2, e5);
  }
}
function Q(e5, a2) {
  a2 = a2.toLowerCase();
  const n2 = Object.keys(e5);
  let t2, s2 = n2.length;
  for (; s2-- > 0; ) if (t2 = n2[s2], a2 === t2.toLowerCase()) return t2;
  return null;
}
var Y = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : "undefined" != typeof window ? window : global;
var X = (e5) => !F(e5) && e5 !== Y;
var Z = (ee = "undefined" != typeof Uint8Array && E(Uint8Array), (e5) => ee && e5 instanceof ee);
var ee;
var ae = C("HTMLFormElement");
var ne = (({ hasOwnProperty: e5 }) => (a2, n2) => e5.call(a2, n2))(Object.prototype);
var te = C("RegExp");
var se = (e5, a2) => {
  const n2 = Object.getOwnPropertyDescriptors(e5), t2 = {};
  K(n2, (n3, s2) => {
    let i2;
    false !== (i2 = a2(n3, s2, e5)) && (t2[s2] = i2 || n3);
  }), Object.defineProperties(e5, t2);
};
var ie = "abcdefghijklmnopqrstuvwxyz";
var oe = "0123456789";
var re = { DIGIT: oe, ALPHA: ie, ALPHA_DIGIT: ie + ie.toUpperCase() + oe };
var ce = C("AsyncFunction");
var pe = (le = "function" == typeof setImmediate, ue = B(Y.postMessage), le ? setImmediate : ue ? (de = `axios@${Math.random()}`, me = [], Y.addEventListener("message", ({ source: e5, data: a2 }) => {
  e5 === Y && a2 === de && me.length && me.shift()();
}, false), (e5) => {
  me.push(e5), Y.postMessage(de, "*");
}) : (e5) => setTimeout(e5));
var le;
var ue;
var de;
var me;
var he = "undefined" != typeof queueMicrotask ? queueMicrotask.bind(Y) : "undefined" != typeof process && process.nextTick || pe;
var fe = { isArray: O, isArrayBuffer: D, isBuffer: function(e5) {
  return null !== e5 && !F(e5) && null !== e5.constructor && !F(e5.constructor) && B(e5.constructor.isBuffer) && e5.constructor.isBuffer(e5);
}, isFormData: (e5) => {
  let a2;
  return e5 && ("function" == typeof FormData && e5 instanceof FormData || B(e5.append) && ("formdata" === (a2 = T(e5)) || "object" === a2 && B(e5.toString) && "[object FormData]" === e5.toString()));
}, isArrayBufferView: function(e5) {
  let a2;
  return a2 = "undefined" != typeof ArrayBuffer && ArrayBuffer.isView ? ArrayBuffer.isView(e5) : e5 && e5.buffer && D(e5.buffer), a2;
}, isString: P, isNumber: L, isBoolean: (e5) => true === e5 || false === e5, isObject: U, isPlainObject: z, isReadableStream: H, isRequest: V, isResponse: G, isHeaders: J, isUndefined: F, isDate: I, isFile: N, isBlob: M, isRegExp: te, isFunction: B, isStream: (e5) => U(e5) && B(e5.pipe), isURLSearchParams: W, isTypedArray: Z, isFileList: $, forEach: K, merge: function e2() {
  const { caseless: a2 } = X(this) && this || {}, n2 = {}, t2 = (t3, s2) => {
    const i2 = a2 && Q(n2, s2) || s2;
    z(n2[i2]) && z(t3) ? n2[i2] = e2(n2[i2], t3) : z(t3) ? n2[i2] = e2({}, t3) : O(t3) ? n2[i2] = t3.slice() : n2[i2] = t3;
  };
  for (let e5 = 0, a3 = arguments.length; e5 < a3; e5++) arguments[e5] && K(arguments[e5], t2);
  return n2;
}, extend: (e5, a2, n2, { allOwnKeys: t2 } = {}) => (K(a2, (a3, t3) => {
  n2 && B(a3) ? e5[t3] = R(a3, n2) : e5[t3] = a3;
}, { allOwnKeys: t2 }), e5), trim: (e5) => e5.trim ? e5.trim() : e5.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, ""), stripBOM: (e5) => (65279 === e5.charCodeAt(0) && (e5 = e5.slice(1)), e5), inherits: (e5, a2, n2, t2) => {
  e5.prototype = Object.create(a2.prototype, t2), e5.prototype.constructor = e5, Object.defineProperty(e5, "super", { value: a2.prototype }), n2 && Object.assign(e5.prototype, n2);
}, toFlatObject: (e5, a2, n2, t2) => {
  let s2, i2, o2;
  const r2 = {};
  if (a2 = a2 || {}, null == e5) return a2;
  do {
    for (s2 = Object.getOwnPropertyNames(e5), i2 = s2.length; i2-- > 0; ) o2 = s2[i2], t2 && !t2(o2, e5, a2) || r2[o2] || (a2[o2] = e5[o2], r2[o2] = true);
    e5 = false !== n2 && E(e5);
  } while (e5 && (!n2 || n2(e5, a2)) && e5 !== Object.prototype);
  return a2;
}, kindOf: T, kindOfTest: C, endsWith: (e5, a2, n2) => {
  e5 = String(e5), (void 0 === n2 || n2 > e5.length) && (n2 = e5.length), n2 -= a2.length;
  const t2 = e5.indexOf(a2, n2);
  return -1 !== t2 && t2 === n2;
}, toArray: (e5) => {
  if (!e5) return null;
  if (O(e5)) return e5;
  let a2 = e5.length;
  if (!L(a2)) return null;
  const n2 = new Array(a2);
  for (; a2-- > 0; ) n2[a2] = e5[a2];
  return n2;
}, forEachEntry: (e5, a2) => {
  const n2 = (e5 && e5[Symbol.iterator]).call(e5);
  let t2;
  for (; (t2 = n2.next()) && !t2.done; ) {
    const n3 = t2.value;
    a2.call(e5, n3[0], n3[1]);
  }
}, matchAll: (e5, a2) => {
  let n2;
  const t2 = [];
  for (; null !== (n2 = e5.exec(a2)); ) t2.push(n2);
  return t2;
}, isHTMLForm: ae, hasOwnProperty: ne, hasOwnProp: ne, reduceDescriptors: se, freezeMethods: (e5) => {
  se(e5, (a2, n2) => {
    if (B(e5) && -1 !== ["arguments", "caller", "callee"].indexOf(n2)) return false;
    const t2 = e5[n2];
    B(t2) && (a2.enumerable = false, "writable" in a2 ? a2.writable = false : a2.set || (a2.set = () => {
      throw Error("Can not rewrite read-only method '" + n2 + "'");
    }));
  });
}, toObjectSet: (e5, a2) => {
  const n2 = {}, t2 = (e6) => {
    e6.forEach((e7) => {
      n2[e7] = true;
    });
  };
  return O(e5) ? t2(e5) : t2(String(e5).split(a2)), n2;
}, toCamelCase: (e5) => e5.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function(e6, a2, n2) {
  return a2.toUpperCase() + n2;
}), noop: () => {
}, toFiniteNumber: (e5, a2) => null != e5 && Number.isFinite(e5 = +e5) ? e5 : a2, findKey: Q, global: Y, isContextDefined: X, ALPHABET: re, generateString: (e5 = 16, a2 = re.ALPHA_DIGIT) => {
  let n2 = "";
  const { length: t2 } = a2;
  for (; e5--; ) n2 += a2[Math.random() * t2 | 0];
  return n2;
}, isSpecCompliantForm: function(e5) {
  return !!(e5 && B(e5.append) && "FormData" === e5[Symbol.toStringTag] && e5[Symbol.iterator]);
}, toJSONObject: (e5) => {
  const a2 = new Array(10), n2 = (e6, t2) => {
    if (U(e6)) {
      if (a2.indexOf(e6) >= 0) return;
      if (!("toJSON" in e6)) {
        a2[t2] = e6;
        const s2 = O(e6) ? [] : {};
        return K(e6, (e7, a3) => {
          const i2 = n2(e7, t2 + 1);
          !F(i2) && (s2[a3] = i2);
        }), a2[t2] = void 0, s2;
      }
    }
    return e6;
  };
  return n2(e5, 0);
}, isAsyncFn: ce, isThenable: (e5) => e5 && (U(e5) || B(e5)) && B(e5.then) && B(e5.catch), setImmediate: pe, asap: he };
function xe(e5, a2, n2, t2, s2) {
  Error.call(this), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack, this.message = e5, this.name = "AxiosError", a2 && (this.code = a2), n2 && (this.config = n2), t2 && (this.request = t2), s2 && (this.response = s2, this.status = s2.status ? s2.status : null);
}
fe.inherits(xe, Error, { toJSON: function() {
  return { message: this.message, name: this.name, description: this.description, number: this.number, fileName: this.fileName, lineNumber: this.lineNumber, columnNumber: this.columnNumber, stack: this.stack, config: fe.toJSONObject(this.config), code: this.code, status: this.status };
} });
var ve = xe.prototype;
var be = {};
var ge;
var ye;
var we;
var _e;
function ke() {
  if (_e) return we;
  _e = 1;
  var n2 = import_util.default, t2 = import_stream.default.Stream, s2 = function() {
    if (ye) return ge;
    ye = 1;
    var n3 = import_stream.default.Stream;
    function t3() {
      this.source = null, this.dataSize = 0, this.maxDataSize = 1048576, this.pauseStream = true, this._maxDataSizeExceeded = false, this._released = false, this._bufferedEvents = [];
    }
    return ge = t3, import_util.default.inherits(t3, n3), t3.create = function(e5, a2) {
      var n4 = new this();
      for (var t4 in a2 = a2 || {}) n4[t4] = a2[t4];
      n4.source = e5;
      var s3 = e5.emit;
      return e5.emit = function() {
        return n4._handleEmit(arguments), s3.apply(e5, arguments);
      }, e5.on("error", function() {
      }), n4.pauseStream && e5.pause(), n4;
    }, Object.defineProperty(t3.prototype, "readable", { configurable: true, enumerable: true, get: function() {
      return this.source.readable;
    } }), t3.prototype.setEncoding = function() {
      return this.source.setEncoding.apply(this.source, arguments);
    }, t3.prototype.resume = function() {
      this._released || this.release(), this.source.resume();
    }, t3.prototype.pause = function() {
      this.source.pause();
    }, t3.prototype.release = function() {
      this._released = true, this._bufferedEvents.forEach(function(e5) {
        this.emit.apply(this, e5);
      }.bind(this)), this._bufferedEvents = [];
    }, t3.prototype.pipe = function() {
      var e5 = n3.prototype.pipe.apply(this, arguments);
      return this.resume(), e5;
    }, t3.prototype._handleEmit = function(e5) {
      this._released ? this.emit.apply(this, e5) : ("data" === e5[0] && (this.dataSize += e5[1].length, this._checkIfMaxDataSizeExceeded()), this._bufferedEvents.push(e5));
    }, t3.prototype._checkIfMaxDataSizeExceeded = function() {
      if (!(this._maxDataSizeExceeded || this.dataSize <= this.maxDataSize)) {
        this._maxDataSizeExceeded = true;
        var e5 = "DelayedStream#maxDataSize of " + this.maxDataSize + " bytes exceeded.";
        this.emit("error", new Error(e5));
      }
    }, ge;
  }();
  function i2() {
    this.writable = false, this.readable = true, this.dataSize = 0, this.maxDataSize = 2097152, this.pauseStreams = true, this._released = false, this._streams = [], this._currentStream = null, this._insideLoop = false, this._pendingNext = false;
  }
  return we = i2, n2.inherits(i2, t2), i2.create = function(e5) {
    var a2 = new this();
    for (var n3 in e5 = e5 || {}) a2[n3] = e5[n3];
    return a2;
  }, i2.isStreamLike = function(e5) {
    return "function" != typeof e5 && "string" != typeof e5 && "boolean" != typeof e5 && "number" != typeof e5 && !Buffer.isBuffer(e5);
  }, i2.prototype.append = function(e5) {
    if (i2.isStreamLike(e5)) {
      if (!(e5 instanceof s2)) {
        var a2 = s2.create(e5, { maxDataSize: 1 / 0, pauseStream: this.pauseStreams });
        e5.on("data", this._checkDataSize.bind(this)), e5 = a2;
      }
      this._handleErrors(e5), this.pauseStreams && e5.pause();
    }
    return this._streams.push(e5), this;
  }, i2.prototype.pipe = function(e5, a2) {
    return t2.prototype.pipe.call(this, e5, a2), this.resume(), e5;
  }, i2.prototype._getNext = function() {
    if (this._currentStream = null, this._insideLoop) this._pendingNext = true;
    else {
      this._insideLoop = true;
      try {
        do {
          this._pendingNext = false, this._realGetNext();
        } while (this._pendingNext);
      } finally {
        this._insideLoop = false;
      }
    }
  }, i2.prototype._realGetNext = function() {
    var e5 = this._streams.shift();
    void 0 !== e5 ? "function" == typeof e5 ? e5(function(e6) {
      i2.isStreamLike(e6) && (e6.on("data", this._checkDataSize.bind(this)), this._handleErrors(e6)), this._pipeNext(e6);
    }.bind(this)) : this._pipeNext(e5) : this.end();
  }, i2.prototype._pipeNext = function(e5) {
    if (this._currentStream = e5, i2.isStreamLike(e5)) return e5.on("end", this._getNext.bind(this)), void e5.pipe(this, { end: false });
    var a2 = e5;
    this.write(a2), this._getNext();
  }, i2.prototype._handleErrors = function(e5) {
    var a2 = this;
    e5.on("error", function(e6) {
      a2._emitError(e6);
    });
  }, i2.prototype.write = function(e5) {
    this.emit("data", e5);
  }, i2.prototype.pause = function() {
    this.pauseStreams && (this.pauseStreams && this._currentStream && "function" == typeof this._currentStream.pause && this._currentStream.pause(), this.emit("pause"));
  }, i2.prototype.resume = function() {
    this._released || (this._released = true, this.writable = true, this._getNext()), this.pauseStreams && this._currentStream && "function" == typeof this._currentStream.resume && this._currentStream.resume(), this.emit("resume");
  }, i2.prototype.end = function() {
    this._reset(), this.emit("end");
  }, i2.prototype.destroy = function() {
    this._reset(), this.emit("close");
  }, i2.prototype._reset = function() {
    this.writable = false, this._streams = [], this._currentStream = null;
  }, i2.prototype._checkDataSize = function() {
    if (this._updateDataSize(), !(this.dataSize <= this.maxDataSize)) {
      var e5 = "DelayedStream#maxDataSize of " + this.maxDataSize + " bytes exceeded.";
      this._emitError(new Error(e5));
    }
  }, i2.prototype._updateDataSize = function() {
    this.dataSize = 0;
    var e5 = this;
    this._streams.forEach(function(a2) {
      a2.dataSize && (e5.dataSize += a2.dataSize);
    }), this._currentStream && this._currentStream.dataSize && (this.dataSize += this._currentStream.dataSize);
  }, i2.prototype._emitError = function(e5) {
    this._reset(), this.emit("error", e5);
  }, we;
}
["ERR_BAD_OPTION_VALUE", "ERR_BAD_OPTION", "ECONNABORTED", "ETIMEDOUT", "ERR_NETWORK", "ERR_FR_TOO_MANY_REDIRECTS", "ERR_DEPRECATED", "ERR_BAD_RESPONSE", "ERR_BAD_REQUEST", "ERR_CANCELED", "ERR_NOT_SUPPORT", "ERR_INVALID_URL"].forEach((e5) => {
  be[e5] = { value: e5 };
}), Object.defineProperties(xe, be), Object.defineProperty(ve, "isAxiosError", { value: true }), xe.from = (e5, a2, n2, t2, s2, i2) => {
  const o2 = Object.create(ve);
  return fe.toFlatObject(e5, o2, function(e6) {
    return e6 !== Error.prototype;
  }, (e6) => "isAxiosError" !== e6), xe.call(o2, e5.message, a2, n2, t2, s2), o2.cause = e5, o2.name = e5.name, i2 && Object.assign(o2, i2), o2;
};
var je;
var Re;
var Se;
var Ee;
var Te;
var qe;
var Ce;
var Ae;
var Oe;
var Fe;
var De;
var Pe;
var Be;
var Le;
var Ue;
var ze;
var Ie;
var Ne = {};
var Me = { "application/1d-interleaved-parityfec": { source: "iana" }, "application/3gpdash-qoe-report+xml": { source: "iana", charset: "UTF-8", compressible: true }, "application/3gpp-ims+xml": { source: "iana", compressible: true }, "application/3gpphal+json": { source: "iana", compressible: true }, "application/3gpphalforms+json": { source: "iana", compressible: true }, "application/a2l": { source: "iana" }, "application/ace+cbor": { source: "iana" }, "application/activemessage": { source: "iana" }, "application/activity+json": { source: "iana", compressible: true }, "application/alto-costmap+json": { source: "iana", compressible: true }, "application/alto-costmapfilter+json": { source: "iana", compressible: true }, "application/alto-directory+json": { source: "iana", compressible: true }, "application/alto-endpointcost+json": { source: "iana", compressible: true }, "application/alto-endpointcostparams+json": { source: "iana", compressible: true }, "application/alto-endpointprop+json": { source: "iana", compressible: true }, "application/alto-endpointpropparams+json": { source: "iana", compressible: true }, "application/alto-error+json": { source: "iana", compressible: true }, "application/alto-networkmap+json": { source: "iana", compressible: true }, "application/alto-networkmapfilter+json": { source: "iana", compressible: true }, "application/alto-updatestreamcontrol+json": { source: "iana", compressible: true }, "application/alto-updatestreamparams+json": { source: "iana", compressible: true }, "application/aml": { source: "iana" }, "application/andrew-inset": { source: "iana", extensions: ["ez"] }, "application/applefile": { source: "iana" }, "application/applixware": { source: "apache", extensions: ["aw"] }, "application/at+jwt": { source: "iana" }, "application/atf": { source: "iana" }, "application/atfx": { source: "iana" }, "application/atom+xml": { source: "iana", compressible: true, extensions: ["atom"] }, "application/atomcat+xml": { source: "iana", compressible: true, extensions: ["atomcat"] }, "application/atomdeleted+xml": { source: "iana", compressible: true, extensions: ["atomdeleted"] }, "application/atomicmail": { source: "iana" }, "application/atomsvc+xml": { source: "iana", compressible: true, extensions: ["atomsvc"] }, "application/atsc-dwd+xml": { source: "iana", compressible: true, extensions: ["dwd"] }, "application/atsc-dynamic-event-message": { source: "iana" }, "application/atsc-held+xml": { source: "iana", compressible: true, extensions: ["held"] }, "application/atsc-rdt+json": { source: "iana", compressible: true }, "application/atsc-rsat+xml": { source: "iana", compressible: true, extensions: ["rsat"] }, "application/atxml": { source: "iana" }, "application/auth-policy+xml": { source: "iana", compressible: true }, "application/bacnet-xdd+zip": { source: "iana", compressible: false }, "application/batch-smtp": { source: "iana" }, "application/bdoc": { compressible: false, extensions: ["bdoc"] }, "application/beep+xml": { source: "iana", charset: "UTF-8", compressible: true }, "application/calendar+json": { source: "iana", compressible: true }, "application/calendar+xml": { source: "iana", compressible: true, extensions: ["xcs"] }, "application/call-completion": { source: "iana" }, "application/cals-1840": { source: "iana" }, "application/captive+json": { source: "iana", compressible: true }, "application/cbor": { source: "iana" }, "application/cbor-seq": { source: "iana" }, "application/cccex": { source: "iana" }, "application/ccmp+xml": { source: "iana", compressible: true }, "application/ccxml+xml": { source: "iana", compressible: true, extensions: ["ccxml"] }, "application/cdfx+xml": { source: "iana", compressible: true, extensions: ["cdfx"] }, "application/cdmi-capability": { source: "iana", extensions: ["cdmia"] }, "application/cdmi-container": { source: "iana", extensions: ["cdmic"] }, "application/cdmi-domain": { source: "iana", extensions: ["cdmid"] }, "application/cdmi-object": { source: "iana", extensions: ["cdmio"] }, "application/cdmi-queue": { source: "iana", extensions: ["cdmiq"] }, "application/cdni": { source: "iana" }, "application/cea": { source: "iana" }, "application/cea-2018+xml": { source: "iana", compressible: true }, "application/cellml+xml": { source: "iana", compressible: true }, "application/cfw": { source: "iana" }, "application/city+json": { source: "iana", compressible: true }, "application/clr": { source: "iana" }, "application/clue+xml": { source: "iana", compressible: true }, "application/clue_info+xml": { source: "iana", compressible: true }, "application/cms": { source: "iana" }, "application/cnrp+xml": { source: "iana", compressible: true }, "application/coap-group+json": { source: "iana", compressible: true }, "application/coap-payload": { source: "iana" }, "application/commonground": { source: "iana" }, "application/conference-info+xml": { source: "iana", compressible: true }, "application/cose": { source: "iana" }, "application/cose-key": { source: "iana" }, "application/cose-key-set": { source: "iana" }, "application/cpl+xml": { source: "iana", compressible: true, extensions: ["cpl"] }, "application/csrattrs": { source: "iana" }, "application/csta+xml": { source: "iana", compressible: true }, "application/cstadata+xml": { source: "iana", compressible: true }, "application/csvm+json": { source: "iana", compressible: true }, "application/cu-seeme": { source: "apache", extensions: ["cu"] }, "application/cwt": { source: "iana" }, "application/cybercash": { source: "iana" }, "application/dart": { compressible: true }, "application/dash+xml": { source: "iana", compressible: true, extensions: ["mpd"] }, "application/dash-patch+xml": { source: "iana", compressible: true, extensions: ["mpp"] }, "application/dashdelta": { source: "iana" }, "application/davmount+xml": { source: "iana", compressible: true, extensions: ["davmount"] }, "application/dca-rft": { source: "iana" }, "application/dcd": { source: "iana" }, "application/dec-dx": { source: "iana" }, "application/dialog-info+xml": { source: "iana", compressible: true }, "application/dicom": { source: "iana" }, "application/dicom+json": { source: "iana", compressible: true }, "application/dicom+xml": { source: "iana", compressible: true }, "application/dii": { source: "iana" }, "application/dit": { source: "iana" }, "application/dns": { source: "iana" }, "application/dns+json": { source: "iana", compressible: true }, "application/dns-message": { source: "iana" }, "application/docbook+xml": { source: "apache", compressible: true, extensions: ["dbk"] }, "application/dots+cbor": { source: "iana" }, "application/dskpp+xml": { source: "iana", compressible: true }, "application/dssc+der": { source: "iana", extensions: ["dssc"] }, "application/dssc+xml": { source: "iana", compressible: true, extensions: ["xdssc"] }, "application/dvcs": { source: "iana" }, "application/ecmascript": { source: "iana", compressible: true, extensions: ["es", "ecma"] }, "application/edi-consent": { source: "iana" }, "application/edi-x12": { source: "iana", compressible: false }, "application/edifact": { source: "iana", compressible: false }, "application/efi": { source: "iana" }, "application/elm+json": { source: "iana", charset: "UTF-8", compressible: true }, "application/elm+xml": { source: "iana", compressible: true }, "application/emergencycalldata.cap+xml": { source: "iana", charset: "UTF-8", compressible: true }, "application/emergencycalldata.comment+xml": { source: "iana", compressible: true }, "application/emergencycalldata.control+xml": { source: "iana", compressible: true }, "application/emergencycalldata.deviceinfo+xml": { source: "iana", compressible: true }, "application/emergencycalldata.ecall.msd": { source: "iana" }, "application/emergencycalldata.providerinfo+xml": { source: "iana", compressible: true }, "application/emergencycalldata.serviceinfo+xml": { source: "iana", compressible: true }, "application/emergencycalldata.subscriberinfo+xml": { source: "iana", compressible: true }, "application/emergencycalldata.veds+xml": { source: "iana", compressible: true }, "application/emma+xml": { source: "iana", compressible: true, extensions: ["emma"] }, "application/emotionml+xml": { source: "iana", compressible: true, extensions: ["emotionml"] }, "application/encaprtp": { source: "iana" }, "application/epp+xml": { source: "iana", compressible: true }, "application/epub+zip": { source: "iana", compressible: false, extensions: ["epub"] }, "application/eshop": { source: "iana" }, "application/exi": { source: "iana", extensions: ["exi"] }, "application/expect-ct-report+json": { source: "iana", compressible: true }, "application/express": { source: "iana", extensions: ["exp"] }, "application/fastinfoset": { source: "iana" }, "application/fastsoap": { source: "iana" }, "application/fdt+xml": { source: "iana", compressible: true, extensions: ["fdt"] }, "application/fhir+json": { source: "iana", charset: "UTF-8", compressible: true }, "application/fhir+xml": { source: "iana", charset: "UTF-8", compressible: true }, "application/fido.trusted-apps+json": { compressible: true }, "application/fits": { source: "iana" }, "application/flexfec": { source: "iana" }, "application/font-sfnt": { source: "iana" }, "application/font-tdpfr": { source: "iana", extensions: ["pfr"] }, "application/font-woff": { source: "iana", compressible: false }, "application/framework-attributes+xml": { source: "iana", compressible: true }, "application/geo+json": { source: "iana", compressible: true, extensions: ["geojson"] }, "application/geo+json-seq": { source: "iana" }, "application/geopackage+sqlite3": { source: "iana" }, "application/geoxacml+xml": { source: "iana", compressible: true }, "application/gltf-buffer": { source: "iana" }, "application/gml+xml": { source: "iana", compressible: true, extensions: ["gml"] }, "application/gpx+xml": { source: "apache", compressible: true, extensions: ["gpx"] }, "application/gxf": { source: "apache", extensions: ["gxf"] }, "application/gzip": { source: "iana", compressible: false, extensions: ["gz"] }, "application/h224": { source: "iana" }, "application/held+xml": { source: "iana", compressible: true }, "application/hjson": { extensions: ["hjson"] }, "application/http": { source: "iana" }, "application/hyperstudio": { source: "iana", extensions: ["stk"] }, "application/ibe-key-request+xml": { source: "iana", compressible: true }, "application/ibe-pkg-reply+xml": { source: "iana", compressible: true }, "application/ibe-pp-data": { source: "iana" }, "application/iges": { source: "iana" }, "application/im-iscomposing+xml": { source: "iana", charset: "UTF-8", compressible: true }, "application/index": { source: "iana" }, "application/index.cmd": { source: "iana" }, "application/index.obj": { source: "iana" }, "application/index.response": { source: "iana" }, "application/index.vnd": { source: "iana" }, "application/inkml+xml": { source: "iana", compressible: true, extensions: ["ink", "inkml"] }, "application/iotp": { source: "iana" }, "application/ipfix": { source: "iana", extensions: ["ipfix"] }, "application/ipp": { source: "iana" }, "application/isup": { source: "iana" }, "application/its+xml": { source: "iana", compressible: true, extensions: ["its"] }, "application/java-archive": { source: "apache", compressible: false, extensions: ["jar", "war", "ear"] }, "application/java-serialized-object": { source: "apache", compressible: false, extensions: ["ser"] }, "application/java-vm": { source: "apache", compressible: false, extensions: ["class"] }, "application/javascript": { source: "iana", charset: "UTF-8", compressible: true, extensions: ["js", "mjs"] }, "application/jf2feed+json": { source: "iana", compressible: true }, "application/jose": { source: "iana" }, "application/jose+json": { source: "iana", compressible: true }, "application/jrd+json": { source: "iana", compressible: true }, "application/jscalendar+json": { source: "iana", compressible: true }, "application/json": { source: "iana", charset: "UTF-8", compressible: true, extensions: ["json", "map"] }, "application/json-patch+json": { source: "iana", compressible: true }, "application/json-seq": { source: "iana" }, "application/json5": { extensions: ["json5"] }, "application/jsonml+json": { source: "apache", compressible: true, extensions: ["jsonml"] }, "application/jwk+json": { source: "iana", compressible: true }, "application/jwk-set+json": { source: "iana", compressible: true }, "application/jwt": { source: "iana" }, "application/kpml-request+xml": { source: "iana", compressible: true }, "application/kpml-response+xml": { source: "iana", compressible: true }, "application/ld+json": { source: "iana", compressible: true, extensions: ["jsonld"] }, "application/lgr+xml": { source: "iana", compressible: true, extensions: ["lgr"] }, "application/link-format": { source: "iana" }, "application/load-control+xml": { source: "iana", compressible: true }, "application/lost+xml": { source: "iana", compressible: true, extensions: ["lostxml"] }, "application/lostsync+xml": { source: "iana", compressible: true }, "application/lpf+zip": { source: "iana", compressible: false }, "application/lxf": { source: "iana" }, "application/mac-binhex40": { source: "iana", extensions: ["hqx"] }, "application/mac-compactpro": { source: "apache", extensions: ["cpt"] }, "application/macwriteii": { source: "iana" }, "application/mads+xml": { source: "iana", compressible: true, extensions: ["mads"] }, "application/manifest+json": { source: "iana", charset: "UTF-8", compressible: true, extensions: ["webmanifest"] }, "application/marc": { source: "iana", extensions: ["mrc"] }, "application/marcxml+xml": { source: "iana", compressible: true, extensions: ["mrcx"] }, "application/mathematica": { source: "iana", extensions: ["ma", "nb", "mb"] }, "application/mathml+xml": { source: "iana", compressible: true, extensions: ["mathml"] }, "application/mathml-content+xml": { source: "iana", compressible: true }, "application/mathml-presentation+xml": { source: "iana", compressible: true }, "application/mbms-associated-procedure-description+xml": { source: "iana", compressible: true }, "application/mbms-deregister+xml": { source: "iana", compressible: true }, "application/mbms-envelope+xml": { source: "iana", compressible: true }, "application/mbms-msk+xml": { source: "iana", compressible: true }, "application/mbms-msk-response+xml": { source: "iana", compressible: true }, "application/mbms-protection-description+xml": { source: "iana", compressible: true }, "application/mbms-reception-report+xml": { source: "iana", compressible: true }, "application/mbms-register+xml": { source: "iana", compressible: true }, "application/mbms-register-response+xml": { source: "iana", compressible: true }, "application/mbms-schedule+xml": { source: "iana", compressible: true }, "application/mbms-user-service-description+xml": { source: "iana", compressible: true }, "application/mbox": { source: "iana", extensions: ["mbox"] }, "application/media-policy-dataset+xml": { source: "iana", compressible: true, extensions: ["mpf"] }, "application/media_control+xml": { source: "iana", compressible: true }, "application/mediaservercontrol+xml": { source: "iana", compressible: true, extensions: ["mscml"] }, "application/merge-patch+json": { source: "iana", compressible: true }, "application/metalink+xml": { source: "apache", compressible: true, extensions: ["metalink"] }, "application/metalink4+xml": { source: "iana", compressible: true, extensions: ["meta4"] }, "application/mets+xml": { source: "iana", compressible: true, extensions: ["mets"] }, "application/mf4": { source: "iana" }, "application/mikey": { source: "iana" }, "application/mipc": { source: "iana" }, "application/missing-blocks+cbor-seq": { source: "iana" }, "application/mmt-aei+xml": { source: "iana", compressible: true, extensions: ["maei"] }, "application/mmt-usd+xml": { source: "iana", compressible: true, extensions: ["musd"] }, "application/mods+xml": { source: "iana", compressible: true, extensions: ["mods"] }, "application/moss-keys": { source: "iana" }, "application/moss-signature": { source: "iana" }, "application/mosskey-data": { source: "iana" }, "application/mosskey-request": { source: "iana" }, "application/mp21": { source: "iana", extensions: ["m21", "mp21"] }, "application/mp4": { source: "iana", extensions: ["mp4s", "m4p"] }, "application/mpeg4-generic": { source: "iana" }, "application/mpeg4-iod": { source: "iana" }, "application/mpeg4-iod-xmt": { source: "iana" }, "application/mrb-consumer+xml": { source: "iana", compressible: true }, "application/mrb-publish+xml": { source: "iana", compressible: true }, "application/msc-ivr+xml": { source: "iana", charset: "UTF-8", compressible: true }, "application/msc-mixer+xml": { source: "iana", charset: "UTF-8", compressible: true }, "application/msword": { source: "iana", compressible: false, extensions: ["doc", "dot"] }, "application/mud+json": { source: "iana", compressible: true }, "application/multipart-core": { source: "iana" }, "application/mxf": { source: "iana", extensions: ["mxf"] }, "application/n-quads": { source: "iana", extensions: ["nq"] }, "application/n-triples": { source: "iana", extensions: ["nt"] }, "application/nasdata": { source: "iana" }, "application/news-checkgroups": { source: "iana", charset: "US-ASCII" }, "application/news-groupinfo": { source: "iana", charset: "US-ASCII" }, "application/news-transmission": { source: "iana" }, "application/nlsml+xml": { source: "iana", compressible: true }, "application/node": { source: "iana", extensions: ["cjs"] }, "application/nss": { source: "iana" }, "application/oauth-authz-req+jwt": { source: "iana" }, "application/oblivious-dns-message": { source: "iana" }, "application/ocsp-request": { source: "iana" }, "application/ocsp-response": { source: "iana" }, "application/octet-stream": { source: "iana", compressible: false, extensions: ["bin", "dms", "lrf", "mar", "so", "dist", "distz", "pkg", "bpk", "dump", "elc", "deploy", "exe", "dll", "deb", "dmg", "iso", "img", "msi", "msp", "msm", "buffer"] }, "application/oda": { source: "iana", extensions: ["oda"] }, "application/odm+xml": { source: "iana", compressible: true }, "application/odx": { source: "iana" }, "application/oebps-package+xml": { source: "iana", compressible: true, extensions: ["opf"] }, "application/ogg": { source: "iana", compressible: false, extensions: ["ogx"] }, "application/omdoc+xml": { source: "apache", compressible: true, extensions: ["omdoc"] }, "application/onenote": { source: "apache", extensions: ["onetoc", "onetoc2", "onetmp", "onepkg"] }, "application/opc-nodeset+xml": { source: "iana", compressible: true }, "application/oscore": { source: "iana" }, "application/oxps": { source: "iana", extensions: ["oxps"] }, "application/p21": { source: "iana" }, "application/p21+zip": { source: "iana", compressible: false }, "application/p2p-overlay+xml": { source: "iana", compressible: true, extensions: ["relo"] }, "application/parityfec": { source: "iana" }, "application/passport": { source: "iana" }, "application/patch-ops-error+xml": { source: "iana", compressible: true, extensions: ["xer"] }, "application/pdf": { source: "iana", compressible: false, extensions: ["pdf"] }, "application/pdx": { source: "iana" }, "application/pem-certificate-chain": { source: "iana" }, "application/pgp-encrypted": { source: "iana", compressible: false, extensions: ["pgp"] }, "application/pgp-keys": { source: "iana", extensions: ["asc"] }, "application/pgp-signature": { source: "iana", extensions: ["asc", "sig"] }, "application/pics-rules": { source: "apache", extensions: ["prf"] }, "application/pidf+xml": { source: "iana", charset: "UTF-8", compressible: true }, "application/pidf-diff+xml": { source: "iana", charset: "UTF-8", compressible: true }, "application/pkcs10": { source: "iana", extensions: ["p10"] }, "application/pkcs12": { source: "iana" }, "application/pkcs7-mime": { source: "iana", extensions: ["p7m", "p7c"] }, "application/pkcs7-signature": { source: "iana", extensions: ["p7s"] }, "application/pkcs8": { source: "iana", extensions: ["p8"] }, "application/pkcs8-encrypted": { source: "iana" }, "application/pkix-attr-cert": { source: "iana", extensions: ["ac"] }, "application/pkix-cert": { source: "iana", extensions: ["cer"] }, "application/pkix-crl": { source: "iana", extensions: ["crl"] }, "application/pkix-pkipath": { source: "iana", extensions: ["pkipath"] }, "application/pkixcmp": { source: "iana", extensions: ["pki"] }, "application/pls+xml": { source: "iana", compressible: true, extensions: ["pls"] }, "application/poc-settings+xml": { source: "iana", charset: "UTF-8", compressible: true }, "application/postscript": { source: "iana", compressible: true, extensions: ["ai", "eps", "ps"] }, "application/ppsp-tracker+json": { source: "iana", compressible: true }, "application/problem+json": { source: "iana", compressible: true }, "application/problem+xml": { source: "iana", compressible: true }, "application/provenance+xml": { source: "iana", compressible: true, extensions: ["provx"] }, "application/prs.alvestrand.titrax-sheet": { source: "iana" }, "application/prs.cww": { source: "iana", extensions: ["cww"] }, "application/prs.cyn": { source: "iana", charset: "7-BIT" }, "application/prs.hpub+zip": { source: "iana", compressible: false }, "application/prs.nprend": { source: "iana" }, "application/prs.plucker": { source: "iana" }, "application/prs.rdf-xml-crypt": { source: "iana" }, "application/prs.xsf+xml": { source: "iana", compressible: true }, "application/pskc+xml": { source: "iana", compressible: true, extensions: ["pskcxml"] }, "application/pvd+json": { source: "iana", compressible: true }, "application/qsig": { source: "iana" }, "application/raml+yaml": { compressible: true, extensions: ["raml"] }, "application/raptorfec": { source: "iana" }, "application/rdap+json": { source: "iana", compressible: true }, "application/rdf+xml": { source: "iana", compressible: true, extensions: ["rdf", "owl"] }, "application/reginfo+xml": { source: "iana", compressible: true, extensions: ["rif"] }, "application/relax-ng-compact-syntax": { source: "iana", extensions: ["rnc"] }, "application/remote-printing": { source: "iana" }, "application/reputon+json": { source: "iana", compressible: true }, "application/resource-lists+xml": { source: "iana", compressible: true, extensions: ["rl"] }, "application/resource-lists-diff+xml": { source: "iana", compressible: true, extensions: ["rld"] }, "application/rfc+xml": { source: "iana", compressible: true }, "application/riscos": { source: "iana" }, "application/rlmi+xml": { source: "iana", compressible: true }, "application/rls-services+xml": { source: "iana", compressible: true, extensions: ["rs"] }, "application/route-apd+xml": { source: "iana", compressible: true, extensions: ["rapd"] }, "application/route-s-tsid+xml": { source: "iana", compressible: true, extensions: ["sls"] }, "application/route-usd+xml": { source: "iana", compressible: true, extensions: ["rusd"] }, "application/rpki-ghostbusters": { source: "iana", extensions: ["gbr"] }, "application/rpki-manifest": { source: "iana", extensions: ["mft"] }, "application/rpki-publication": { source: "iana" }, "application/rpki-roa": { source: "iana", extensions: ["roa"] }, "application/rpki-updown": { source: "iana" }, "application/rsd+xml": { source: "apache", compressible: true, extensions: ["rsd"] }, "application/rss+xml": { source: "apache", compressible: true, extensions: ["rss"] }, "application/rtf": { source: "iana", compressible: true, extensions: ["rtf"] }, "application/rtploopback": { source: "iana" }, "application/rtx": { source: "iana" }, "application/samlassertion+xml": { source: "iana", compressible: true }, "application/samlmetadata+xml": { source: "iana", compressible: true }, "application/sarif+json": { source: "iana", compressible: true }, "application/sarif-external-properties+json": { source: "iana", compressible: true }, "application/sbe": { source: "iana" }, "application/sbml+xml": { source: "iana", compressible: true, extensions: ["sbml"] }, "application/scaip+xml": { source: "iana", compressible: true }, "application/scim+json": { source: "iana", compressible: true }, "application/scvp-cv-request": { source: "iana", extensions: ["scq"] }, "application/scvp-cv-response": { source: "iana", extensions: ["scs"] }, "application/scvp-vp-request": { source: "iana", extensions: ["spq"] }, "application/scvp-vp-response": { source: "iana", extensions: ["spp"] }, "application/sdp": { source: "iana", extensions: ["sdp"] }, "application/secevent+jwt": { source: "iana" }, "application/senml+cbor": { source: "iana" }, "application/senml+json": { source: "iana", compressible: true }, "application/senml+xml": { source: "iana", compressible: true, extensions: ["senmlx"] }, "application/senml-etch+cbor": { source: "iana" }, "application/senml-etch+json": { source: "iana", compressible: true }, "application/senml-exi": { source: "iana" }, "application/sensml+cbor": { source: "iana" }, "application/sensml+json": { source: "iana", compressible: true }, "application/sensml+xml": { source: "iana", compressible: true, extensions: ["sensmlx"] }, "application/sensml-exi": { source: "iana" }, "application/sep+xml": { source: "iana", compressible: true }, "application/sep-exi": { source: "iana" }, "application/session-info": { source: "iana" }, "application/set-payment": { source: "iana" }, "application/set-payment-initiation": { source: "iana", extensions: ["setpay"] }, "application/set-registration": { source: "iana" }, "application/set-registration-initiation": { source: "iana", extensions: ["setreg"] }, "application/sgml": { source: "iana" }, "application/sgml-open-catalog": { source: "iana" }, "application/shf+xml": { source: "iana", compressible: true, extensions: ["shf"] }, "application/sieve": { source: "iana", extensions: ["siv", "sieve"] }, "application/simple-filter+xml": { source: "iana", compressible: true }, "application/simple-message-summary": { source: "iana" }, "application/simplesymbolcontainer": { source: "iana" }, "application/sipc": { source: "iana" }, "application/slate": { source: "iana" }, "application/smil": { source: "iana" }, "application/smil+xml": { source: "iana", compressible: true, extensions: ["smi", "smil"] }, "application/smpte336m": { source: "iana" }, "application/soap+fastinfoset": { source: "iana" }, "application/soap+xml": { source: "iana", compressible: true }, "application/sparql-query": { source: "iana", extensions: ["rq"] }, "application/sparql-results+xml": { source: "iana", compressible: true, extensions: ["srx"] }, "application/spdx+json": { source: "iana", compressible: true }, "application/spirits-event+xml": { source: "iana", compressible: true }, "application/sql": { source: "iana" }, "application/srgs": { source: "iana", extensions: ["gram"] }, "application/srgs+xml": { source: "iana", compressible: true, extensions: ["grxml"] }, "application/sru+xml": { source: "iana", compressible: true, extensions: ["sru"] }, "application/ssdl+xml": { source: "apache", compressible: true, extensions: ["ssdl"] }, "application/ssml+xml": { source: "iana", compressible: true, extensions: ["ssml"] }, "application/stix+json": { source: "iana", compressible: true }, "application/swid+xml": { source: "iana", compressible: true, extensions: ["swidtag"] }, "application/tamp-apex-update": { source: "iana" }, "application/tamp-apex-update-confirm": { source: "iana" }, "application/tamp-community-update": { source: "iana" }, "application/tamp-community-update-confirm": { source: "iana" }, "application/tamp-error": { source: "iana" }, "application/tamp-sequence-adjust": { source: "iana" }, "application/tamp-sequence-adjust-confirm": { source: "iana" }, "application/tamp-status-query": { source: "iana" }, "application/tamp-status-response": { source: "iana" }, "application/tamp-update": { source: "iana" }, "application/tamp-update-confirm": { source: "iana" }, "application/tar": { compressible: true }, "application/taxii+json": { source: "iana", compressible: true }, "application/td+json": { source: "iana", compressible: true }, "application/tei+xml": { source: "iana", compressible: true, extensions: ["tei", "teicorpus"] }, "application/tetra_isi": { source: "iana" }, "application/thraud+xml": { source: "iana", compressible: true, extensions: ["tfi"] }, "application/timestamp-query": { source: "iana" }, "application/timestamp-reply": { source: "iana" }, "application/timestamped-data": { source: "iana", extensions: ["tsd"] }, "application/tlsrpt+gzip": { source: "iana" }, "application/tlsrpt+json": { source: "iana", compressible: true }, "application/tnauthlist": { source: "iana" }, "application/token-introspection+jwt": { source: "iana" }, "application/toml": { compressible: true, extensions: ["toml"] }, "application/trickle-ice-sdpfrag": { source: "iana" }, "application/trig": { source: "iana", extensions: ["trig"] }, "application/ttml+xml": { source: "iana", compressible: true, extensions: ["ttml"] }, "application/tve-trigger": { source: "iana" }, "application/tzif": { source: "iana" }, "application/tzif-leap": { source: "iana" }, "application/ubjson": { compressible: false, extensions: ["ubj"] }, "application/ulpfec": { source: "iana" }, "application/urc-grpsheet+xml": { source: "iana", compressible: true }, "application/urc-ressheet+xml": { source: "iana", compressible: true, extensions: ["rsheet"] }, "application/urc-targetdesc+xml": { source: "iana", compressible: true, extensions: ["td"] }, "application/urc-uisocketdesc+xml": { source: "iana", compressible: true }, "application/vcard+json": { source: "iana", compressible: true }, "application/vcard+xml": { source: "iana", compressible: true }, "application/vemmi": { source: "iana" }, "application/vividence.scriptfile": { source: "apache" }, "application/vnd.1000minds.decision-model+xml": { source: "iana", compressible: true, extensions: ["1km"] }, "application/vnd.3gpp-prose+xml": { source: "iana", compressible: true }, "application/vnd.3gpp-prose-pc3ch+xml": { source: "iana", compressible: true }, "application/vnd.3gpp-v2x-local-service-information": { source: "iana" }, "application/vnd.3gpp.5gnas": { source: "iana" }, "application/vnd.3gpp.access-transfer-events+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.bsf+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.gmop+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.gtpc": { source: "iana" }, "application/vnd.3gpp.interworking-data": { source: "iana" }, "application/vnd.3gpp.lpp": { source: "iana" }, "application/vnd.3gpp.mc-signalling-ear": { source: "iana" }, "application/vnd.3gpp.mcdata-affiliation-command+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcdata-info+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcdata-payload": { source: "iana" }, "application/vnd.3gpp.mcdata-service-config+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcdata-signalling": { source: "iana" }, "application/vnd.3gpp.mcdata-ue-config+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcdata-user-profile+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcptt-affiliation-command+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcptt-floor-request+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcptt-info+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcptt-location-info+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcptt-mbms-usage-info+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcptt-service-config+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcptt-signed+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcptt-ue-config+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcptt-ue-init-config+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcptt-user-profile+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcvideo-affiliation-command+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcvideo-affiliation-info+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcvideo-info+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcvideo-location-info+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcvideo-mbms-usage-info+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcvideo-service-config+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcvideo-transmission-request+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcvideo-ue-config+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mcvideo-user-profile+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.mid-call+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.ngap": { source: "iana" }, "application/vnd.3gpp.pfcp": { source: "iana" }, "application/vnd.3gpp.pic-bw-large": { source: "iana", extensions: ["plb"] }, "application/vnd.3gpp.pic-bw-small": { source: "iana", extensions: ["psb"] }, "application/vnd.3gpp.pic-bw-var": { source: "iana", extensions: ["pvb"] }, "application/vnd.3gpp.s1ap": { source: "iana" }, "application/vnd.3gpp.sms": { source: "iana" }, "application/vnd.3gpp.sms+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.srvcc-ext+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.srvcc-info+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.state-and-event-info+xml": { source: "iana", compressible: true }, "application/vnd.3gpp.ussd+xml": { source: "iana", compressible: true }, "application/vnd.3gpp2.bcmcsinfo+xml": { source: "iana", compressible: true }, "application/vnd.3gpp2.sms": { source: "iana" }, "application/vnd.3gpp2.tcap": { source: "iana", extensions: ["tcap"] }, "application/vnd.3lightssoftware.imagescal": { source: "iana" }, "application/vnd.3m.post-it-notes": { source: "iana", extensions: ["pwn"] }, "application/vnd.accpac.simply.aso": { source: "iana", extensions: ["aso"] }, "application/vnd.accpac.simply.imp": { source: "iana", extensions: ["imp"] }, "application/vnd.acucobol": { source: "iana", extensions: ["acu"] }, "application/vnd.acucorp": { source: "iana", extensions: ["atc", "acutc"] }, "application/vnd.adobe.air-application-installer-package+zip": { source: "apache", compressible: false, extensions: ["air"] }, "application/vnd.adobe.flash.movie": { source: "iana" }, "application/vnd.adobe.formscentral.fcdt": { source: "iana", extensions: ["fcdt"] }, "application/vnd.adobe.fxp": { source: "iana", extensions: ["fxp", "fxpl"] }, "application/vnd.adobe.partial-upload": { source: "iana" }, "application/vnd.adobe.xdp+xml": { source: "iana", compressible: true, extensions: ["xdp"] }, "application/vnd.adobe.xfdf": { source: "iana", extensions: ["xfdf"] }, "application/vnd.aether.imp": { source: "iana" }, "application/vnd.afpc.afplinedata": { source: "iana" }, "application/vnd.afpc.afplinedata-pagedef": { source: "iana" }, "application/vnd.afpc.cmoca-cmresource": { source: "iana" }, "application/vnd.afpc.foca-charset": { source: "iana" }, "application/vnd.afpc.foca-codedfont": { source: "iana" }, "application/vnd.afpc.foca-codepage": { source: "iana" }, "application/vnd.afpc.modca": { source: "iana" }, "application/vnd.afpc.modca-cmtable": { source: "iana" }, "application/vnd.afpc.modca-formdef": { source: "iana" }, "application/vnd.afpc.modca-mediummap": { source: "iana" }, "application/vnd.afpc.modca-objectcontainer": { source: "iana" }, "application/vnd.afpc.modca-overlay": { source: "iana" }, "application/vnd.afpc.modca-pagesegment": { source: "iana" }, "application/vnd.age": { source: "iana", extensions: ["age"] }, "application/vnd.ah-barcode": { source: "iana" }, "application/vnd.ahead.space": { source: "iana", extensions: ["ahead"] }, "application/vnd.airzip.filesecure.azf": { source: "iana", extensions: ["azf"] }, "application/vnd.airzip.filesecure.azs": { source: "iana", extensions: ["azs"] }, "application/vnd.amadeus+json": { source: "iana", compressible: true }, "application/vnd.amazon.ebook": { source: "apache", extensions: ["azw"] }, "application/vnd.amazon.mobi8-ebook": { source: "iana" }, "application/vnd.americandynamics.acc": { source: "iana", extensions: ["acc"] }, "application/vnd.amiga.ami": { source: "iana", extensions: ["ami"] }, "application/vnd.amundsen.maze+xml": { source: "iana", compressible: true }, "application/vnd.android.ota": { source: "iana" }, "application/vnd.android.package-archive": { source: "apache", compressible: false, extensions: ["apk"] }, "application/vnd.anki": { source: "iana" }, "application/vnd.anser-web-certificate-issue-initiation": { source: "iana", extensions: ["cii"] }, "application/vnd.anser-web-funds-transfer-initiation": { source: "apache", extensions: ["fti"] }, "application/vnd.antix.game-component": { source: "iana", extensions: ["atx"] }, "application/vnd.apache.arrow.file": { source: "iana" }, "application/vnd.apache.arrow.stream": { source: "iana" }, "application/vnd.apache.thrift.binary": { source: "iana" }, "application/vnd.apache.thrift.compact": { source: "iana" }, "application/vnd.apache.thrift.json": { source: "iana" }, "application/vnd.api+json": { source: "iana", compressible: true }, "application/vnd.aplextor.warrp+json": { source: "iana", compressible: true }, "application/vnd.apothekende.reservation+json": { source: "iana", compressible: true }, "application/vnd.apple.installer+xml": { source: "iana", compressible: true, extensions: ["mpkg"] }, "application/vnd.apple.keynote": { source: "iana", extensions: ["key"] }, "application/vnd.apple.mpegurl": { source: "iana", extensions: ["m3u8"] }, "application/vnd.apple.numbers": { source: "iana", extensions: ["numbers"] }, "application/vnd.apple.pages": { source: "iana", extensions: ["pages"] }, "application/vnd.apple.pkpass": { compressible: false, extensions: ["pkpass"] }, "application/vnd.arastra.swi": { source: "iana" }, "application/vnd.aristanetworks.swi": { source: "iana", extensions: ["swi"] }, "application/vnd.artisan+json": { source: "iana", compressible: true }, "application/vnd.artsquare": { source: "iana" }, "application/vnd.astraea-software.iota": { source: "iana", extensions: ["iota"] }, "application/vnd.audiograph": { source: "iana", extensions: ["aep"] }, "application/vnd.autopackage": { source: "iana" }, "application/vnd.avalon+json": { source: "iana", compressible: true }, "application/vnd.avistar+xml": { source: "iana", compressible: true }, "application/vnd.balsamiq.bmml+xml": { source: "iana", compressible: true, extensions: ["bmml"] }, "application/vnd.balsamiq.bmpr": { source: "iana" }, "application/vnd.banana-accounting": { source: "iana" }, "application/vnd.bbf.usp.error": { source: "iana" }, "application/vnd.bbf.usp.msg": { source: "iana" }, "application/vnd.bbf.usp.msg+json": { source: "iana", compressible: true }, "application/vnd.bekitzur-stech+json": { source: "iana", compressible: true }, "application/vnd.bint.med-content": { source: "iana" }, "application/vnd.biopax.rdf+xml": { source: "iana", compressible: true }, "application/vnd.blink-idb-value-wrapper": { source: "iana" }, "application/vnd.blueice.multipass": { source: "iana", extensions: ["mpm"] }, "application/vnd.bluetooth.ep.oob": { source: "iana" }, "application/vnd.bluetooth.le.oob": { source: "iana" }, "application/vnd.bmi": { source: "iana", extensions: ["bmi"] }, "application/vnd.bpf": { source: "iana" }, "application/vnd.bpf3": { source: "iana" }, "application/vnd.businessobjects": { source: "iana", extensions: ["rep"] }, "application/vnd.byu.uapi+json": { source: "iana", compressible: true }, "application/vnd.cab-jscript": { source: "iana" }, "application/vnd.canon-cpdl": { source: "iana" }, "application/vnd.canon-lips": { source: "iana" }, "application/vnd.capasystems-pg+json": { source: "iana", compressible: true }, "application/vnd.cendio.thinlinc.clientconf": { source: "iana" }, "application/vnd.century-systems.tcp_stream": { source: "iana" }, "application/vnd.chemdraw+xml": { source: "iana", compressible: true, extensions: ["cdxml"] }, "application/vnd.chess-pgn": { source: "iana" }, "application/vnd.chipnuts.karaoke-mmd": { source: "iana", extensions: ["mmd"] }, "application/vnd.ciedi": { source: "iana" }, "application/vnd.cinderella": { source: "iana", extensions: ["cdy"] }, "application/vnd.cirpack.isdn-ext": { source: "iana" }, "application/vnd.citationstyles.style+xml": { source: "iana", compressible: true, extensions: ["csl"] }, "application/vnd.claymore": { source: "iana", extensions: ["cla"] }, "application/vnd.cloanto.rp9": { source: "iana", extensions: ["rp9"] }, "application/vnd.clonk.c4group": { source: "iana", extensions: ["c4g", "c4d", "c4f", "c4p", "c4u"] }, "application/vnd.cluetrust.cartomobile-config": { source: "iana", extensions: ["c11amc"] }, "application/vnd.cluetrust.cartomobile-config-pkg": { source: "iana", extensions: ["c11amz"] }, "application/vnd.coffeescript": { source: "iana" }, "application/vnd.collabio.xodocuments.document": { source: "iana" }, "application/vnd.collabio.xodocuments.document-template": { source: "iana" }, "application/vnd.collabio.xodocuments.presentation": { source: "iana" }, "application/vnd.collabio.xodocuments.presentation-template": { source: "iana" }, "application/vnd.collabio.xodocuments.spreadsheet": { source: "iana" }, "application/vnd.collabio.xodocuments.spreadsheet-template": { source: "iana" }, "application/vnd.collection+json": { source: "iana", compressible: true }, "application/vnd.collection.doc+json": { source: "iana", compressible: true }, "application/vnd.collection.next+json": { source: "iana", compressible: true }, "application/vnd.comicbook+zip": { source: "iana", compressible: false }, "application/vnd.comicbook-rar": { source: "iana" }, "application/vnd.commerce-battelle": { source: "iana" }, "application/vnd.commonspace": { source: "iana", extensions: ["csp"] }, "application/vnd.contact.cmsg": { source: "iana", extensions: ["cdbcmsg"] }, "application/vnd.coreos.ignition+json": { source: "iana", compressible: true }, "application/vnd.cosmocaller": { source: "iana", extensions: ["cmc"] }, "application/vnd.crick.clicker": { source: "iana", extensions: ["clkx"] }, "application/vnd.crick.clicker.keyboard": { source: "iana", extensions: ["clkk"] }, "application/vnd.crick.clicker.palette": { source: "iana", extensions: ["clkp"] }, "application/vnd.crick.clicker.template": { source: "iana", extensions: ["clkt"] }, "application/vnd.crick.clicker.wordbank": { source: "iana", extensions: ["clkw"] }, "application/vnd.criticaltools.wbs+xml": { source: "iana", compressible: true, extensions: ["wbs"] }, "application/vnd.cryptii.pipe+json": { source: "iana", compressible: true }, "application/vnd.crypto-shade-file": { source: "iana" }, "application/vnd.cryptomator.encrypted": { source: "iana" }, "application/vnd.cryptomator.vault": { source: "iana" }, "application/vnd.ctc-posml": { source: "iana", extensions: ["pml"] }, "application/vnd.ctct.ws+xml": { source: "iana", compressible: true }, "application/vnd.cups-pdf": { source: "iana" }, "application/vnd.cups-postscript": { source: "iana" }, "application/vnd.cups-ppd": { source: "iana", extensions: ["ppd"] }, "application/vnd.cups-raster": { source: "iana" }, "application/vnd.cups-raw": { source: "iana" }, "application/vnd.curl": { source: "iana" }, "application/vnd.curl.car": { source: "apache", extensions: ["car"] }, "application/vnd.curl.pcurl": { source: "apache", extensions: ["pcurl"] }, "application/vnd.cyan.dean.root+xml": { source: "iana", compressible: true }, "application/vnd.cybank": { source: "iana" }, "application/vnd.cyclonedx+json": { source: "iana", compressible: true }, "application/vnd.cyclonedx+xml": { source: "iana", compressible: true }, "application/vnd.d2l.coursepackage1p0+zip": { source: "iana", compressible: false }, "application/vnd.d3m-dataset": { source: "iana" }, "application/vnd.d3m-problem": { source: "iana" }, "application/vnd.dart": { source: "iana", compressible: true, extensions: ["dart"] }, "application/vnd.data-vision.rdz": { source: "iana", extensions: ["rdz"] }, "application/vnd.datapackage+json": { source: "iana", compressible: true }, "application/vnd.dataresource+json": { source: "iana", compressible: true }, "application/vnd.dbf": { source: "iana", extensions: ["dbf"] }, "application/vnd.debian.binary-package": { source: "iana" }, "application/vnd.dece.data": { source: "iana", extensions: ["uvf", "uvvf", "uvd", "uvvd"] }, "application/vnd.dece.ttml+xml": { source: "iana", compressible: true, extensions: ["uvt", "uvvt"] }, "application/vnd.dece.unspecified": { source: "iana", extensions: ["uvx", "uvvx"] }, "application/vnd.dece.zip": { source: "iana", extensions: ["uvz", "uvvz"] }, "application/vnd.denovo.fcselayout-link": { source: "iana", extensions: ["fe_launch"] }, "application/vnd.desmume.movie": { source: "iana" }, "application/vnd.dir-bi.plate-dl-nosuffix": { source: "iana" }, "application/vnd.dm.delegation+xml": { source: "iana", compressible: true }, "application/vnd.dna": { source: "iana", extensions: ["dna"] }, "application/vnd.document+json": { source: "iana", compressible: true }, "application/vnd.dolby.mlp": { source: "apache", extensions: ["mlp"] }, "application/vnd.dolby.mobile.1": { source: "iana" }, "application/vnd.dolby.mobile.2": { source: "iana" }, "application/vnd.doremir.scorecloud-binary-document": { source: "iana" }, "application/vnd.dpgraph": { source: "iana", extensions: ["dpg"] }, "application/vnd.dreamfactory": { source: "iana", extensions: ["dfac"] }, "application/vnd.drive+json": { source: "iana", compressible: true }, "application/vnd.ds-keypoint": { source: "apache", extensions: ["kpxx"] }, "application/vnd.dtg.local": { source: "iana" }, "application/vnd.dtg.local.flash": { source: "iana" }, "application/vnd.dtg.local.html": { source: "iana" }, "application/vnd.dvb.ait": { source: "iana", extensions: ["ait"] }, "application/vnd.dvb.dvbisl+xml": { source: "iana", compressible: true }, "application/vnd.dvb.dvbj": { source: "iana" }, "application/vnd.dvb.esgcontainer": { source: "iana" }, "application/vnd.dvb.ipdcdftnotifaccess": { source: "iana" }, "application/vnd.dvb.ipdcesgaccess": { source: "iana" }, "application/vnd.dvb.ipdcesgaccess2": { source: "iana" }, "application/vnd.dvb.ipdcesgpdd": { source: "iana" }, "application/vnd.dvb.ipdcroaming": { source: "iana" }, "application/vnd.dvb.iptv.alfec-base": { source: "iana" }, "application/vnd.dvb.iptv.alfec-enhancement": { source: "iana" }, "application/vnd.dvb.notif-aggregate-root+xml": { source: "iana", compressible: true }, "application/vnd.dvb.notif-container+xml": { source: "iana", compressible: true }, "application/vnd.dvb.notif-generic+xml": { source: "iana", compressible: true }, "application/vnd.dvb.notif-ia-msglist+xml": { source: "iana", compressible: true }, "application/vnd.dvb.notif-ia-registration-request+xml": { source: "iana", compressible: true }, "application/vnd.dvb.notif-ia-registration-response+xml": { source: "iana", compressible: true }, "application/vnd.dvb.notif-init+xml": { source: "iana", compressible: true }, "application/vnd.dvb.pfr": { source: "iana" }, "application/vnd.dvb.service": { source: "iana", extensions: ["svc"] }, "application/vnd.dxr": { source: "iana" }, "application/vnd.dynageo": { source: "iana", extensions: ["geo"] }, "application/vnd.dzr": { source: "iana" }, "application/vnd.easykaraoke.cdgdownload": { source: "iana" }, "application/vnd.ecdis-update": { source: "iana" }, "application/vnd.ecip.rlp": { source: "iana" }, "application/vnd.eclipse.ditto+json": { source: "iana", compressible: true }, "application/vnd.ecowin.chart": { source: "iana", extensions: ["mag"] }, "application/vnd.ecowin.filerequest": { source: "iana" }, "application/vnd.ecowin.fileupdate": { source: "iana" }, "application/vnd.ecowin.series": { source: "iana" }, "application/vnd.ecowin.seriesrequest": { source: "iana" }, "application/vnd.ecowin.seriesupdate": { source: "iana" }, "application/vnd.efi.img": { source: "iana" }, "application/vnd.efi.iso": { source: "iana" }, "application/vnd.emclient.accessrequest+xml": { source: "iana", compressible: true }, "application/vnd.enliven": { source: "iana", extensions: ["nml"] }, "application/vnd.enphase.envoy": { source: "iana" }, "application/vnd.eprints.data+xml": { source: "iana", compressible: true }, "application/vnd.epson.esf": { source: "iana", extensions: ["esf"] }, "application/vnd.epson.msf": { source: "iana", extensions: ["msf"] }, "application/vnd.epson.quickanime": { source: "iana", extensions: ["qam"] }, "application/vnd.epson.salt": { source: "iana", extensions: ["slt"] }, "application/vnd.epson.ssf": { source: "iana", extensions: ["ssf"] }, "application/vnd.ericsson.quickcall": { source: "iana" }, "application/vnd.espass-espass+zip": { source: "iana", compressible: false }, "application/vnd.eszigno3+xml": { source: "iana", compressible: true, extensions: ["es3", "et3"] }, "application/vnd.etsi.aoc+xml": { source: "iana", compressible: true }, "application/vnd.etsi.asic-e+zip": { source: "iana", compressible: false }, "application/vnd.etsi.asic-s+zip": { source: "iana", compressible: false }, "application/vnd.etsi.cug+xml": { source: "iana", compressible: true }, "application/vnd.etsi.iptvcommand+xml": { source: "iana", compressible: true }, "application/vnd.etsi.iptvdiscovery+xml": { source: "iana", compressible: true }, "application/vnd.etsi.iptvprofile+xml": { source: "iana", compressible: true }, "application/vnd.etsi.iptvsad-bc+xml": { source: "iana", compressible: true }, "application/vnd.etsi.iptvsad-cod+xml": { source: "iana", compressible: true }, "application/vnd.etsi.iptvsad-npvr+xml": { source: "iana", compressible: true }, "application/vnd.etsi.iptvservice+xml": { source: "iana", compressible: true }, "application/vnd.etsi.iptvsync+xml": { source: "iana", compressible: true }, "application/vnd.etsi.iptvueprofile+xml": { source: "iana", compressible: true }, "application/vnd.etsi.mcid+xml": { source: "iana", compressible: true }, "application/vnd.etsi.mheg5": { source: "iana" }, "application/vnd.etsi.overload-control-policy-dataset+xml": { source: "iana", compressible: true }, "application/vnd.etsi.pstn+xml": { source: "iana", compressible: true }, "application/vnd.etsi.sci+xml": { source: "iana", compressible: true }, "application/vnd.etsi.simservs+xml": { source: "iana", compressible: true }, "application/vnd.etsi.timestamp-token": { source: "iana" }, "application/vnd.etsi.tsl+xml": { source: "iana", compressible: true }, "application/vnd.etsi.tsl.der": { source: "iana" }, "application/vnd.eu.kasparian.car+json": { source: "iana", compressible: true }, "application/vnd.eudora.data": { source: "iana" }, "application/vnd.evolv.ecig.profile": { source: "iana" }, "application/vnd.evolv.ecig.settings": { source: "iana" }, "application/vnd.evolv.ecig.theme": { source: "iana" }, "application/vnd.exstream-empower+zip": { source: "iana", compressible: false }, "application/vnd.exstream-package": { source: "iana" }, "application/vnd.ezpix-album": { source: "iana", extensions: ["ez2"] }, "application/vnd.ezpix-package": { source: "iana", extensions: ["ez3"] }, "application/vnd.f-secure.mobile": { source: "iana" }, "application/vnd.familysearch.gedcom+zip": { source: "iana", compressible: false }, "application/vnd.fastcopy-disk-image": { source: "iana" }, "application/vnd.fdf": { source: "iana", extensions: ["fdf"] }, "application/vnd.fdsn.mseed": { source: "iana", extensions: ["mseed"] }, "application/vnd.fdsn.seed": { source: "iana", extensions: ["seed", "dataless"] }, "application/vnd.ffsns": { source: "iana" }, "application/vnd.ficlab.flb+zip": { source: "iana", compressible: false }, "application/vnd.filmit.zfc": { source: "iana" }, "application/vnd.fints": { source: "iana" }, "application/vnd.firemonkeys.cloudcell": { source: "iana" }, "application/vnd.flographit": { source: "iana", extensions: ["gph"] }, "application/vnd.fluxtime.clip": { source: "iana", extensions: ["ftc"] }, "application/vnd.font-fontforge-sfd": { source: "iana" }, "application/vnd.framemaker": { source: "iana", extensions: ["fm", "frame", "maker", "book"] }, "application/vnd.frogans.fnc": { source: "iana", extensions: ["fnc"] }, "application/vnd.frogans.ltf": { source: "iana", extensions: ["ltf"] }, "application/vnd.fsc.weblaunch": { source: "iana", extensions: ["fsc"] }, "application/vnd.fujifilm.fb.docuworks": { source: "iana" }, "application/vnd.fujifilm.fb.docuworks.binder": { source: "iana" }, "application/vnd.fujifilm.fb.docuworks.container": { source: "iana" }, "application/vnd.fujifilm.fb.jfi+xml": { source: "iana", compressible: true }, "application/vnd.fujitsu.oasys": { source: "iana", extensions: ["oas"] }, "application/vnd.fujitsu.oasys2": { source: "iana", extensions: ["oa2"] }, "application/vnd.fujitsu.oasys3": { source: "iana", extensions: ["oa3"] }, "application/vnd.fujitsu.oasysgp": { source: "iana", extensions: ["fg5"] }, "application/vnd.fujitsu.oasysprs": { source: "iana", extensions: ["bh2"] }, "application/vnd.fujixerox.art-ex": { source: "iana" }, "application/vnd.fujixerox.art4": { source: "iana" }, "application/vnd.fujixerox.ddd": { source: "iana", extensions: ["ddd"] }, "application/vnd.fujixerox.docuworks": { source: "iana", extensions: ["xdw"] }, "application/vnd.fujixerox.docuworks.binder": { source: "iana", extensions: ["xbd"] }, "application/vnd.fujixerox.docuworks.container": { source: "iana" }, "application/vnd.fujixerox.hbpl": { source: "iana" }, "application/vnd.fut-misnet": { source: "iana" }, "application/vnd.futoin+cbor": { source: "iana" }, "application/vnd.futoin+json": { source: "iana", compressible: true }, "application/vnd.fuzzysheet": { source: "iana", extensions: ["fzs"] }, "application/vnd.genomatix.tuxedo": { source: "iana", extensions: ["txd"] }, "application/vnd.gentics.grd+json": { source: "iana", compressible: true }, "application/vnd.geo+json": { source: "iana", compressible: true }, "application/vnd.geocube+xml": { source: "iana", compressible: true }, "application/vnd.geogebra.file": { source: "iana", extensions: ["ggb"] }, "application/vnd.geogebra.slides": { source: "iana" }, "application/vnd.geogebra.tool": { source: "iana", extensions: ["ggt"] }, "application/vnd.geometry-explorer": { source: "iana", extensions: ["gex", "gre"] }, "application/vnd.geonext": { source: "iana", extensions: ["gxt"] }, "application/vnd.geoplan": { source: "iana", extensions: ["g2w"] }, "application/vnd.geospace": { source: "iana", extensions: ["g3w"] }, "application/vnd.gerber": { source: "iana" }, "application/vnd.globalplatform.card-content-mgt": { source: "iana" }, "application/vnd.globalplatform.card-content-mgt-response": { source: "iana" }, "application/vnd.gmx": { source: "iana", extensions: ["gmx"] }, "application/vnd.google-apps.document": { compressible: false, extensions: ["gdoc"] }, "application/vnd.google-apps.presentation": { compressible: false, extensions: ["gslides"] }, "application/vnd.google-apps.spreadsheet": { compressible: false, extensions: ["gsheet"] }, "application/vnd.google-earth.kml+xml": { source: "iana", compressible: true, extensions: ["kml"] }, "application/vnd.google-earth.kmz": { source: "iana", compressible: false, extensions: ["kmz"] }, "application/vnd.gov.sk.e-form+xml": { source: "iana", compressible: true }, "application/vnd.gov.sk.e-form+zip": { source: "iana", compressible: false }, "application/vnd.gov.sk.xmldatacontainer+xml": { source: "iana", compressible: true }, "application/vnd.grafeq": { source: "iana", extensions: ["gqf", "gqs"] }, "application/vnd.gridmp": { source: "iana" }, "application/vnd.groove-account": { source: "iana", extensions: ["gac"] }, "application/vnd.groove-help": { source: "iana", extensions: ["ghf"] }, "application/vnd.groove-identity-message": { source: "iana", extensions: ["gim"] }, "application/vnd.groove-injector": { source: "iana", extensions: ["grv"] }, "application/vnd.groove-tool-message": { source: "iana", extensions: ["gtm"] }, "application/vnd.groove-tool-template": { source: "iana", extensions: ["tpl"] }, "application/vnd.groove-vcard": { source: "iana", extensions: ["vcg"] }, "application/vnd.hal+json": { source: "iana", compressible: true }, "application/vnd.hal+xml": { source: "iana", compressible: true, extensions: ["hal"] }, "application/vnd.handheld-entertainment+xml": { source: "iana", compressible: true, extensions: ["zmm"] }, "application/vnd.hbci": { source: "iana", extensions: ["hbci"] }, "application/vnd.hc+json": { source: "iana", compressible: true }, "application/vnd.hcl-bireports": { source: "iana" }, "application/vnd.hdt": { source: "iana" }, "application/vnd.heroku+json": { source: "iana", compressible: true }, "application/vnd.hhe.lesson-player": { source: "iana", extensions: ["les"] }, "application/vnd.hl7cda+xml": { source: "iana", charset: "UTF-8", compressible: true }, "application/vnd.hl7v2+xml": { source: "iana", charset: "UTF-8", compressible: true }, "application/vnd.hp-hpgl": { source: "iana", extensions: ["hpgl"] }, "application/vnd.hp-hpid": { source: "iana", extensions: ["hpid"] }, "application/vnd.hp-hps": { source: "iana", extensions: ["hps"] }, "application/vnd.hp-jlyt": { source: "iana", extensions: ["jlt"] }, "application/vnd.hp-pcl": { source: "iana", extensions: ["pcl"] }, "application/vnd.hp-pclxl": { source: "iana", extensions: ["pclxl"] }, "application/vnd.httphone": { source: "iana" }, "application/vnd.hydrostatix.sof-data": { source: "iana", extensions: ["sfd-hdstx"] }, "application/vnd.hyper+json": { source: "iana", compressible: true }, "application/vnd.hyper-item+json": { source: "iana", compressible: true }, "application/vnd.hyperdrive+json": { source: "iana", compressible: true }, "application/vnd.hzn-3d-crossword": { source: "iana" }, "application/vnd.ibm.afplinedata": { source: "iana" }, "application/vnd.ibm.electronic-media": { source: "iana" }, "application/vnd.ibm.minipay": { source: "iana", extensions: ["mpy"] }, "application/vnd.ibm.modcap": { source: "iana", extensions: ["afp", "listafp", "list3820"] }, "application/vnd.ibm.rights-management": { source: "iana", extensions: ["irm"] }, "application/vnd.ibm.secure-container": { source: "iana", extensions: ["sc"] }, "application/vnd.iccprofile": { source: "iana", extensions: ["icc", "icm"] }, "application/vnd.ieee.1905": { source: "iana" }, "application/vnd.igloader": { source: "iana", extensions: ["igl"] }, "application/vnd.imagemeter.folder+zip": { source: "iana", compressible: false }, "application/vnd.imagemeter.image+zip": { source: "iana", compressible: false }, "application/vnd.immervision-ivp": { source: "iana", extensions: ["ivp"] }, "application/vnd.immervision-ivu": { source: "iana", extensions: ["ivu"] }, "application/vnd.ims.imsccv1p1": { source: "iana" }, "application/vnd.ims.imsccv1p2": { source: "iana" }, "application/vnd.ims.imsccv1p3": { source: "iana" }, "application/vnd.ims.lis.v2.result+json": { source: "iana", compressible: true }, "application/vnd.ims.lti.v2.toolconsumerprofile+json": { source: "iana", compressible: true }, "application/vnd.ims.lti.v2.toolproxy+json": { source: "iana", compressible: true }, "application/vnd.ims.lti.v2.toolproxy.id+json": { source: "iana", compressible: true }, "application/vnd.ims.lti.v2.toolsettings+json": { source: "iana", compressible: true }, "application/vnd.ims.lti.v2.toolsettings.simple+json": { source: "iana", compressible: true }, "application/vnd.informedcontrol.rms+xml": { source: "iana", compressible: true }, "application/vnd.informix-visionary": { source: "iana" }, "application/vnd.infotech.project": { source: "iana" }, "application/vnd.infotech.project+xml": { source: "iana", compressible: true }, "application/vnd.innopath.wamp.notification": { source: "iana" }, "application/vnd.insors.igm": { source: "iana", extensions: ["igm"] }, "application/vnd.intercon.formnet": { source: "iana", extensions: ["xpw", "xpx"] }, "application/vnd.intergeo": { source: "iana", extensions: ["i2g"] }, "application/vnd.intertrust.digibox": { source: "iana" }, "application/vnd.intertrust.nncp": { source: "iana" }, "application/vnd.intu.qbo": { source: "iana", extensions: ["qbo"] }, "application/vnd.intu.qfx": { source: "iana", extensions: ["qfx"] }, "application/vnd.iptc.g2.catalogitem+xml": { source: "iana", compressible: true }, "application/vnd.iptc.g2.conceptitem+xml": { source: "iana", compressible: true }, "application/vnd.iptc.g2.knowledgeitem+xml": { source: "iana", compressible: true }, "application/vnd.iptc.g2.newsitem+xml": { source: "iana", compressible: true }, "application/vnd.iptc.g2.newsmessage+xml": { source: "iana", compressible: true }, "application/vnd.iptc.g2.packageitem+xml": { source: "iana", compressible: true }, "application/vnd.iptc.g2.planningitem+xml": { source: "iana", compressible: true }, "application/vnd.ipunplugged.rcprofile": { source: "iana", extensions: ["rcprofile"] }, "application/vnd.irepository.package+xml": { source: "iana", compressible: true, extensions: ["irp"] }, "application/vnd.is-xpr": { source: "iana", extensions: ["xpr"] }, "application/vnd.isac.fcs": { source: "iana", extensions: ["fcs"] }, "application/vnd.iso11783-10+zip": { source: "iana", compressible: false }, "application/vnd.jam": { source: "iana", extensions: ["jam"] }, "application/vnd.japannet-directory-service": { source: "iana" }, "application/vnd.japannet-jpnstore-wakeup": { source: "iana" }, "application/vnd.japannet-payment-wakeup": { source: "iana" }, "application/vnd.japannet-registration": { source: "iana" }, "application/vnd.japannet-registration-wakeup": { source: "iana" }, "application/vnd.japannet-setstore-wakeup": { source: "iana" }, "application/vnd.japannet-verification": { source: "iana" }, "application/vnd.japannet-verification-wakeup": { source: "iana" }, "application/vnd.jcp.javame.midlet-rms": { source: "iana", extensions: ["rms"] }, "application/vnd.jisp": { source: "iana", extensions: ["jisp"] }, "application/vnd.joost.joda-archive": { source: "iana", extensions: ["joda"] }, "application/vnd.jsk.isdn-ngn": { source: "iana" }, "application/vnd.kahootz": { source: "iana", extensions: ["ktz", "ktr"] }, "application/vnd.kde.karbon": { source: "iana", extensions: ["karbon"] }, "application/vnd.kde.kchart": { source: "iana", extensions: ["chrt"] }, "application/vnd.kde.kformula": { source: "iana", extensions: ["kfo"] }, "application/vnd.kde.kivio": { source: "iana", extensions: ["flw"] }, "application/vnd.kde.kontour": { source: "iana", extensions: ["kon"] }, "application/vnd.kde.kpresenter": { source: "iana", extensions: ["kpr", "kpt"] }, "application/vnd.kde.kspread": { source: "iana", extensions: ["ksp"] }, "application/vnd.kde.kword": { source: "iana", extensions: ["kwd", "kwt"] }, "application/vnd.kenameaapp": { source: "iana", extensions: ["htke"] }, "application/vnd.kidspiration": { source: "iana", extensions: ["kia"] }, "application/vnd.kinar": { source: "iana", extensions: ["kne", "knp"] }, "application/vnd.koan": { source: "iana", extensions: ["skp", "skd", "skt", "skm"] }, "application/vnd.kodak-descriptor": { source: "iana", extensions: ["sse"] }, "application/vnd.las": { source: "iana" }, "application/vnd.las.las+json": { source: "iana", compressible: true }, "application/vnd.las.las+xml": { source: "iana", compressible: true, extensions: ["lasxml"] }, "application/vnd.laszip": { source: "iana" }, "application/vnd.leap+json": { source: "iana", compressible: true }, "application/vnd.liberty-request+xml": { source: "iana", compressible: true }, "application/vnd.llamagraphics.life-balance.desktop": { source: "iana", extensions: ["lbd"] }, "application/vnd.llamagraphics.life-balance.exchange+xml": { source: "iana", compressible: true, extensions: ["lbe"] }, "application/vnd.logipipe.circuit+zip": { source: "iana", compressible: false }, "application/vnd.loom": { source: "iana" }, "application/vnd.lotus-1-2-3": { source: "iana", extensions: ["123"] }, "application/vnd.lotus-approach": { source: "iana", extensions: ["apr"] }, "application/vnd.lotus-freelance": { source: "iana", extensions: ["pre"] }, "application/vnd.lotus-notes": { source: "iana", extensions: ["nsf"] }, "application/vnd.lotus-organizer": { source: "iana", extensions: ["org"] }, "application/vnd.lotus-screencam": { source: "iana", extensions: ["scm"] }, "application/vnd.lotus-wordpro": { source: "iana", extensions: ["lwp"] }, "application/vnd.macports.portpkg": { source: "iana", extensions: ["portpkg"] }, "application/vnd.mapbox-vector-tile": { source: "iana", extensions: ["mvt"] }, "application/vnd.marlin.drm.actiontoken+xml": { source: "iana", compressible: true }, "application/vnd.marlin.drm.conftoken+xml": { source: "iana", compressible: true }, "application/vnd.marlin.drm.license+xml": { source: "iana", compressible: true }, "application/vnd.marlin.drm.mdcf": { source: "iana" }, "application/vnd.mason+json": { source: "iana", compressible: true }, "application/vnd.maxar.archive.3tz+zip": { source: "iana", compressible: false }, "application/vnd.maxmind.maxmind-db": { source: "iana" }, "application/vnd.mcd": { source: "iana", extensions: ["mcd"] }, "application/vnd.medcalcdata": { source: "iana", extensions: ["mc1"] }, "application/vnd.mediastation.cdkey": { source: "iana", extensions: ["cdkey"] }, "application/vnd.meridian-slingshot": { source: "iana" }, "application/vnd.mfer": { source: "iana", extensions: ["mwf"] }, "application/vnd.mfmp": { source: "iana", extensions: ["mfm"] }, "application/vnd.micro+json": { source: "iana", compressible: true }, "application/vnd.micrografx.flo": { source: "iana", extensions: ["flo"] }, "application/vnd.micrografx.igx": { source: "iana", extensions: ["igx"] }, "application/vnd.microsoft.portable-executable": { source: "iana" }, "application/vnd.microsoft.windows.thumbnail-cache": { source: "iana" }, "application/vnd.miele+json": { source: "iana", compressible: true }, "application/vnd.mif": { source: "iana", extensions: ["mif"] }, "application/vnd.minisoft-hp3000-save": { source: "iana" }, "application/vnd.mitsubishi.misty-guard.trustweb": { source: "iana" }, "application/vnd.mobius.daf": { source: "iana", extensions: ["daf"] }, "application/vnd.mobius.dis": { source: "iana", extensions: ["dis"] }, "application/vnd.mobius.mbk": { source: "iana", extensions: ["mbk"] }, "application/vnd.mobius.mqy": { source: "iana", extensions: ["mqy"] }, "application/vnd.mobius.msl": { source: "iana", extensions: ["msl"] }, "application/vnd.mobius.plc": { source: "iana", extensions: ["plc"] }, "application/vnd.mobius.txf": { source: "iana", extensions: ["txf"] }, "application/vnd.mophun.application": { source: "iana", extensions: ["mpn"] }, "application/vnd.mophun.certificate": { source: "iana", extensions: ["mpc"] }, "application/vnd.motorola.flexsuite": { source: "iana" }, "application/vnd.motorola.flexsuite.adsi": { source: "iana" }, "application/vnd.motorola.flexsuite.fis": { source: "iana" }, "application/vnd.motorola.flexsuite.gotap": { source: "iana" }, "application/vnd.motorola.flexsuite.kmr": { source: "iana" }, "application/vnd.motorola.flexsuite.ttc": { source: "iana" }, "application/vnd.motorola.flexsuite.wem": { source: "iana" }, "application/vnd.motorola.iprm": { source: "iana" }, "application/vnd.mozilla.xul+xml": { source: "iana", compressible: true, extensions: ["xul"] }, "application/vnd.ms-3mfdocument": { source: "iana" }, "application/vnd.ms-artgalry": { source: "iana", extensions: ["cil"] }, "application/vnd.ms-asf": { source: "iana" }, "application/vnd.ms-cab-compressed": { source: "iana", extensions: ["cab"] }, "application/vnd.ms-color.iccprofile": { source: "apache" }, "application/vnd.ms-excel": { source: "iana", compressible: false, extensions: ["xls", "xlm", "xla", "xlc", "xlt", "xlw"] }, "application/vnd.ms-excel.addin.macroenabled.12": { source: "iana", extensions: ["xlam"] }, "application/vnd.ms-excel.sheet.binary.macroenabled.12": { source: "iana", extensions: ["xlsb"] }, "application/vnd.ms-excel.sheet.macroenabled.12": { source: "iana", extensions: ["xlsm"] }, "application/vnd.ms-excel.template.macroenabled.12": { source: "iana", extensions: ["xltm"] }, "application/vnd.ms-fontobject": { source: "iana", compressible: true, extensions: ["eot"] }, "application/vnd.ms-htmlhelp": { source: "iana", extensions: ["chm"] }, "application/vnd.ms-ims": { source: "iana", extensions: ["ims"] }, "application/vnd.ms-lrm": { source: "iana", extensions: ["lrm"] }, "application/vnd.ms-office.activex+xml": { source: "iana", compressible: true }, "application/vnd.ms-officetheme": { source: "iana", extensions: ["thmx"] }, "application/vnd.ms-opentype": { source: "apache", compressible: true }, "application/vnd.ms-outlook": { compressible: false, extensions: ["msg"] }, "application/vnd.ms-package.obfuscated-opentype": { source: "apache" }, "application/vnd.ms-pki.seccat": { source: "apache", extensions: ["cat"] }, "application/vnd.ms-pki.stl": { source: "apache", extensions: ["stl"] }, "application/vnd.ms-playready.initiator+xml": { source: "iana", compressible: true }, "application/vnd.ms-powerpoint": { source: "iana", compressible: false, extensions: ["ppt", "pps", "pot"] }, "application/vnd.ms-powerpoint.addin.macroenabled.12": { source: "iana", extensions: ["ppam"] }, "application/vnd.ms-powerpoint.presentation.macroenabled.12": { source: "iana", extensions: ["pptm"] }, "application/vnd.ms-powerpoint.slide.macroenabled.12": { source: "iana", extensions: ["sldm"] }, "application/vnd.ms-powerpoint.slideshow.macroenabled.12": { source: "iana", extensions: ["ppsm"] }, "application/vnd.ms-powerpoint.template.macroenabled.12": { source: "iana", extensions: ["potm"] }, "application/vnd.ms-printdevicecapabilities+xml": { source: "iana", compressible: true }, "application/vnd.ms-printing.printticket+xml": { source: "apache", compressible: true }, "application/vnd.ms-printschematicket+xml": { source: "iana", compressible: true }, "application/vnd.ms-project": { source: "iana", extensions: ["mpp", "mpt"] }, "application/vnd.ms-tnef": { source: "iana" }, "application/vnd.ms-windows.devicepairing": { source: "iana" }, "application/vnd.ms-windows.nwprinting.oob": { source: "iana" }, "application/vnd.ms-windows.printerpairing": { source: "iana" }, "application/vnd.ms-windows.wsd.oob": { source: "iana" }, "application/vnd.ms-wmdrm.lic-chlg-req": { source: "iana" }, "application/vnd.ms-wmdrm.lic-resp": { source: "iana" }, "application/vnd.ms-wmdrm.meter-chlg-req": { source: "iana" }, "application/vnd.ms-wmdrm.meter-resp": { source: "iana" }, "application/vnd.ms-word.document.macroenabled.12": { source: "iana", extensions: ["docm"] }, "application/vnd.ms-word.template.macroenabled.12": { source: "iana", extensions: ["dotm"] }, "application/vnd.ms-works": { source: "iana", extensions: ["wps", "wks", "wcm", "wdb"] }, "application/vnd.ms-wpl": { source: "iana", extensions: ["wpl"] }, "application/vnd.ms-xpsdocument": { source: "iana", compressible: false, extensions: ["xps"] }, "application/vnd.msa-disk-image": { source: "iana" }, "application/vnd.mseq": { source: "iana", extensions: ["mseq"] }, "application/vnd.msign": { source: "iana" }, "application/vnd.multiad.creator": { source: "iana" }, "application/vnd.multiad.creator.cif": { source: "iana" }, "application/vnd.music-niff": { source: "iana" }, "application/vnd.musician": { source: "iana", extensions: ["mus"] }, "application/vnd.muvee.style": { source: "iana", extensions: ["msty"] }, "application/vnd.mynfc": { source: "iana", extensions: ["taglet"] }, "application/vnd.nacamar.ybrid+json": { source: "iana", compressible: true }, "application/vnd.ncd.control": { source: "iana" }, "application/vnd.ncd.reference": { source: "iana" }, "application/vnd.nearst.inv+json": { source: "iana", compressible: true }, "application/vnd.nebumind.line": { source: "iana" }, "application/vnd.nervana": { source: "iana" }, "application/vnd.netfpx": { source: "iana" }, "application/vnd.neurolanguage.nlu": { source: "iana", extensions: ["nlu"] }, "application/vnd.nimn": { source: "iana" }, "application/vnd.nintendo.nitro.rom": { source: "iana" }, "application/vnd.nintendo.snes.rom": { source: "iana" }, "application/vnd.nitf": { source: "iana", extensions: ["ntf", "nitf"] }, "application/vnd.noblenet-directory": { source: "iana", extensions: ["nnd"] }, "application/vnd.noblenet-sealer": { source: "iana", extensions: ["nns"] }, "application/vnd.noblenet-web": { source: "iana", extensions: ["nnw"] }, "application/vnd.nokia.catalogs": { source: "iana" }, "application/vnd.nokia.conml+wbxml": { source: "iana" }, "application/vnd.nokia.conml+xml": { source: "iana", compressible: true }, "application/vnd.nokia.iptv.config+xml": { source: "iana", compressible: true }, "application/vnd.nokia.isds-radio-presets": { source: "iana" }, "application/vnd.nokia.landmark+wbxml": { source: "iana" }, "application/vnd.nokia.landmark+xml": { source: "iana", compressible: true }, "application/vnd.nokia.landmarkcollection+xml": { source: "iana", compressible: true }, "application/vnd.nokia.n-gage.ac+xml": { source: "iana", compressible: true, extensions: ["ac"] }, "application/vnd.nokia.n-gage.data": { source: "iana", extensions: ["ngdat"] }, "application/vnd.nokia.n-gage.symbian.install": { source: "iana", extensions: ["n-gage"] }, "application/vnd.nokia.ncd": { source: "iana" }, "application/vnd.nokia.pcd+wbxml": { source: "iana" }, "application/vnd.nokia.pcd+xml": { source: "iana", compressible: true }, "application/vnd.nokia.radio-preset": { source: "iana", extensions: ["rpst"] }, "application/vnd.nokia.radio-presets": { source: "iana", extensions: ["rpss"] }, "application/vnd.novadigm.edm": { source: "iana", extensions: ["edm"] }, "application/vnd.novadigm.edx": { source: "iana", extensions: ["edx"] }, "application/vnd.novadigm.ext": { source: "iana", extensions: ["ext"] }, "application/vnd.ntt-local.content-share": { source: "iana" }, "application/vnd.ntt-local.file-transfer": { source: "iana" }, "application/vnd.ntt-local.ogw_remote-access": { source: "iana" }, "application/vnd.ntt-local.sip-ta_remote": { source: "iana" }, "application/vnd.ntt-local.sip-ta_tcp_stream": { source: "iana" }, "application/vnd.oasis.opendocument.chart": { source: "iana", extensions: ["odc"] }, "application/vnd.oasis.opendocument.chart-template": { source: "iana", extensions: ["otc"] }, "application/vnd.oasis.opendocument.database": { source: "iana", extensions: ["odb"] }, "application/vnd.oasis.opendocument.formula": { source: "iana", extensions: ["odf"] }, "application/vnd.oasis.opendocument.formula-template": { source: "iana", extensions: ["odft"] }, "application/vnd.oasis.opendocument.graphics": { source: "iana", compressible: false, extensions: ["odg"] }, "application/vnd.oasis.opendocument.graphics-template": { source: "iana", extensions: ["otg"] }, "application/vnd.oasis.opendocument.image": { source: "iana", extensions: ["odi"] }, "application/vnd.oasis.opendocument.image-template": { source: "iana", extensions: ["oti"] }, "application/vnd.oasis.opendocument.presentation": { source: "iana", compressible: false, extensions: ["odp"] }, "application/vnd.oasis.opendocument.presentation-template": { source: "iana", extensions: ["otp"] }, "application/vnd.oasis.opendocument.spreadsheet": { source: "iana", compressible: false, extensions: ["ods"] }, "application/vnd.oasis.opendocument.spreadsheet-template": { source: "iana", extensions: ["ots"] }, "application/vnd.oasis.opendocument.text": { source: "iana", compressible: false, extensions: ["odt"] }, "application/vnd.oasis.opendocument.text-master": { source: "iana", extensions: ["odm"] }, "application/vnd.oasis.opendocument.text-template": { source: "iana", extensions: ["ott"] }, "application/vnd.oasis.opendocument.text-web": { source: "iana", extensions: ["oth"] }, "application/vnd.obn": { source: "iana" }, "application/vnd.ocf+cbor": { source: "iana" }, "application/vnd.oci.image.manifest.v1+json": { source: "iana", compressible: true }, "application/vnd.oftn.l10n+json": { source: "iana", compressible: true }, "application/vnd.oipf.contentaccessdownload+xml": { source: "iana", compressible: true }, "application/vnd.oipf.contentaccessstreaming+xml": { source: "iana", compressible: true }, "application/vnd.oipf.cspg-hexbinary": { source: "iana" }, "application/vnd.oipf.dae.svg+xml": { source: "iana", compressible: true }, "application/vnd.oipf.dae.xhtml+xml": { source: "iana", compressible: true }, "application/vnd.oipf.mippvcontrolmessage+xml": { source: "iana", compressible: true }, "application/vnd.oipf.pae.gem": { source: "iana" }, "application/vnd.oipf.spdiscovery+xml": { source: "iana", compressible: true }, "application/vnd.oipf.spdlist+xml": { source: "iana", compressible: true }, "application/vnd.oipf.ueprofile+xml": { source: "iana", compressible: true }, "application/vnd.oipf.userprofile+xml": { source: "iana", compressible: true }, "application/vnd.olpc-sugar": { source: "iana", extensions: ["xo"] }, "application/vnd.oma-scws-config": { source: "iana" }, "application/vnd.oma-scws-http-request": { source: "iana" }, "application/vnd.oma-scws-http-response": { source: "iana" }, "application/vnd.oma.bcast.associated-procedure-parameter+xml": { source: "iana", compressible: true }, "application/vnd.oma.bcast.drm-trigger+xml": { source: "iana", compressible: true }, "application/vnd.oma.bcast.imd+xml": { source: "iana", compressible: true }, "application/vnd.oma.bcast.ltkm": { source: "iana" }, "application/vnd.oma.bcast.notification+xml": { source: "iana", compressible: true }, "application/vnd.oma.bcast.provisioningtrigger": { source: "iana" }, "application/vnd.oma.bcast.sgboot": { source: "iana" }, "application/vnd.oma.bcast.sgdd+xml": { source: "iana", compressible: true }, "application/vnd.oma.bcast.sgdu": { source: "iana" }, "application/vnd.oma.bcast.simple-symbol-container": { source: "iana" }, "application/vnd.oma.bcast.smartcard-trigger+xml": { source: "iana", compressible: true }, "application/vnd.oma.bcast.sprov+xml": { source: "iana", compressible: true }, "application/vnd.oma.bcast.stkm": { source: "iana" }, "application/vnd.oma.cab-address-book+xml": { source: "iana", compressible: true }, "application/vnd.oma.cab-feature-handler+xml": { source: "iana", compressible: true }, "application/vnd.oma.cab-pcc+xml": { source: "iana", compressible: true }, "application/vnd.oma.cab-subs-invite+xml": { source: "iana", compressible: true }, "application/vnd.oma.cab-user-prefs+xml": { source: "iana", compressible: true }, "application/vnd.oma.dcd": { source: "iana" }, "application/vnd.oma.dcdc": { source: "iana" }, "application/vnd.oma.dd2+xml": { source: "iana", compressible: true, extensions: ["dd2"] }, "application/vnd.oma.drm.risd+xml": { source: "iana", compressible: true }, "application/vnd.oma.group-usage-list+xml": { source: "iana", compressible: true }, "application/vnd.oma.lwm2m+cbor": { source: "iana" }, "application/vnd.oma.lwm2m+json": { source: "iana", compressible: true }, "application/vnd.oma.lwm2m+tlv": { source: "iana" }, "application/vnd.oma.pal+xml": { source: "iana", compressible: true }, "application/vnd.oma.poc.detailed-progress-report+xml": { source: "iana", compressible: true }, "application/vnd.oma.poc.final-report+xml": { source: "iana", compressible: true }, "application/vnd.oma.poc.groups+xml": { source: "iana", compressible: true }, "application/vnd.oma.poc.invocation-descriptor+xml": { source: "iana", compressible: true }, "application/vnd.oma.poc.optimized-progress-report+xml": { source: "iana", compressible: true }, "application/vnd.oma.push": { source: "iana" }, "application/vnd.oma.scidm.messages+xml": { source: "iana", compressible: true }, "application/vnd.oma.xcap-directory+xml": { source: "iana", compressible: true }, "application/vnd.omads-email+xml": { source: "iana", charset: "UTF-8", compressible: true }, "application/vnd.omads-file+xml": { source: "iana", charset: "UTF-8", compressible: true }, "application/vnd.omads-folder+xml": { source: "iana", charset: "UTF-8", compressible: true }, "application/vnd.omaloc-supl-init": { source: "iana" }, "application/vnd.onepager": { source: "iana" }, "application/vnd.onepagertamp": { source: "iana" }, "application/vnd.onepagertamx": { source: "iana" }, "application/vnd.onepagertat": { source: "iana" }, "application/vnd.onepagertatp": { source: "iana" }, "application/vnd.onepagertatx": { source: "iana" }, "application/vnd.openblox.game+xml": { source: "iana", compressible: true, extensions: ["obgx"] }, "application/vnd.openblox.game-binary": { source: "iana" }, "application/vnd.openeye.oeb": { source: "iana" }, "application/vnd.openofficeorg.extension": { source: "apache", extensions: ["oxt"] }, "application/vnd.openstreetmap.data+xml": { source: "iana", compressible: true, extensions: ["osm"] }, "application/vnd.opentimestamps.ots": { source: "iana" }, "application/vnd.openxmlformats-officedocument.custom-properties+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.customxmlproperties+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.drawing+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.drawingml.chart+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.drawingml.chartshapes+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.drawingml.diagramcolors+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.drawingml.diagramdata+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.drawingml.diagramlayout+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.drawingml.diagramstyle+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.extended-properties+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.presentationml.commentauthors+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.presentationml.comments+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.presentationml.handoutmaster+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.presentationml.notesmaster+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.presentationml.notesslide+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.presentationml.presentation": { source: "iana", compressible: false, extensions: ["pptx"] }, "application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.presentationml.presprops+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.presentationml.slide": { source: "iana", extensions: ["sldx"] }, "application/vnd.openxmlformats-officedocument.presentationml.slide+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.presentationml.slidelayout+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.presentationml.slidemaster+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.presentationml.slideshow": { source: "iana", extensions: ["ppsx"] }, "application/vnd.openxmlformats-officedocument.presentationml.slideshow.main+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.presentationml.slideupdateinfo+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.presentationml.tablestyles+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.presentationml.tags+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.presentationml.template": { source: "iana", extensions: ["potx"] }, "application/vnd.openxmlformats-officedocument.presentationml.template.main+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.presentationml.viewprops+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.calcchain+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.chartsheet+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.connections+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.dialogsheet+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.externallink+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotcachedefinition+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotcacherecords+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.pivottable+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.querytable+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.revisionheaders+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.revisionlog+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedstrings+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": { source: "iana", compressible: false, extensions: ["xlsx"] }, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheetmetadata+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.tablesinglecells+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.template": { source: "iana", extensions: ["xltx"] }, "application/vnd.openxmlformats-officedocument.spreadsheetml.template.main+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.usernames+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.volatiledependencies+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.theme+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.themeoverride+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.vmldrawing": { source: "iana" }, "application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.wordprocessingml.document": { source: "iana", compressible: false, extensions: ["docx"] }, "application/vnd.openxmlformats-officedocument.wordprocessingml.document.glossary+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.wordprocessingml.endnotes+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.wordprocessingml.fonttable+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.wordprocessingml.template": { source: "iana", extensions: ["dotx"] }, "application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-officedocument.wordprocessingml.websettings+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-package.core-properties+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-package.digital-signature-xmlsignature+xml": { source: "iana", compressible: true }, "application/vnd.openxmlformats-package.relationships+xml": { source: "iana", compressible: true }, "application/vnd.oracle.resource+json": { source: "iana", compressible: true }, "application/vnd.orange.indata": { source: "iana" }, "application/vnd.osa.netdeploy": { source: "iana" }, "application/vnd.osgeo.mapguide.package": { source: "iana", extensions: ["mgp"] }, "application/vnd.osgi.bundle": { source: "iana" }, "application/vnd.osgi.dp": { source: "iana", extensions: ["dp"] }, "application/vnd.osgi.subsystem": { source: "iana", extensions: ["esa"] }, "application/vnd.otps.ct-kip+xml": { source: "iana", compressible: true }, "application/vnd.oxli.countgraph": { source: "iana" }, "application/vnd.pagerduty+json": { source: "iana", compressible: true }, "application/vnd.palm": { source: "iana", extensions: ["pdb", "pqa", "oprc"] }, "application/vnd.panoply": { source: "iana" }, "application/vnd.paos.xml": { source: "iana" }, "application/vnd.patentdive": { source: "iana" }, "application/vnd.patientecommsdoc": { source: "iana" }, "application/vnd.pawaafile": { source: "iana", extensions: ["paw"] }, "application/vnd.pcos": { source: "iana" }, "application/vnd.pg.format": { source: "iana", extensions: ["str"] }, "application/vnd.pg.osasli": { source: "iana", extensions: ["ei6"] }, "application/vnd.piaccess.application-licence": { source: "iana" }, "application/vnd.picsel": { source: "iana", extensions: ["efif"] }, "application/vnd.pmi.widget": { source: "iana", extensions: ["wg"] }, "application/vnd.poc.group-advertisement+xml": { source: "iana", compressible: true }, "application/vnd.pocketlearn": { source: "iana", extensions: ["plf"] }, "application/vnd.powerbuilder6": { source: "iana", extensions: ["pbd"] }, "application/vnd.powerbuilder6-s": { source: "iana" }, "application/vnd.powerbuilder7": { source: "iana" }, "application/vnd.powerbuilder7-s": { source: "iana" }, "application/vnd.powerbuilder75": { source: "iana" }, "application/vnd.powerbuilder75-s": { source: "iana" }, "application/vnd.preminet": { source: "iana" }, "application/vnd.previewsystems.box": { source: "iana", extensions: ["box"] }, "application/vnd.proteus.magazine": { source: "iana", extensions: ["mgz"] }, "application/vnd.psfs": { source: "iana" }, "application/vnd.publishare-delta-tree": { source: "iana", extensions: ["qps"] }, "application/vnd.pvi.ptid1": { source: "iana", extensions: ["ptid"] }, "application/vnd.pwg-multiplexed": { source: "iana" }, "application/vnd.pwg-xhtml-print+xml": { source: "iana", compressible: true }, "application/vnd.qualcomm.brew-app-res": { source: "iana" }, "application/vnd.quarantainenet": { source: "iana" }, "application/vnd.quark.quarkxpress": { source: "iana", extensions: ["qxd", "qxt", "qwd", "qwt", "qxl", "qxb"] }, "application/vnd.quobject-quoxdocument": { source: "iana" }, "application/vnd.radisys.moml+xml": { source: "iana", compressible: true }, "application/vnd.radisys.msml+xml": { source: "iana", compressible: true }, "application/vnd.radisys.msml-audit+xml": { source: "iana", compressible: true }, "application/vnd.radisys.msml-audit-conf+xml": { source: "iana", compressible: true }, "application/vnd.radisys.msml-audit-conn+xml": { source: "iana", compressible: true }, "application/vnd.radisys.msml-audit-dialog+xml": { source: "iana", compressible: true }, "application/vnd.radisys.msml-audit-stream+xml": { source: "iana", compressible: true }, "application/vnd.radisys.msml-conf+xml": { source: "iana", compressible: true }, "application/vnd.radisys.msml-dialog+xml": { source: "iana", compressible: true }, "application/vnd.radisys.msml-dialog-base+xml": { source: "iana", compressible: true }, "application/vnd.radisys.msml-dialog-fax-detect+xml": { source: "iana", compressible: true }, "application/vnd.radisys.msml-dialog-fax-sendrecv+xml": { source: "iana", compressible: true }, "application/vnd.radisys.msml-dialog-group+xml": { source: "iana", compressible: true }, "application/vnd.radisys.msml-dialog-speech+xml": { source: "iana", compressible: true }, "application/vnd.radisys.msml-dialog-transform+xml": { source: "iana", compressible: true }, "application/vnd.rainstor.data": { source: "iana" }, "application/vnd.rapid": { source: "iana" }, "application/vnd.rar": { source: "iana", extensions: ["rar"] }, "application/vnd.realvnc.bed": { source: "iana", extensions: ["bed"] }, "application/vnd.recordare.musicxml": { source: "iana", extensions: ["mxl"] }, "application/vnd.recordare.musicxml+xml": { source: "iana", compressible: true, extensions: ["musicxml"] }, "application/vnd.renlearn.rlprint": { source: "iana" }, "application/vnd.resilient.logic": { source: "iana" }, "application/vnd.restful+json": { source: "iana", compressible: true }, "application/vnd.rig.cryptonote": { source: "iana", extensions: ["cryptonote"] }, "application/vnd.rim.cod": { source: "apache", extensions: ["cod"] }, "application/vnd.rn-realmedia": { source: "apache", extensions: ["rm"] }, "application/vnd.rn-realmedia-vbr": { source: "apache", extensions: ["rmvb"] }, "application/vnd.route66.link66+xml": { source: "iana", compressible: true, extensions: ["link66"] }, "application/vnd.rs-274x": { source: "iana" }, "application/vnd.ruckus.download": { source: "iana" }, "application/vnd.s3sms": { source: "iana" }, "application/vnd.sailingtracker.track": { source: "iana", extensions: ["st"] }, "application/vnd.sar": { source: "iana" }, "application/vnd.sbm.cid": { source: "iana" }, "application/vnd.sbm.mid2": { source: "iana" }, "application/vnd.scribus": { source: "iana" }, "application/vnd.sealed.3df": { source: "iana" }, "application/vnd.sealed.csf": { source: "iana" }, "application/vnd.sealed.doc": { source: "iana" }, "application/vnd.sealed.eml": { source: "iana" }, "application/vnd.sealed.mht": { source: "iana" }, "application/vnd.sealed.net": { source: "iana" }, "application/vnd.sealed.ppt": { source: "iana" }, "application/vnd.sealed.tiff": { source: "iana" }, "application/vnd.sealed.xls": { source: "iana" }, "application/vnd.sealedmedia.softseal.html": { source: "iana" }, "application/vnd.sealedmedia.softseal.pdf": { source: "iana" }, "application/vnd.seemail": { source: "iana", extensions: ["see"] }, "application/vnd.seis+json": { source: "iana", compressible: true }, "application/vnd.sema": { source: "iana", extensions: ["sema"] }, "application/vnd.semd": { source: "iana", extensions: ["semd"] }, "application/vnd.semf": { source: "iana", extensions: ["semf"] }, "application/vnd.shade-save-file": { source: "iana" }, "application/vnd.shana.informed.formdata": { source: "iana", extensions: ["ifm"] }, "application/vnd.shana.informed.formtemplate": { source: "iana", extensions: ["itp"] }, "application/vnd.shana.informed.interchange": { source: "iana", extensions: ["iif"] }, "application/vnd.shana.informed.package": { source: "iana", extensions: ["ipk"] }, "application/vnd.shootproof+json": { source: "iana", compressible: true }, "application/vnd.shopkick+json": { source: "iana", compressible: true }, "application/vnd.shp": { source: "iana" }, "application/vnd.shx": { source: "iana" }, "application/vnd.sigrok.session": { source: "iana" }, "application/vnd.simtech-mindmapper": { source: "iana", extensions: ["twd", "twds"] }, "application/vnd.siren+json": { source: "iana", compressible: true }, "application/vnd.smaf": { source: "iana", extensions: ["mmf"] }, "application/vnd.smart.notebook": { source: "iana" }, "application/vnd.smart.teacher": { source: "iana", extensions: ["teacher"] }, "application/vnd.snesdev-page-table": { source: "iana" }, "application/vnd.software602.filler.form+xml": { source: "iana", compressible: true, extensions: ["fo"] }, "application/vnd.software602.filler.form-xml-zip": { source: "iana" }, "application/vnd.solent.sdkm+xml": { source: "iana", compressible: true, extensions: ["sdkm", "sdkd"] }, "application/vnd.spotfire.dxp": { source: "iana", extensions: ["dxp"] }, "application/vnd.spotfire.sfs": { source: "iana", extensions: ["sfs"] }, "application/vnd.sqlite3": { source: "iana" }, "application/vnd.sss-cod": { source: "iana" }, "application/vnd.sss-dtf": { source: "iana" }, "application/vnd.sss-ntf": { source: "iana" }, "application/vnd.stardivision.calc": { source: "apache", extensions: ["sdc"] }, "application/vnd.stardivision.draw": { source: "apache", extensions: ["sda"] }, "application/vnd.stardivision.impress": { source: "apache", extensions: ["sdd"] }, "application/vnd.stardivision.math": { source: "apache", extensions: ["smf"] }, "application/vnd.stardivision.writer": { source: "apache", extensions: ["sdw", "vor"] }, "application/vnd.stardivision.writer-global": { source: "apache", extensions: ["sgl"] }, "application/vnd.stepmania.package": { source: "iana", extensions: ["smzip"] }, "application/vnd.stepmania.stepchart": { source: "iana", extensions: ["sm"] }, "application/vnd.street-stream": { source: "iana" }, "application/vnd.sun.wadl+xml": { source: "iana", compressible: true, extensions: ["wadl"] }, "application/vnd.sun.xml.calc": { source: "apache", extensions: ["sxc"] }, "application/vnd.sun.xml.calc.template": { source: "apache", extensions: ["stc"] }, "application/vnd.sun.xml.draw": { source: "apache", extensions: ["sxd"] }, "application/vnd.sun.xml.draw.template": { source: "apache", extensions: ["std"] }, "application/vnd.sun.xml.impress": { source: "apache", extensions: ["sxi"] }, "application/vnd.sun.xml.impress.template": { source: "apache", extensions: ["sti"] }, "application/vnd.sun.xml.math": { source: "apache", extensions: ["sxm"] }, "application/vnd.sun.xml.writer": { source: "apache", extensions: ["sxw"] }, "application/vnd.sun.xml.writer.global": { source: "apache", extensions: ["sxg"] }, "application/vnd.sun.xml.writer.template": { source: "apache", extensions: ["stw"] }, "application/vnd.sus-calendar": { source: "iana", extensions: ["sus", "susp"] }, "application/vnd.svd": { source: "iana", extensions: ["svd"] }, "application/vnd.swiftview-ics": { source: "iana" }, "application/vnd.sycle+xml": { source: "iana", compressible: true }, "application/vnd.syft+json": { source: "iana", compressible: true }, "application/vnd.symbian.install": { source: "apache", extensions: ["sis", "sisx"] }, "application/vnd.syncml+xml": { source: "iana", charset: "UTF-8", compressible: true, extensions: ["xsm"] }, "application/vnd.syncml.dm+wbxml": { source: "iana", charset: "UTF-8", extensions: ["bdm"] }, "application/vnd.syncml.dm+xml": { source: "iana", charset: "UTF-8", compressible: true, extensions: ["xdm"] }, "application/vnd.syncml.dm.notification": { source: "iana" }, "application/vnd.syncml.dmddf+wbxml": { source: "iana" }, "application/vnd.syncml.dmddf+xml": { source: "iana", charset: "UTF-8", compressible: true, extensions: ["ddf"] }, "application/vnd.syncml.dmtnds+wbxml": { source: "iana" }, "application/vnd.syncml.dmtnds+xml": { source: "iana", charset: "UTF-8", compressible: true }, "application/vnd.syncml.ds.notification": { source: "iana" }, "application/vnd.tableschema+json": { source: "iana", compressible: true }, "application/vnd.tao.intent-module-archive": { source: "iana", extensions: ["tao"] }, "application/vnd.tcpdump.pcap": { source: "iana", extensions: ["pcap", "cap", "dmp"] }, "application/vnd.think-cell.ppttc+json": { source: "iana", compressible: true }, "application/vnd.tmd.mediaflex.api+xml": { source: "iana", compressible: true }, "application/vnd.tml": { source: "iana" }, "application/vnd.tmobile-livetv": { source: "iana", extensions: ["tmo"] }, "application/vnd.tri.onesource": { source: "iana" }, "application/vnd.trid.tpt": { source: "iana", extensions: ["tpt"] }, "application/vnd.triscape.mxs": { source: "iana", extensions: ["mxs"] }, "application/vnd.trueapp": { source: "iana", extensions: ["tra"] }, "application/vnd.truedoc": { source: "iana" }, "application/vnd.ubisoft.webplayer": { source: "iana" }, "application/vnd.ufdl": { source: "iana", extensions: ["ufd", "ufdl"] }, "application/vnd.uiq.theme": { source: "iana", extensions: ["utz"] }, "application/vnd.umajin": { source: "iana", extensions: ["umj"] }, "application/vnd.unity": { source: "iana", extensions: ["unityweb"] }, "application/vnd.uoml+xml": { source: "iana", compressible: true, extensions: ["uoml"] }, "application/vnd.uplanet.alert": { source: "iana" }, "application/vnd.uplanet.alert-wbxml": { source: "iana" }, "application/vnd.uplanet.bearer-choice": { source: "iana" }, "application/vnd.uplanet.bearer-choice-wbxml": { source: "iana" }, "application/vnd.uplanet.cacheop": { source: "iana" }, "application/vnd.uplanet.cacheop-wbxml": { source: "iana" }, "application/vnd.uplanet.channel": { source: "iana" }, "application/vnd.uplanet.channel-wbxml": { source: "iana" }, "application/vnd.uplanet.list": { source: "iana" }, "application/vnd.uplanet.list-wbxml": { source: "iana" }, "application/vnd.uplanet.listcmd": { source: "iana" }, "application/vnd.uplanet.listcmd-wbxml": { source: "iana" }, "application/vnd.uplanet.signal": { source: "iana" }, "application/vnd.uri-map": { source: "iana" }, "application/vnd.valve.source.material": { source: "iana" }, "application/vnd.vcx": { source: "iana", extensions: ["vcx"] }, "application/vnd.vd-study": { source: "iana" }, "application/vnd.vectorworks": { source: "iana" }, "application/vnd.vel+json": { source: "iana", compressible: true }, "application/vnd.verimatrix.vcas": { source: "iana" }, "application/vnd.veritone.aion+json": { source: "iana", compressible: true }, "application/vnd.veryant.thin": { source: "iana" }, "application/vnd.ves.encrypted": { source: "iana" }, "application/vnd.vidsoft.vidconference": { source: "iana" }, "application/vnd.visio": { source: "iana", extensions: ["vsd", "vst", "vss", "vsw"] }, "application/vnd.visionary": { source: "iana", extensions: ["vis"] }, "application/vnd.vividence.scriptfile": { source: "iana" }, "application/vnd.vsf": { source: "iana", extensions: ["vsf"] }, "application/vnd.wap.sic": { source: "iana" }, "application/vnd.wap.slc": { source: "iana" }, "application/vnd.wap.wbxml": { source: "iana", charset: "UTF-8", extensions: ["wbxml"] }, "application/vnd.wap.wmlc": { source: "iana", extensions: ["wmlc"] }, "application/vnd.wap.wmlscriptc": { source: "iana", extensions: ["wmlsc"] }, "application/vnd.webturbo": { source: "iana", extensions: ["wtb"] }, "application/vnd.wfa.dpp": { source: "iana" }, "application/vnd.wfa.p2p": { source: "iana" }, "application/vnd.wfa.wsc": { source: "iana" }, "application/vnd.windows.devicepairing": { source: "iana" }, "application/vnd.wmc": { source: "iana" }, "application/vnd.wmf.bootstrap": { source: "iana" }, "application/vnd.wolfram.mathematica": { source: "iana" }, "application/vnd.wolfram.mathematica.package": { source: "iana" }, "application/vnd.wolfram.player": { source: "iana", extensions: ["nbp"] }, "application/vnd.wordperfect": { source: "iana", extensions: ["wpd"] }, "application/vnd.wqd": { source: "iana", extensions: ["wqd"] }, "application/vnd.wrq-hp3000-labelled": { source: "iana" }, "application/vnd.wt.stf": { source: "iana", extensions: ["stf"] }, "application/vnd.wv.csp+wbxml": { source: "iana" }, "application/vnd.wv.csp+xml": { source: "iana", compressible: true }, "application/vnd.wv.ssp+xml": { source: "iana", compressible: true }, "application/vnd.xacml+json": { source: "iana", compressible: true }, "application/vnd.xara": { source: "iana", extensions: ["xar"] }, "application/vnd.xfdl": { source: "iana", extensions: ["xfdl"] }, "application/vnd.xfdl.webform": { source: "iana" }, "application/vnd.xmi+xml": { source: "iana", compressible: true }, "application/vnd.xmpie.cpkg": { source: "iana" }, "application/vnd.xmpie.dpkg": { source: "iana" }, "application/vnd.xmpie.plan": { source: "iana" }, "application/vnd.xmpie.ppkg": { source: "iana" }, "application/vnd.xmpie.xlim": { source: "iana" }, "application/vnd.yamaha.hv-dic": { source: "iana", extensions: ["hvd"] }, "application/vnd.yamaha.hv-script": { source: "iana", extensions: ["hvs"] }, "application/vnd.yamaha.hv-voice": { source: "iana", extensions: ["hvp"] }, "application/vnd.yamaha.openscoreformat": { source: "iana", extensions: ["osf"] }, "application/vnd.yamaha.openscoreformat.osfpvg+xml": { source: "iana", compressible: true, extensions: ["osfpvg"] }, "application/vnd.yamaha.remote-setup": { source: "iana" }, "application/vnd.yamaha.smaf-audio": { source: "iana", extensions: ["saf"] }, "application/vnd.yamaha.smaf-phrase": { source: "iana", extensions: ["spf"] }, "application/vnd.yamaha.through-ngn": { source: "iana" }, "application/vnd.yamaha.tunnel-udpencap": { source: "iana" }, "application/vnd.yaoweme": { source: "iana" }, "application/vnd.yellowriver-custom-menu": { source: "iana", extensions: ["cmp"] }, "application/vnd.youtube.yt": { source: "iana" }, "application/vnd.zul": { source: "iana", extensions: ["zir", "zirz"] }, "application/vnd.zzazz.deck+xml": { source: "iana", compressible: true, extensions: ["zaz"] }, "application/voicexml+xml": { source: "iana", compressible: true, extensions: ["vxml"] }, "application/voucher-cms+json": { source: "iana", compressible: true }, "application/vq-rtcpxr": { source: "iana" }, "application/wasm": { source: "iana", compressible: true, extensions: ["wasm"] }, "application/watcherinfo+xml": { source: "iana", compressible: true, extensions: ["wif"] }, "application/webpush-options+json": { source: "iana", compressible: true }, "application/whoispp-query": { source: "iana" }, "application/whoispp-response": { source: "iana" }, "application/widget": { source: "iana", extensions: ["wgt"] }, "application/winhlp": { source: "apache", extensions: ["hlp"] }, "application/wita": { source: "iana" }, "application/wordperfect5.1": { source: "iana" }, "application/wsdl+xml": { source: "iana", compressible: true, extensions: ["wsdl"] }, "application/wspolicy+xml": { source: "iana", compressible: true, extensions: ["wspolicy"] }, "application/x-7z-compressed": { source: "apache", compressible: false, extensions: ["7z"] }, "application/x-abiword": { source: "apache", extensions: ["abw"] }, "application/x-ace-compressed": { source: "apache", extensions: ["ace"] }, "application/x-amf": { source: "apache" }, "application/x-apple-diskimage": { source: "apache", extensions: ["dmg"] }, "application/x-arj": { compressible: false, extensions: ["arj"] }, "application/x-authorware-bin": { source: "apache", extensions: ["aab", "x32", "u32", "vox"] }, "application/x-authorware-map": { source: "apache", extensions: ["aam"] }, "application/x-authorware-seg": { source: "apache", extensions: ["aas"] }, "application/x-bcpio": { source: "apache", extensions: ["bcpio"] }, "application/x-bdoc": { compressible: false, extensions: ["bdoc"] }, "application/x-bittorrent": { source: "apache", extensions: ["torrent"] }, "application/x-blorb": { source: "apache", extensions: ["blb", "blorb"] }, "application/x-bzip": { source: "apache", compressible: false, extensions: ["bz"] }, "application/x-bzip2": { source: "apache", compressible: false, extensions: ["bz2", "boz"] }, "application/x-cbr": { source: "apache", extensions: ["cbr", "cba", "cbt", "cbz", "cb7"] }, "application/x-cdlink": { source: "apache", extensions: ["vcd"] }, "application/x-cfs-compressed": { source: "apache", extensions: ["cfs"] }, "application/x-chat": { source: "apache", extensions: ["chat"] }, "application/x-chess-pgn": { source: "apache", extensions: ["pgn"] }, "application/x-chrome-extension": { extensions: ["crx"] }, "application/x-cocoa": { source: "nginx", extensions: ["cco"] }, "application/x-compress": { source: "apache" }, "application/x-conference": { source: "apache", extensions: ["nsc"] }, "application/x-cpio": { source: "apache", extensions: ["cpio"] }, "application/x-csh": { source: "apache", extensions: ["csh"] }, "application/x-deb": { compressible: false }, "application/x-debian-package": { source: "apache", extensions: ["deb", "udeb"] }, "application/x-dgc-compressed": { source: "apache", extensions: ["dgc"] }, "application/x-director": { source: "apache", extensions: ["dir", "dcr", "dxr", "cst", "cct", "cxt", "w3d", "fgd", "swa"] }, "application/x-doom": { source: "apache", extensions: ["wad"] }, "application/x-dtbncx+xml": { source: "apache", compressible: true, extensions: ["ncx"] }, "application/x-dtbook+xml": { source: "apache", compressible: true, extensions: ["dtb"] }, "application/x-dtbresource+xml": { source: "apache", compressible: true, extensions: ["res"] }, "application/x-dvi": { source: "apache", compressible: false, extensions: ["dvi"] }, "application/x-envoy": { source: "apache", extensions: ["evy"] }, "application/x-eva": { source: "apache", extensions: ["eva"] }, "application/x-font-bdf": { source: "apache", extensions: ["bdf"] }, "application/x-font-dos": { source: "apache" }, "application/x-font-framemaker": { source: "apache" }, "application/x-font-ghostscript": { source: "apache", extensions: ["gsf"] }, "application/x-font-libgrx": { source: "apache" }, "application/x-font-linux-psf": { source: "apache", extensions: ["psf"] }, "application/x-font-pcf": { source: "apache", extensions: ["pcf"] }, "application/x-font-snf": { source: "apache", extensions: ["snf"] }, "application/x-font-speedo": { source: "apache" }, "application/x-font-sunos-news": { source: "apache" }, "application/x-font-type1": { source: "apache", extensions: ["pfa", "pfb", "pfm", "afm"] }, "application/x-font-vfont": { source: "apache" }, "application/x-freearc": { source: "apache", extensions: ["arc"] }, "application/x-futuresplash": { source: "apache", extensions: ["spl"] }, "application/x-gca-compressed": { source: "apache", extensions: ["gca"] }, "application/x-glulx": { source: "apache", extensions: ["ulx"] }, "application/x-gnumeric": { source: "apache", extensions: ["gnumeric"] }, "application/x-gramps-xml": { source: "apache", extensions: ["gramps"] }, "application/x-gtar": { source: "apache", extensions: ["gtar"] }, "application/x-gzip": { source: "apache" }, "application/x-hdf": { source: "apache", extensions: ["hdf"] }, "application/x-httpd-php": { compressible: true, extensions: ["php"] }, "application/x-install-instructions": { source: "apache", extensions: ["install"] }, "application/x-iso9660-image": { source: "apache", extensions: ["iso"] }, "application/x-iwork-keynote-sffkey": { extensions: ["key"] }, "application/x-iwork-numbers-sffnumbers": { extensions: ["numbers"] }, "application/x-iwork-pages-sffpages": { extensions: ["pages"] }, "application/x-java-archive-diff": { source: "nginx", extensions: ["jardiff"] }, "application/x-java-jnlp-file": { source: "apache", compressible: false, extensions: ["jnlp"] }, "application/x-javascript": { compressible: true }, "application/x-keepass2": { extensions: ["kdbx"] }, "application/x-latex": { source: "apache", compressible: false, extensions: ["latex"] }, "application/x-lua-bytecode": { extensions: ["luac"] }, "application/x-lzh-compressed": { source: "apache", extensions: ["lzh", "lha"] }, "application/x-makeself": { source: "nginx", extensions: ["run"] }, "application/x-mie": { source: "apache", extensions: ["mie"] }, "application/x-mobipocket-ebook": { source: "apache", extensions: ["prc", "mobi"] }, "application/x-mpegurl": { compressible: false }, "application/x-ms-application": { source: "apache", extensions: ["application"] }, "application/x-ms-shortcut": { source: "apache", extensions: ["lnk"] }, "application/x-ms-wmd": { source: "apache", extensions: ["wmd"] }, "application/x-ms-wmz": { source: "apache", extensions: ["wmz"] }, "application/x-ms-xbap": { source: "apache", extensions: ["xbap"] }, "application/x-msaccess": { source: "apache", extensions: ["mdb"] }, "application/x-msbinder": { source: "apache", extensions: ["obd"] }, "application/x-mscardfile": { source: "apache", extensions: ["crd"] }, "application/x-msclip": { source: "apache", extensions: ["clp"] }, "application/x-msdos-program": { extensions: ["exe"] }, "application/x-msdownload": { source: "apache", extensions: ["exe", "dll", "com", "bat", "msi"] }, "application/x-msmediaview": { source: "apache", extensions: ["mvb", "m13", "m14"] }, "application/x-msmetafile": { source: "apache", extensions: ["wmf", "wmz", "emf", "emz"] }, "application/x-msmoney": { source: "apache", extensions: ["mny"] }, "application/x-mspublisher": { source: "apache", extensions: ["pub"] }, "application/x-msschedule": { source: "apache", extensions: ["scd"] }, "application/x-msterminal": { source: "apache", extensions: ["trm"] }, "application/x-mswrite": { source: "apache", extensions: ["wri"] }, "application/x-netcdf": { source: "apache", extensions: ["nc", "cdf"] }, "application/x-ns-proxy-autoconfig": { compressible: true, extensions: ["pac"] }, "application/x-nzb": { source: "apache", extensions: ["nzb"] }, "application/x-perl": { source: "nginx", extensions: ["pl", "pm"] }, "application/x-pilot": { source: "nginx", extensions: ["prc", "pdb"] }, "application/x-pkcs12": { source: "apache", compressible: false, extensions: ["p12", "pfx"] }, "application/x-pkcs7-certificates": { source: "apache", extensions: ["p7b", "spc"] }, "application/x-pkcs7-certreqresp": { source: "apache", extensions: ["p7r"] }, "application/x-pki-message": { source: "iana" }, "application/x-rar-compressed": { source: "apache", compressible: false, extensions: ["rar"] }, "application/x-redhat-package-manager": { source: "nginx", extensions: ["rpm"] }, "application/x-research-info-systems": { source: "apache", extensions: ["ris"] }, "application/x-sea": { source: "nginx", extensions: ["sea"] }, "application/x-sh": { source: "apache", compressible: true, extensions: ["sh"] }, "application/x-shar": { source: "apache", extensions: ["shar"] }, "application/x-shockwave-flash": { source: "apache", compressible: false, extensions: ["swf"] }, "application/x-silverlight-app": { source: "apache", extensions: ["xap"] }, "application/x-sql": { source: "apache", extensions: ["sql"] }, "application/x-stuffit": { source: "apache", compressible: false, extensions: ["sit"] }, "application/x-stuffitx": { source: "apache", extensions: ["sitx"] }, "application/x-subrip": { source: "apache", extensions: ["srt"] }, "application/x-sv4cpio": { source: "apache", extensions: ["sv4cpio"] }, "application/x-sv4crc": { source: "apache", extensions: ["sv4crc"] }, "application/x-t3vm-image": { source: "apache", extensions: ["t3"] }, "application/x-tads": { source: "apache", extensions: ["gam"] }, "application/x-tar": { source: "apache", compressible: true, extensions: ["tar"] }, "application/x-tcl": { source: "apache", extensions: ["tcl", "tk"] }, "application/x-tex": { source: "apache", extensions: ["tex"] }, "application/x-tex-tfm": { source: "apache", extensions: ["tfm"] }, "application/x-texinfo": { source: "apache", extensions: ["texinfo", "texi"] }, "application/x-tgif": { source: "apache", extensions: ["obj"] }, "application/x-ustar": { source: "apache", extensions: ["ustar"] }, "application/x-virtualbox-hdd": { compressible: true, extensions: ["hdd"] }, "application/x-virtualbox-ova": { compressible: true, extensions: ["ova"] }, "application/x-virtualbox-ovf": { compressible: true, extensions: ["ovf"] }, "application/x-virtualbox-vbox": { compressible: true, extensions: ["vbox"] }, "application/x-virtualbox-vbox-extpack": { compressible: false, extensions: ["vbox-extpack"] }, "application/x-virtualbox-vdi": { compressible: true, extensions: ["vdi"] }, "application/x-virtualbox-vhd": { compressible: true, extensions: ["vhd"] }, "application/x-virtualbox-vmdk": { compressible: true, extensions: ["vmdk"] }, "application/x-wais-source": { source: "apache", extensions: ["src"] }, "application/x-web-app-manifest+json": { compressible: true, extensions: ["webapp"] }, "application/x-www-form-urlencoded": { source: "iana", compressible: true }, "application/x-x509-ca-cert": { source: "iana", extensions: ["der", "crt", "pem"] }, "application/x-x509-ca-ra-cert": { source: "iana" }, "application/x-x509-next-ca-cert": { source: "iana" }, "application/x-xfig": { source: "apache", extensions: ["fig"] }, "application/x-xliff+xml": { source: "apache", compressible: true, extensions: ["xlf"] }, "application/x-xpinstall": { source: "apache", compressible: false, extensions: ["xpi"] }, "application/x-xz": { source: "apache", extensions: ["xz"] }, "application/x-zmachine": { source: "apache", extensions: ["z1", "z2", "z3", "z4", "z5", "z6", "z7", "z8"] }, "application/x400-bp": { source: "iana" }, "application/xacml+xml": { source: "iana", compressible: true }, "application/xaml+xml": { source: "apache", compressible: true, extensions: ["xaml"] }, "application/xcap-att+xml": { source: "iana", compressible: true, extensions: ["xav"] }, "application/xcap-caps+xml": { source: "iana", compressible: true, extensions: ["xca"] }, "application/xcap-diff+xml": { source: "iana", compressible: true, extensions: ["xdf"] }, "application/xcap-el+xml": { source: "iana", compressible: true, extensions: ["xel"] }, "application/xcap-error+xml": { source: "iana", compressible: true }, "application/xcap-ns+xml": { source: "iana", compressible: true, extensions: ["xns"] }, "application/xcon-conference-info+xml": { source: "iana", compressible: true }, "application/xcon-conference-info-diff+xml": { source: "iana", compressible: true }, "application/xenc+xml": { source: "iana", compressible: true, extensions: ["xenc"] }, "application/xhtml+xml": { source: "iana", compressible: true, extensions: ["xhtml", "xht"] }, "application/xhtml-voice+xml": { source: "apache", compressible: true }, "application/xliff+xml": { source: "iana", compressible: true, extensions: ["xlf"] }, "application/xml": { source: "iana", compressible: true, extensions: ["xml", "xsl", "xsd", "rng"] }, "application/xml-dtd": { source: "iana", compressible: true, extensions: ["dtd"] }, "application/xml-external-parsed-entity": { source: "iana" }, "application/xml-patch+xml": { source: "iana", compressible: true }, "application/xmpp+xml": { source: "iana", compressible: true }, "application/xop+xml": { source: "iana", compressible: true, extensions: ["xop"] }, "application/xproc+xml": { source: "apache", compressible: true, extensions: ["xpl"] }, "application/xslt+xml": { source: "iana", compressible: true, extensions: ["xsl", "xslt"] }, "application/xspf+xml": { source: "apache", compressible: true, extensions: ["xspf"] }, "application/xv+xml": { source: "iana", compressible: true, extensions: ["mxml", "xhvml", "xvml", "xvm"] }, "application/yang": { source: "iana", extensions: ["yang"] }, "application/yang-data+json": { source: "iana", compressible: true }, "application/yang-data+xml": { source: "iana", compressible: true }, "application/yang-patch+json": { source: "iana", compressible: true }, "application/yang-patch+xml": { source: "iana", compressible: true }, "application/yin+xml": { source: "iana", compressible: true, extensions: ["yin"] }, "application/zip": { source: "iana", compressible: false, extensions: ["zip"] }, "application/zlib": { source: "iana" }, "application/zstd": { source: "iana" }, "audio/1d-interleaved-parityfec": { source: "iana" }, "audio/32kadpcm": { source: "iana" }, "audio/3gpp": { source: "iana", compressible: false, extensions: ["3gpp"] }, "audio/3gpp2": { source: "iana" }, "audio/aac": { source: "iana" }, "audio/ac3": { source: "iana" }, "audio/adpcm": { source: "apache", extensions: ["adp"] }, "audio/amr": { source: "iana", extensions: ["amr"] }, "audio/amr-wb": { source: "iana" }, "audio/amr-wb+": { source: "iana" }, "audio/aptx": { source: "iana" }, "audio/asc": { source: "iana" }, "audio/atrac-advanced-lossless": { source: "iana" }, "audio/atrac-x": { source: "iana" }, "audio/atrac3": { source: "iana" }, "audio/basic": { source: "iana", compressible: false, extensions: ["au", "snd"] }, "audio/bv16": { source: "iana" }, "audio/bv32": { source: "iana" }, "audio/clearmode": { source: "iana" }, "audio/cn": { source: "iana" }, "audio/dat12": { source: "iana" }, "audio/dls": { source: "iana" }, "audio/dsr-es201108": { source: "iana" }, "audio/dsr-es202050": { source: "iana" }, "audio/dsr-es202211": { source: "iana" }, "audio/dsr-es202212": { source: "iana" }, "audio/dv": { source: "iana" }, "audio/dvi4": { source: "iana" }, "audio/eac3": { source: "iana" }, "audio/encaprtp": { source: "iana" }, "audio/evrc": { source: "iana" }, "audio/evrc-qcp": { source: "iana" }, "audio/evrc0": { source: "iana" }, "audio/evrc1": { source: "iana" }, "audio/evrcb": { source: "iana" }, "audio/evrcb0": { source: "iana" }, "audio/evrcb1": { source: "iana" }, "audio/evrcnw": { source: "iana" }, "audio/evrcnw0": { source: "iana" }, "audio/evrcnw1": { source: "iana" }, "audio/evrcwb": { source: "iana" }, "audio/evrcwb0": { source: "iana" }, "audio/evrcwb1": { source: "iana" }, "audio/evs": { source: "iana" }, "audio/flexfec": { source: "iana" }, "audio/fwdred": { source: "iana" }, "audio/g711-0": { source: "iana" }, "audio/g719": { source: "iana" }, "audio/g722": { source: "iana" }, "audio/g7221": { source: "iana" }, "audio/g723": { source: "iana" }, "audio/g726-16": { source: "iana" }, "audio/g726-24": { source: "iana" }, "audio/g726-32": { source: "iana" }, "audio/g726-40": { source: "iana" }, "audio/g728": { source: "iana" }, "audio/g729": { source: "iana" }, "audio/g7291": { source: "iana" }, "audio/g729d": { source: "iana" }, "audio/g729e": { source: "iana" }, "audio/gsm": { source: "iana" }, "audio/gsm-efr": { source: "iana" }, "audio/gsm-hr-08": { source: "iana" }, "audio/ilbc": { source: "iana" }, "audio/ip-mr_v2.5": { source: "iana" }, "audio/isac": { source: "apache" }, "audio/l16": { source: "iana" }, "audio/l20": { source: "iana" }, "audio/l24": { source: "iana", compressible: false }, "audio/l8": { source: "iana" }, "audio/lpc": { source: "iana" }, "audio/melp": { source: "iana" }, "audio/melp1200": { source: "iana" }, "audio/melp2400": { source: "iana" }, "audio/melp600": { source: "iana" }, "audio/mhas": { source: "iana" }, "audio/midi": { source: "apache", extensions: ["mid", "midi", "kar", "rmi"] }, "audio/mobile-xmf": { source: "iana", extensions: ["mxmf"] }, "audio/mp3": { compressible: false, extensions: ["mp3"] }, "audio/mp4": { source: "iana", compressible: false, extensions: ["m4a", "mp4a"] }, "audio/mp4a-latm": { source: "iana" }, "audio/mpa": { source: "iana" }, "audio/mpa-robust": { source: "iana" }, "audio/mpeg": { source: "iana", compressible: false, extensions: ["mpga", "mp2", "mp2a", "mp3", "m2a", "m3a"] }, "audio/mpeg4-generic": { source: "iana" }, "audio/musepack": { source: "apache" }, "audio/ogg": { source: "iana", compressible: false, extensions: ["oga", "ogg", "spx", "opus"] }, "audio/opus": { source: "iana" }, "audio/parityfec": { source: "iana" }, "audio/pcma": { source: "iana" }, "audio/pcma-wb": { source: "iana" }, "audio/pcmu": { source: "iana" }, "audio/pcmu-wb": { source: "iana" }, "audio/prs.sid": { source: "iana" }, "audio/qcelp": { source: "iana" }, "audio/raptorfec": { source: "iana" }, "audio/red": { source: "iana" }, "audio/rtp-enc-aescm128": { source: "iana" }, "audio/rtp-midi": { source: "iana" }, "audio/rtploopback": { source: "iana" }, "audio/rtx": { source: "iana" }, "audio/s3m": { source: "apache", extensions: ["s3m"] }, "audio/scip": { source: "iana" }, "audio/silk": { source: "apache", extensions: ["sil"] }, "audio/smv": { source: "iana" }, "audio/smv-qcp": { source: "iana" }, "audio/smv0": { source: "iana" }, "audio/sofa": { source: "iana" }, "audio/sp-midi": { source: "iana" }, "audio/speex": { source: "iana" }, "audio/t140c": { source: "iana" }, "audio/t38": { source: "iana" }, "audio/telephone-event": { source: "iana" }, "audio/tetra_acelp": { source: "iana" }, "audio/tetra_acelp_bb": { source: "iana" }, "audio/tone": { source: "iana" }, "audio/tsvcis": { source: "iana" }, "audio/uemclip": { source: "iana" }, "audio/ulpfec": { source: "iana" }, "audio/usac": { source: "iana" }, "audio/vdvi": { source: "iana" }, "audio/vmr-wb": { source: "iana" }, "audio/vnd.3gpp.iufp": { source: "iana" }, "audio/vnd.4sb": { source: "iana" }, "audio/vnd.audiokoz": { source: "iana" }, "audio/vnd.celp": { source: "iana" }, "audio/vnd.cisco.nse": { source: "iana" }, "audio/vnd.cmles.radio-events": { source: "iana" }, "audio/vnd.cns.anp1": { source: "iana" }, "audio/vnd.cns.inf1": { source: "iana" }, "audio/vnd.dece.audio": { source: "iana", extensions: ["uva", "uvva"] }, "audio/vnd.digital-winds": { source: "iana", extensions: ["eol"] }, "audio/vnd.dlna.adts": { source: "iana" }, "audio/vnd.dolby.heaac.1": { source: "iana" }, "audio/vnd.dolby.heaac.2": { source: "iana" }, "audio/vnd.dolby.mlp": { source: "iana" }, "audio/vnd.dolby.mps": { source: "iana" }, "audio/vnd.dolby.pl2": { source: "iana" }, "audio/vnd.dolby.pl2x": { source: "iana" }, "audio/vnd.dolby.pl2z": { source: "iana" }, "audio/vnd.dolby.pulse.1": { source: "iana" }, "audio/vnd.dra": { source: "iana", extensions: ["dra"] }, "audio/vnd.dts": { source: "iana", extensions: ["dts"] }, "audio/vnd.dts.hd": { source: "iana", extensions: ["dtshd"] }, "audio/vnd.dts.uhd": { source: "iana" }, "audio/vnd.dvb.file": { source: "iana" }, "audio/vnd.everad.plj": { source: "iana" }, "audio/vnd.hns.audio": { source: "iana" }, "audio/vnd.lucent.voice": { source: "iana", extensions: ["lvp"] }, "audio/vnd.ms-playready.media.pya": { source: "iana", extensions: ["pya"] }, "audio/vnd.nokia.mobile-xmf": { source: "iana" }, "audio/vnd.nortel.vbk": { source: "iana" }, "audio/vnd.nuera.ecelp4800": { source: "iana", extensions: ["ecelp4800"] }, "audio/vnd.nuera.ecelp7470": { source: "iana", extensions: ["ecelp7470"] }, "audio/vnd.nuera.ecelp9600": { source: "iana", extensions: ["ecelp9600"] }, "audio/vnd.octel.sbc": { source: "iana" }, "audio/vnd.presonus.multitrack": { source: "iana" }, "audio/vnd.qcelp": { source: "iana" }, "audio/vnd.rhetorex.32kadpcm": { source: "iana" }, "audio/vnd.rip": { source: "iana", extensions: ["rip"] }, "audio/vnd.rn-realaudio": { compressible: false }, "audio/vnd.sealedmedia.softseal.mpeg": { source: "iana" }, "audio/vnd.vmx.cvsd": { source: "iana" }, "audio/vnd.wave": { compressible: false }, "audio/vorbis": { source: "iana", compressible: false }, "audio/vorbis-config": { source: "iana" }, "audio/wav": { compressible: false, extensions: ["wav"] }, "audio/wave": { compressible: false, extensions: ["wav"] }, "audio/webm": { source: "apache", compressible: false, extensions: ["weba"] }, "audio/x-aac": { source: "apache", compressible: false, extensions: ["aac"] }, "audio/x-aiff": { source: "apache", extensions: ["aif", "aiff", "aifc"] }, "audio/x-caf": { source: "apache", compressible: false, extensions: ["caf"] }, "audio/x-flac": { source: "apache", extensions: ["flac"] }, "audio/x-m4a": { source: "nginx", extensions: ["m4a"] }, "audio/x-matroska": { source: "apache", extensions: ["mka"] }, "audio/x-mpegurl": { source: "apache", extensions: ["m3u"] }, "audio/x-ms-wax": { source: "apache", extensions: ["wax"] }, "audio/x-ms-wma": { source: "apache", extensions: ["wma"] }, "audio/x-pn-realaudio": { source: "apache", extensions: ["ram", "ra"] }, "audio/x-pn-realaudio-plugin": { source: "apache", extensions: ["rmp"] }, "audio/x-realaudio": { source: "nginx", extensions: ["ra"] }, "audio/x-tta": { source: "apache" }, "audio/x-wav": { source: "apache", extensions: ["wav"] }, "audio/xm": { source: "apache", extensions: ["xm"] }, "chemical/x-cdx": { source: "apache", extensions: ["cdx"] }, "chemical/x-cif": { source: "apache", extensions: ["cif"] }, "chemical/x-cmdf": { source: "apache", extensions: ["cmdf"] }, "chemical/x-cml": { source: "apache", extensions: ["cml"] }, "chemical/x-csml": { source: "apache", extensions: ["csml"] }, "chemical/x-pdb": { source: "apache" }, "chemical/x-xyz": { source: "apache", extensions: ["xyz"] }, "font/collection": { source: "iana", extensions: ["ttc"] }, "font/otf": { source: "iana", compressible: true, extensions: ["otf"] }, "font/sfnt": { source: "iana" }, "font/ttf": { source: "iana", compressible: true, extensions: ["ttf"] }, "font/woff": { source: "iana", extensions: ["woff"] }, "font/woff2": { source: "iana", extensions: ["woff2"] }, "image/aces": { source: "iana", extensions: ["exr"] }, "image/apng": { compressible: false, extensions: ["apng"] }, "image/avci": { source: "iana", extensions: ["avci"] }, "image/avcs": { source: "iana", extensions: ["avcs"] }, "image/avif": { source: "iana", compressible: false, extensions: ["avif"] }, "image/bmp": { source: "iana", compressible: true, extensions: ["bmp"] }, "image/cgm": { source: "iana", extensions: ["cgm"] }, "image/dicom-rle": { source: "iana", extensions: ["drle"] }, "image/emf": { source: "iana", extensions: ["emf"] }, "image/fits": { source: "iana", extensions: ["fits"] }, "image/g3fax": { source: "iana", extensions: ["g3"] }, "image/gif": { source: "iana", compressible: false, extensions: ["gif"] }, "image/heic": { source: "iana", extensions: ["heic"] }, "image/heic-sequence": { source: "iana", extensions: ["heics"] }, "image/heif": { source: "iana", extensions: ["heif"] }, "image/heif-sequence": { source: "iana", extensions: ["heifs"] }, "image/hej2k": { source: "iana", extensions: ["hej2"] }, "image/hsj2": { source: "iana", extensions: ["hsj2"] }, "image/ief": { source: "iana", extensions: ["ief"] }, "image/jls": { source: "iana", extensions: ["jls"] }, "image/jp2": { source: "iana", compressible: false, extensions: ["jp2", "jpg2"] }, "image/jpeg": { source: "iana", compressible: false, extensions: ["jpeg", "jpg", "jpe"] }, "image/jph": { source: "iana", extensions: ["jph"] }, "image/jphc": { source: "iana", extensions: ["jhc"] }, "image/jpm": { source: "iana", compressible: false, extensions: ["jpm"] }, "image/jpx": { source: "iana", compressible: false, extensions: ["jpx", "jpf"] }, "image/jxr": { source: "iana", extensions: ["jxr"] }, "image/jxra": { source: "iana", extensions: ["jxra"] }, "image/jxrs": { source: "iana", extensions: ["jxrs"] }, "image/jxs": { source: "iana", extensions: ["jxs"] }, "image/jxsc": { source: "iana", extensions: ["jxsc"] }, "image/jxsi": { source: "iana", extensions: ["jxsi"] }, "image/jxss": { source: "iana", extensions: ["jxss"] }, "image/ktx": { source: "iana", extensions: ["ktx"] }, "image/ktx2": { source: "iana", extensions: ["ktx2"] }, "image/naplps": { source: "iana" }, "image/pjpeg": { compressible: false }, "image/png": { source: "iana", compressible: false, extensions: ["png"] }, "image/prs.btif": { source: "iana", extensions: ["btif"] }, "image/prs.pti": { source: "iana", extensions: ["pti"] }, "image/pwg-raster": { source: "iana" }, "image/sgi": { source: "apache", extensions: ["sgi"] }, "image/svg+xml": { source: "iana", compressible: true, extensions: ["svg", "svgz"] }, "image/t38": { source: "iana", extensions: ["t38"] }, "image/tiff": { source: "iana", compressible: false, extensions: ["tif", "tiff"] }, "image/tiff-fx": { source: "iana", extensions: ["tfx"] }, "image/vnd.adobe.photoshop": { source: "iana", compressible: true, extensions: ["psd"] }, "image/vnd.airzip.accelerator.azv": { source: "iana", extensions: ["azv"] }, "image/vnd.cns.inf2": { source: "iana" }, "image/vnd.dece.graphic": { source: "iana", extensions: ["uvi", "uvvi", "uvg", "uvvg"] }, "image/vnd.djvu": { source: "iana", extensions: ["djvu", "djv"] }, "image/vnd.dvb.subtitle": { source: "iana", extensions: ["sub"] }, "image/vnd.dwg": { source: "iana", extensions: ["dwg"] }, "image/vnd.dxf": { source: "iana", extensions: ["dxf"] }, "image/vnd.fastbidsheet": { source: "iana", extensions: ["fbs"] }, "image/vnd.fpx": { source: "iana", extensions: ["fpx"] }, "image/vnd.fst": { source: "iana", extensions: ["fst"] }, "image/vnd.fujixerox.edmics-mmr": { source: "iana", extensions: ["mmr"] }, "image/vnd.fujixerox.edmics-rlc": { source: "iana", extensions: ["rlc"] }, "image/vnd.globalgraphics.pgb": { source: "iana" }, "image/vnd.microsoft.icon": { source: "iana", compressible: true, extensions: ["ico"] }, "image/vnd.mix": { source: "iana" }, "image/vnd.mozilla.apng": { source: "iana" }, "image/vnd.ms-dds": { compressible: true, extensions: ["dds"] }, "image/vnd.ms-modi": { source: "iana", extensions: ["mdi"] }, "image/vnd.ms-photo": { source: "apache", extensions: ["wdp"] }, "image/vnd.net-fpx": { source: "iana", extensions: ["npx"] }, "image/vnd.pco.b16": { source: "iana", extensions: ["b16"] }, "image/vnd.radiance": { source: "iana" }, "image/vnd.sealed.png": { source: "iana" }, "image/vnd.sealedmedia.softseal.gif": { source: "iana" }, "image/vnd.sealedmedia.softseal.jpg": { source: "iana" }, "image/vnd.svf": { source: "iana" }, "image/vnd.tencent.tap": { source: "iana", extensions: ["tap"] }, "image/vnd.valve.source.texture": { source: "iana", extensions: ["vtf"] }, "image/vnd.wap.wbmp": { source: "iana", extensions: ["wbmp"] }, "image/vnd.xiff": { source: "iana", extensions: ["xif"] }, "image/vnd.zbrush.pcx": { source: "iana", extensions: ["pcx"] }, "image/webp": { source: "apache", extensions: ["webp"] }, "image/wmf": { source: "iana", extensions: ["wmf"] }, "image/x-3ds": { source: "apache", extensions: ["3ds"] }, "image/x-cmu-raster": { source: "apache", extensions: ["ras"] }, "image/x-cmx": { source: "apache", extensions: ["cmx"] }, "image/x-freehand": { source: "apache", extensions: ["fh", "fhc", "fh4", "fh5", "fh7"] }, "image/x-icon": { source: "apache", compressible: true, extensions: ["ico"] }, "image/x-jng": { source: "nginx", extensions: ["jng"] }, "image/x-mrsid-image": { source: "apache", extensions: ["sid"] }, "image/x-ms-bmp": { source: "nginx", compressible: true, extensions: ["bmp"] }, "image/x-pcx": { source: "apache", extensions: ["pcx"] }, "image/x-pict": { source: "apache", extensions: ["pic", "pct"] }, "image/x-portable-anymap": { source: "apache", extensions: ["pnm"] }, "image/x-portable-bitmap": { source: "apache", extensions: ["pbm"] }, "image/x-portable-graymap": { source: "apache", extensions: ["pgm"] }, "image/x-portable-pixmap": { source: "apache", extensions: ["ppm"] }, "image/x-rgb": { source: "apache", extensions: ["rgb"] }, "image/x-tga": { source: "apache", extensions: ["tga"] }, "image/x-xbitmap": { source: "apache", extensions: ["xbm"] }, "image/x-xcf": { compressible: false }, "image/x-xpixmap": { source: "apache", extensions: ["xpm"] }, "image/x-xwindowdump": { source: "apache", extensions: ["xwd"] }, "message/cpim": { source: "iana" }, "message/delivery-status": { source: "iana" }, "message/disposition-notification": { source: "iana", extensions: ["disposition-notification"] }, "message/external-body": { source: "iana" }, "message/feedback-report": { source: "iana" }, "message/global": { source: "iana", extensions: ["u8msg"] }, "message/global-delivery-status": { source: "iana", extensions: ["u8dsn"] }, "message/global-disposition-notification": { source: "iana", extensions: ["u8mdn"] }, "message/global-headers": { source: "iana", extensions: ["u8hdr"] }, "message/http": { source: "iana", compressible: false }, "message/imdn+xml": { source: "iana", compressible: true }, "message/news": { source: "iana" }, "message/partial": { source: "iana", compressible: false }, "message/rfc822": { source: "iana", compressible: true, extensions: ["eml", "mime"] }, "message/s-http": { source: "iana" }, "message/sip": { source: "iana" }, "message/sipfrag": { source: "iana" }, "message/tracking-status": { source: "iana" }, "message/vnd.si.simp": { source: "iana" }, "message/vnd.wfa.wsc": { source: "iana", extensions: ["wsc"] }, "model/3mf": { source: "iana", extensions: ["3mf"] }, "model/e57": { source: "iana" }, "model/gltf+json": { source: "iana", compressible: true, extensions: ["gltf"] }, "model/gltf-binary": { source: "iana", compressible: true, extensions: ["glb"] }, "model/iges": { source: "iana", compressible: false, extensions: ["igs", "iges"] }, "model/mesh": { source: "iana", compressible: false, extensions: ["msh", "mesh", "silo"] }, "model/mtl": { source: "iana", extensions: ["mtl"] }, "model/obj": { source: "iana", extensions: ["obj"] }, "model/step": { source: "iana" }, "model/step+xml": { source: "iana", compressible: true, extensions: ["stpx"] }, "model/step+zip": { source: "iana", compressible: false, extensions: ["stpz"] }, "model/step-xml+zip": { source: "iana", compressible: false, extensions: ["stpxz"] }, "model/stl": { source: "iana", extensions: ["stl"] }, "model/vnd.collada+xml": { source: "iana", compressible: true, extensions: ["dae"] }, "model/vnd.dwf": { source: "iana", extensions: ["dwf"] }, "model/vnd.flatland.3dml": { source: "iana" }, "model/vnd.gdl": { source: "iana", extensions: ["gdl"] }, "model/vnd.gs-gdl": { source: "apache" }, "model/vnd.gs.gdl": { source: "iana" }, "model/vnd.gtw": { source: "iana", extensions: ["gtw"] }, "model/vnd.moml+xml": { source: "iana", compressible: true }, "model/vnd.mts": { source: "iana", extensions: ["mts"] }, "model/vnd.opengex": { source: "iana", extensions: ["ogex"] }, "model/vnd.parasolid.transmit.binary": { source: "iana", extensions: ["x_b"] }, "model/vnd.parasolid.transmit.text": { source: "iana", extensions: ["x_t"] }, "model/vnd.pytha.pyox": { source: "iana" }, "model/vnd.rosette.annotated-data-model": { source: "iana" }, "model/vnd.sap.vds": { source: "iana", extensions: ["vds"] }, "model/vnd.usdz+zip": { source: "iana", compressible: false, extensions: ["usdz"] }, "model/vnd.valve.source.compiled-map": { source: "iana", extensions: ["bsp"] }, "model/vnd.vtu": { source: "iana", extensions: ["vtu"] }, "model/vrml": { source: "iana", compressible: false, extensions: ["wrl", "vrml"] }, "model/x3d+binary": { source: "apache", compressible: false, extensions: ["x3db", "x3dbz"] }, "model/x3d+fastinfoset": { source: "iana", extensions: ["x3db"] }, "model/x3d+vrml": { source: "apache", compressible: false, extensions: ["x3dv", "x3dvz"] }, "model/x3d+xml": { source: "iana", compressible: true, extensions: ["x3d", "x3dz"] }, "model/x3d-vrml": { source: "iana", extensions: ["x3dv"] }, "multipart/alternative": { source: "iana", compressible: false }, "multipart/appledouble": { source: "iana" }, "multipart/byteranges": { source: "iana" }, "multipart/digest": { source: "iana" }, "multipart/encrypted": { source: "iana", compressible: false }, "multipart/form-data": { source: "iana", compressible: false }, "multipart/header-set": { source: "iana" }, "multipart/mixed": { source: "iana" }, "multipart/multilingual": { source: "iana" }, "multipart/parallel": { source: "iana" }, "multipart/related": { source: "iana", compressible: false }, "multipart/report": { source: "iana" }, "multipart/signed": { source: "iana", compressible: false }, "multipart/vnd.bint.med-plus": { source: "iana" }, "multipart/voice-message": { source: "iana" }, "multipart/x-mixed-replace": { source: "iana" }, "text/1d-interleaved-parityfec": { source: "iana" }, "text/cache-manifest": { source: "iana", compressible: true, extensions: ["appcache", "manifest"] }, "text/calendar": { source: "iana", extensions: ["ics", "ifb"] }, "text/calender": { compressible: true }, "text/cmd": { compressible: true }, "text/coffeescript": { extensions: ["coffee", "litcoffee"] }, "text/cql": { source: "iana" }, "text/cql-expression": { source: "iana" }, "text/cql-identifier": { source: "iana" }, "text/css": { source: "iana", charset: "UTF-8", compressible: true, extensions: ["css"] }, "text/csv": { source: "iana", compressible: true, extensions: ["csv"] }, "text/csv-schema": { source: "iana" }, "text/directory": { source: "iana" }, "text/dns": { source: "iana" }, "text/ecmascript": { source: "iana" }, "text/encaprtp": { source: "iana" }, "text/enriched": { source: "iana" }, "text/fhirpath": { source: "iana" }, "text/flexfec": { source: "iana" }, "text/fwdred": { source: "iana" }, "text/gff3": { source: "iana" }, "text/grammar-ref-list": { source: "iana" }, "text/html": { source: "iana", compressible: true, extensions: ["html", "htm", "shtml"] }, "text/jade": { extensions: ["jade"] }, "text/javascript": { source: "iana", compressible: true }, "text/jcr-cnd": { source: "iana" }, "text/jsx": { compressible: true, extensions: ["jsx"] }, "text/less": { compressible: true, extensions: ["less"] }, "text/markdown": { source: "iana", compressible: true, extensions: ["markdown", "md"] }, "text/mathml": { source: "nginx", extensions: ["mml"] }, "text/mdx": { compressible: true, extensions: ["mdx"] }, "text/mizar": { source: "iana" }, "text/n3": { source: "iana", charset: "UTF-8", compressible: true, extensions: ["n3"] }, "text/parameters": { source: "iana", charset: "UTF-8" }, "text/parityfec": { source: "iana" }, "text/plain": { source: "iana", compressible: true, extensions: ["txt", "text", "conf", "def", "list", "log", "in", "ini"] }, "text/provenance-notation": { source: "iana", charset: "UTF-8" }, "text/prs.fallenstein.rst": { source: "iana" }, "text/prs.lines.tag": { source: "iana", extensions: ["dsc"] }, "text/prs.prop.logic": { source: "iana" }, "text/raptorfec": { source: "iana" }, "text/red": { source: "iana" }, "text/rfc822-headers": { source: "iana" }, "text/richtext": { source: "iana", compressible: true, extensions: ["rtx"] }, "text/rtf": { source: "iana", compressible: true, extensions: ["rtf"] }, "text/rtp-enc-aescm128": { source: "iana" }, "text/rtploopback": { source: "iana" }, "text/rtx": { source: "iana" }, "text/sgml": { source: "iana", extensions: ["sgml", "sgm"] }, "text/shaclc": { source: "iana" }, "text/shex": { source: "iana", extensions: ["shex"] }, "text/slim": { extensions: ["slim", "slm"] }, "text/spdx": { source: "iana", extensions: ["spdx"] }, "text/strings": { source: "iana" }, "text/stylus": { extensions: ["stylus", "styl"] }, "text/t140": { source: "iana" }, "text/tab-separated-values": { source: "iana", compressible: true, extensions: ["tsv"] }, "text/troff": { source: "iana", extensions: ["t", "tr", "roff", "man", "me", "ms"] }, "text/turtle": { source: "iana", charset: "UTF-8", extensions: ["ttl"] }, "text/ulpfec": { source: "iana" }, "text/uri-list": { source: "iana", compressible: true, extensions: ["uri", "uris", "urls"] }, "text/vcard": { source: "iana", compressible: true, extensions: ["vcard"] }, "text/vnd.a": { source: "iana" }, "text/vnd.abc": { source: "iana" }, "text/vnd.ascii-art": { source: "iana" }, "text/vnd.curl": { source: "iana", extensions: ["curl"] }, "text/vnd.curl.dcurl": { source: "apache", extensions: ["dcurl"] }, "text/vnd.curl.mcurl": { source: "apache", extensions: ["mcurl"] }, "text/vnd.curl.scurl": { source: "apache", extensions: ["scurl"] }, "text/vnd.debian.copyright": { source: "iana", charset: "UTF-8" }, "text/vnd.dmclientscript": { source: "iana" }, "text/vnd.dvb.subtitle": { source: "iana", extensions: ["sub"] }, "text/vnd.esmertec.theme-descriptor": { source: "iana", charset: "UTF-8" }, "text/vnd.familysearch.gedcom": { source: "iana", extensions: ["ged"] }, "text/vnd.ficlab.flt": { source: "iana" }, "text/vnd.fly": { source: "iana", extensions: ["fly"] }, "text/vnd.fmi.flexstor": { source: "iana", extensions: ["flx"] }, "text/vnd.gml": { source: "iana" }, "text/vnd.graphviz": { source: "iana", extensions: ["gv"] }, "text/vnd.hans": { source: "iana" }, "text/vnd.hgl": { source: "iana" }, "text/vnd.in3d.3dml": { source: "iana", extensions: ["3dml"] }, "text/vnd.in3d.spot": { source: "iana", extensions: ["spot"] }, "text/vnd.iptc.newsml": { source: "iana" }, "text/vnd.iptc.nitf": { source: "iana" }, "text/vnd.latex-z": { source: "iana" }, "text/vnd.motorola.reflex": { source: "iana" }, "text/vnd.ms-mediapackage": { source: "iana" }, "text/vnd.net2phone.commcenter.command": { source: "iana" }, "text/vnd.radisys.msml-basic-layout": { source: "iana" }, "text/vnd.senx.warpscript": { source: "iana" }, "text/vnd.si.uricatalogue": { source: "iana" }, "text/vnd.sosi": { source: "iana" }, "text/vnd.sun.j2me.app-descriptor": { source: "iana", charset: "UTF-8", extensions: ["jad"] }, "text/vnd.trolltech.linguist": { source: "iana", charset: "UTF-8" }, "text/vnd.wap.si": { source: "iana" }, "text/vnd.wap.sl": { source: "iana" }, "text/vnd.wap.wml": { source: "iana", extensions: ["wml"] }, "text/vnd.wap.wmlscript": { source: "iana", extensions: ["wmls"] }, "text/vtt": { source: "iana", charset: "UTF-8", compressible: true, extensions: ["vtt"] }, "text/x-asm": { source: "apache", extensions: ["s", "asm"] }, "text/x-c": { source: "apache", extensions: ["c", "cc", "cxx", "cpp", "h", "hh", "dic"] }, "text/x-component": { source: "nginx", extensions: ["htc"] }, "text/x-fortran": { source: "apache", extensions: ["f", "for", "f77", "f90"] }, "text/x-gwt-rpc": { compressible: true }, "text/x-handlebars-template": { extensions: ["hbs"] }, "text/x-java-source": { source: "apache", extensions: ["java"] }, "text/x-jquery-tmpl": { compressible: true }, "text/x-lua": { extensions: ["lua"] }, "text/x-markdown": { compressible: true, extensions: ["mkd"] }, "text/x-nfo": { source: "apache", extensions: ["nfo"] }, "text/x-opml": { source: "apache", extensions: ["opml"] }, "text/x-org": { compressible: true, extensions: ["org"] }, "text/x-pascal": { source: "apache", extensions: ["p", "pas"] }, "text/x-processing": { compressible: true, extensions: ["pde"] }, "text/x-sass": { extensions: ["sass"] }, "text/x-scss": { extensions: ["scss"] }, "text/x-setext": { source: "apache", extensions: ["etx"] }, "text/x-sfv": { source: "apache", extensions: ["sfv"] }, "text/x-suse-ymp": { compressible: true, extensions: ["ymp"] }, "text/x-uuencode": { source: "apache", extensions: ["uu"] }, "text/x-vcalendar": { source: "apache", extensions: ["vcs"] }, "text/x-vcard": { source: "apache", extensions: ["vcf"] }, "text/xml": { source: "iana", compressible: true, extensions: ["xml"] }, "text/xml-external-parsed-entity": { source: "iana" }, "text/yaml": { compressible: true, extensions: ["yaml", "yml"] }, "video/1d-interleaved-parityfec": { source: "iana" }, "video/3gpp": { source: "iana", extensions: ["3gp", "3gpp"] }, "video/3gpp-tt": { source: "iana" }, "video/3gpp2": { source: "iana", extensions: ["3g2"] }, "video/av1": { source: "iana" }, "video/bmpeg": { source: "iana" }, "video/bt656": { source: "iana" }, "video/celb": { source: "iana" }, "video/dv": { source: "iana" }, "video/encaprtp": { source: "iana" }, "video/ffv1": { source: "iana" }, "video/flexfec": { source: "iana" }, "video/h261": { source: "iana", extensions: ["h261"] }, "video/h263": { source: "iana", extensions: ["h263"] }, "video/h263-1998": { source: "iana" }, "video/h263-2000": { source: "iana" }, "video/h264": { source: "iana", extensions: ["h264"] }, "video/h264-rcdo": { source: "iana" }, "video/h264-svc": { source: "iana" }, "video/h265": { source: "iana" }, "video/iso.segment": { source: "iana", extensions: ["m4s"] }, "video/jpeg": { source: "iana", extensions: ["jpgv"] }, "video/jpeg2000": { source: "iana" }, "video/jpm": { source: "apache", extensions: ["jpm", "jpgm"] }, "video/jxsv": { source: "iana" }, "video/mj2": { source: "iana", extensions: ["mj2", "mjp2"] }, "video/mp1s": { source: "iana" }, "video/mp2p": { source: "iana" }, "video/mp2t": { source: "iana", extensions: ["ts"] }, "video/mp4": { source: "iana", compressible: false, extensions: ["mp4", "mp4v", "mpg4"] }, "video/mp4v-es": { source: "iana" }, "video/mpeg": { source: "iana", compressible: false, extensions: ["mpeg", "mpg", "mpe", "m1v", "m2v"] }, "video/mpeg4-generic": { source: "iana" }, "video/mpv": { source: "iana" }, "video/nv": { source: "iana" }, "video/ogg": { source: "iana", compressible: false, extensions: ["ogv"] }, "video/parityfec": { source: "iana" }, "video/pointer": { source: "iana" }, "video/quicktime": { source: "iana", compressible: false, extensions: ["qt", "mov"] }, "video/raptorfec": { source: "iana" }, "video/raw": { source: "iana" }, "video/rtp-enc-aescm128": { source: "iana" }, "video/rtploopback": { source: "iana" }, "video/rtx": { source: "iana" }, "video/scip": { source: "iana" }, "video/smpte291": { source: "iana" }, "video/smpte292m": { source: "iana" }, "video/ulpfec": { source: "iana" }, "video/vc1": { source: "iana" }, "video/vc2": { source: "iana" }, "video/vnd.cctv": { source: "iana" }, "video/vnd.dece.hd": { source: "iana", extensions: ["uvh", "uvvh"] }, "video/vnd.dece.mobile": { source: "iana", extensions: ["uvm", "uvvm"] }, "video/vnd.dece.mp4": { source: "iana" }, "video/vnd.dece.pd": { source: "iana", extensions: ["uvp", "uvvp"] }, "video/vnd.dece.sd": { source: "iana", extensions: ["uvs", "uvvs"] }, "video/vnd.dece.video": { source: "iana", extensions: ["uvv", "uvvv"] }, "video/vnd.directv.mpeg": { source: "iana" }, "video/vnd.directv.mpeg-tts": { source: "iana" }, "video/vnd.dlna.mpeg-tts": { source: "iana" }, "video/vnd.dvb.file": { source: "iana", extensions: ["dvb"] }, "video/vnd.fvt": { source: "iana", extensions: ["fvt"] }, "video/vnd.hns.video": { source: "iana" }, "video/vnd.iptvforum.1dparityfec-1010": { source: "iana" }, "video/vnd.iptvforum.1dparityfec-2005": { source: "iana" }, "video/vnd.iptvforum.2dparityfec-1010": { source: "iana" }, "video/vnd.iptvforum.2dparityfec-2005": { source: "iana" }, "video/vnd.iptvforum.ttsavc": { source: "iana" }, "video/vnd.iptvforum.ttsmpeg2": { source: "iana" }, "video/vnd.motorola.video": { source: "iana" }, "video/vnd.motorola.videop": { source: "iana" }, "video/vnd.mpegurl": { source: "iana", extensions: ["mxu", "m4u"] }, "video/vnd.ms-playready.media.pyv": { source: "iana", extensions: ["pyv"] }, "video/vnd.nokia.interleaved-multimedia": { source: "iana" }, "video/vnd.nokia.mp4vr": { source: "iana" }, "video/vnd.nokia.videovoip": { source: "iana" }, "video/vnd.objectvideo": { source: "iana" }, "video/vnd.radgamettools.bink": { source: "iana" }, "video/vnd.radgamettools.smacker": { source: "iana" }, "video/vnd.sealed.mpeg1": { source: "iana" }, "video/vnd.sealed.mpeg4": { source: "iana" }, "video/vnd.sealed.swf": { source: "iana" }, "video/vnd.sealedmedia.softseal.mov": { source: "iana" }, "video/vnd.uvvu.mp4": { source: "iana", extensions: ["uvu", "uvvu"] }, "video/vnd.vivo": { source: "iana", extensions: ["viv"] }, "video/vnd.youtube.yt": { source: "iana" }, "video/vp8": { source: "iana" }, "video/vp9": { source: "iana" }, "video/webm": { source: "apache", compressible: false, extensions: ["webm"] }, "video/x-f4v": { source: "apache", extensions: ["f4v"] }, "video/x-fli": { source: "apache", extensions: ["fli"] }, "video/x-flv": { source: "apache", compressible: false, extensions: ["flv"] }, "video/x-m4v": { source: "apache", extensions: ["m4v"] }, "video/x-matroska": { source: "apache", compressible: false, extensions: ["mkv", "mk3d", "mks"] }, "video/x-mng": { source: "apache", extensions: ["mng"] }, "video/x-ms-asf": { source: "apache", extensions: ["asf", "asx"] }, "video/x-ms-vob": { source: "apache", extensions: ["vob"] }, "video/x-ms-wm": { source: "apache", extensions: ["wm"] }, "video/x-ms-wmv": { source: "apache", compressible: false, extensions: ["wmv"] }, "video/x-ms-wmx": { source: "apache", extensions: ["wmx"] }, "video/x-ms-wvx": { source: "apache", extensions: ["wvx"] }, "video/x-msvideo": { source: "apache", extensions: ["avi"] }, "video/x-sgi-movie": { source: "apache", extensions: ["movie"] }, "video/x-smv": { source: "apache", extensions: ["smv"] }, "x-conference/x-cooltalk": { source: "apache", extensions: ["ice"] }, "x-shader/x-fragment": { compressible: true }, "x-shader/x-vertex": { compressible: true } };
function $e() {
  return Se || (Se = 1, function(e5) {
    var a2, n2, s2, i2 = Re ? je : (Re = 1, je = Me), o2 = import_path.default.extname, r2 = /^\s*([^;\s]*)(?:;|\s|$)/, c2 = /^text\//i;
    function p2(e6) {
      if (!e6 || "string" != typeof e6) return false;
      var a3 = r2.exec(e6), n3 = a3 && i2[a3[1].toLowerCase()];
      return n3 && n3.charset ? n3.charset : !(!a3 || !c2.test(a3[1])) && "UTF-8";
    }
    e5.charset = p2, e5.charsets = { lookup: p2 }, e5.contentType = function(a3) {
      if (!a3 || "string" != typeof a3) return false;
      var n3 = -1 === a3.indexOf("/") ? e5.lookup(a3) : a3;
      if (!n3) return false;
      if (-1 === n3.indexOf("charset")) {
        var t2 = e5.charset(n3);
        t2 && (n3 += "; charset=" + t2.toLowerCase());
      }
      return n3;
    }, e5.extension = function(a3) {
      if (!a3 || "string" != typeof a3) return false;
      var n3 = r2.exec(a3), t2 = n3 && e5.extensions[n3[1].toLowerCase()];
      if (!t2 || !t2.length) return false;
      return t2[0];
    }, e5.extensions = /* @__PURE__ */ Object.create(null), e5.lookup = function(a3) {
      if (!a3 || "string" != typeof a3) return false;
      var n3 = o2("x." + a3).toLowerCase().substr(1);
      if (!n3) return false;
      return e5.types[n3] || false;
    }, e5.types = /* @__PURE__ */ Object.create(null), a2 = e5.extensions, n2 = e5.types, s2 = ["nginx", "apache", void 0, "iana"], Object.keys(i2).forEach(function(e6) {
      var t2 = i2[e6], o3 = t2.extensions;
      if (o3 && o3.length) {
        a2[e6] = o3;
        for (var r3 = 0; r3 < o3.length; r3++) {
          var c3 = o3[r3];
          if (n2[c3]) {
            var p3 = s2.indexOf(i2[n2[c3]].source), l2 = s2.indexOf(t2.source);
            if ("application/octet-stream" !== n2[c3] && (p3 > l2 || p3 === l2 && "application/" === n2[c3].substr(0, 12))) continue;
          }
          n2[c3] = e6;
        }
      }
    });
  }(Ne)), Ne;
}
function We() {
  if (Ce) return qe;
  Ce = 1;
  var e5 = Te ? Ee : (Te = 1, Ee = function(e6) {
    var a2 = "function" == typeof setImmediate ? setImmediate : "object" == typeof process && "function" == typeof process.nextTick ? process.nextTick : null;
    a2 ? a2(e6) : setTimeout(e6, 0);
  });
  return qe = function(a2) {
    var n2 = false;
    return e5(function() {
      n2 = true;
    }), function(t2, s2) {
      n2 ? a2(t2, s2) : e5(function() {
        a2(t2, s2);
      });
    };
  };
}
function He() {
  if (Oe) return Ae;
  function e5(e6) {
    "function" == typeof this.jobs[e6] && this.jobs[e6]();
  }
  return Oe = 1, Ae = function(a2) {
    Object.keys(a2.jobs).forEach(e5.bind(a2)), a2.jobs = {};
  };
}
function Ve() {
  if (De) return Fe;
  De = 1;
  var e5 = We(), a2 = He();
  return Fe = function(n2, t2, s2, i2) {
    var o2 = s2.keyedList ? s2.keyedList[s2.index] : s2.index;
    s2.jobs[o2] = function(a3, n3, t3, s3) {
      var i3;
      i3 = 2 == a3.length ? a3(t3, e5(s3)) : a3(t3, n3, e5(s3));
      return i3;
    }(t2, o2, n2[o2], function(e6, n3) {
      o2 in s2.jobs && (delete s2.jobs[o2], e6 ? a2(s2) : s2.results[o2] = n3, i2(e6, s2.results));
    });
  };
}
function Ge() {
  if (Be) return Pe;
  return Be = 1, Pe = function(e5, a2) {
    var n2 = !Array.isArray(e5), t2 = { index: 0, keyedList: n2 || a2 ? Object.keys(e5) : null, jobs: {}, results: n2 ? {} : [], size: n2 ? Object.keys(e5).length : e5.length };
    a2 && t2.keyedList.sort(n2 ? a2 : function(n3, t3) {
      return a2(e5[n3], e5[t3]);
    });
    return t2;
  };
}
function Je() {
  if (Ue) return Le;
  Ue = 1;
  var e5 = He(), a2 = We();
  return Le = function(n2) {
    if (!Object.keys(this.jobs).length) return;
    this.index = this.size, e5(this), a2(n2)(null, this.results);
  };
}
function Ke() {
  if (Ie) return ze;
  Ie = 1;
  var e5 = Ve(), a2 = Ge(), n2 = Je();
  return ze = function(t2, s2, i2) {
    var o2 = a2(t2);
    for (; o2.index < (o2.keyedList || t2).length; ) e5(t2, s2, o2, function(e6, a3) {
      e6 ? i2(e6, a3) : 0 !== Object.keys(o2.jobs).length || i2(null, o2.results);
    }), o2.index++;
    return n2.bind(o2, i2);
  };
}
var Qe;
var Ye;
var Xe;
var Ze;
var ea;
var aa;
var na;
var ta;
var sa;
var ia;
var oa;
var ra;
var ca;
var pa;
var la;
var ua;
var da;
var ma;
var ha;
var fa;
var xa;
var va;
var ba;
var ga;
var ya;
var wa;
var _a;
var ka;
var ja;
var Ra;
var Sa;
var Ea;
var Ta;
var qa;
var Ca;
var Aa;
var Oa;
var Fa;
var Da;
var Pa;
var Ba;
var La;
var Ua;
var za;
var Ia;
var Na;
var Ma;
var $a;
var Wa;
var Ha;
var Va;
var Ga;
var Ja;
var Ka;
var Qa;
var Ya;
var Xa;
var Za;
var en;
var an;
var nn;
var tn;
var sn;
var on;
var rn;
var cn;
var pn;
var ln;
var un;
var dn;
var mn;
var hn;
var fn;
var xn;
var vn;
var bn;
var gn;
var yn;
var wn;
var _n;
var kn;
var jn = { exports: {} };
function Rn() {
  if (Qe) return jn.exports;
  Qe = 1;
  var e5 = Ve(), a2 = Ge(), n2 = Je();
  function t2(e6, a3) {
    return e6 < a3 ? -1 : e6 > a3 ? 1 : 0;
  }
  return jn.exports = function(t3, s2, i2, o2) {
    var r2 = a2(t3, i2);
    return e5(t3, s2, r2, function a3(n3, i3) {
      n3 ? o2(n3, i3) : (r2.index++, r2.index < (r2.keyedList || t3).length ? e5(t3, s2, r2, a3) : o2(null, r2.results));
    }), n2.bind(r2, o2);
  }, jn.exports.ascending = t2, jn.exports.descending = function(e6, a3) {
    return -1 * t2(e6, a3);
  }, jn.exports;
}
function Sn() {
  if (Xe) return Ye;
  Xe = 1;
  var e5 = Rn();
  return Ye = function(a2, n2, t2) {
    return e5(a2, n2, null, t2);
  };
}
function En() {
  return ea ? Ze : (ea = 1, Ze = { parallel: Ke(), serial: Sn(), serialOrdered: Rn() });
}
function Tn() {
  return na ? aa : (na = 1, aa = Object);
}
function qn() {
  return sa ? ta : (sa = 1, ta = Error);
}
function Cn() {
  return oa ? ia : (oa = 1, ia = EvalError);
}
function An() {
  return ca ? ra : (ca = 1, ra = RangeError);
}
function On() {
  return la ? pa : (la = 1, pa = ReferenceError);
}
function Fn() {
  return da ? ua : (da = 1, ua = SyntaxError);
}
function Dn() {
  return ha ? ma : (ha = 1, ma = TypeError);
}
function Pn() {
  return xa ? fa : (xa = 1, fa = URIError);
}
function Bn() {
  return ba ? va : (ba = 1, va = Math.abs);
}
function Ln() {
  return ya ? ga : (ya = 1, ga = Math.floor);
}
function Un() {
  return _a ? wa : (_a = 1, wa = Math.max);
}
function zn() {
  return ja ? ka : (ja = 1, ka = Math.min);
}
function In() {
  return Sa ? Ra : (Sa = 1, Ra = Math.pow);
}
function Nn() {
  return Ta ? Ea : (Ta = 1, Ea = Math.round);
}
function Mn() {
  return Ca ? qa : (Ca = 1, qa = Number.isNaN || function(e5) {
    return e5 != e5;
  });
}
function $n() {
  if (Oa) return Aa;
  Oa = 1;
  var e5 = Mn();
  return Aa = function(a2) {
    return e5(a2) || 0 === a2 ? a2 : a2 < 0 ? -1 : 1;
  };
}
function Wn() {
  return Da ? Fa : (Da = 1, Fa = Object.getOwnPropertyDescriptor);
}
function Hn() {
  if (Ba) return Pa;
  Ba = 1;
  var e5 = Wn();
  if (e5) try {
    e5([], "length");
  } catch (a2) {
    e5 = null;
  }
  return Pa = e5;
}
function Vn() {
  if (Ua) return La;
  Ua = 1;
  var e5 = Object.defineProperty || false;
  if (e5) try {
    e5({}, "a", { value: 1 });
  } catch (a2) {
    e5 = false;
  }
  return La = e5;
}
function Gn() {
  return Ia ? za : (Ia = 1, za = function() {
    if ("function" != typeof Symbol || "function" != typeof Object.getOwnPropertySymbols) return false;
    if ("symbol" == typeof Symbol.iterator) return true;
    var e5 = {}, a2 = Symbol("test"), n2 = Object(a2);
    if ("string" == typeof a2) return false;
    if ("[object Symbol]" !== Object.prototype.toString.call(a2)) return false;
    if ("[object Symbol]" !== Object.prototype.toString.call(n2)) return false;
    for (var t2 in e5[a2] = 42, e5) return false;
    if ("function" == typeof Object.keys && 0 !== Object.keys(e5).length) return false;
    if ("function" == typeof Object.getOwnPropertyNames && 0 !== Object.getOwnPropertyNames(e5).length) return false;
    var s2 = Object.getOwnPropertySymbols(e5);
    if (1 !== s2.length || s2[0] !== a2) return false;
    if (!Object.prototype.propertyIsEnumerable.call(e5, a2)) return false;
    if ("function" == typeof Object.getOwnPropertyDescriptor) {
      var i2 = Object.getOwnPropertyDescriptor(e5, a2);
      if (42 !== i2.value || true !== i2.enumerable) return false;
    }
    return true;
  });
}
function Jn() {
  if (Ma) return Na;
  Ma = 1;
  var e5 = "undefined" != typeof Symbol && Symbol, a2 = Gn();
  return Na = function() {
    return "function" == typeof e5 && ("function" == typeof Symbol && ("symbol" == typeof e5("foo") && ("symbol" == typeof Symbol("bar") && a2())));
  };
}
function Kn() {
  return Wa ? $a : (Wa = 1, $a = "undefined" != typeof Reflect && Reflect.getPrototypeOf || null);
}
function Qn() {
  return Va ? Ha : (Va = 1, Ha = Tn().getPrototypeOf || null);
}
function Yn() {
  if (Ja) return Ga;
  Ja = 1;
  var e5 = Object.prototype.toString, a2 = Math.max, n2 = function(e6, a3) {
    for (var n3 = [], t2 = 0; t2 < e6.length; t2 += 1) n3[t2] = e6[t2];
    for (var s2 = 0; s2 < a3.length; s2 += 1) n3[s2 + e6.length] = a3[s2];
    return n3;
  };
  return Ga = function(t2) {
    var s2 = this;
    if ("function" != typeof s2 || "[object Function]" !== e5.apply(s2)) throw new TypeError("Function.prototype.bind called on incompatible " + s2);
    for (var i2, o2 = function(e6, a3) {
      for (var n3 = [], t3 = a3, s3 = 0; t3 < e6.length; t3 += 1, s3 += 1) n3[s3] = e6[t3];
      return n3;
    }(arguments, 1), r2 = a2(0, s2.length - o2.length), c2 = [], p2 = 0; p2 < r2; p2++) c2[p2] = "$" + p2;
    if (i2 = Function("binder", "return function (" + function(e6, a3) {
      for (var n3 = "", t3 = 0; t3 < e6.length; t3 += 1) n3 += e6[t3], t3 + 1 < e6.length && (n3 += a3);
      return n3;
    }(c2, ",") + "){ return binder.apply(this,arguments); }")(function() {
      if (this instanceof i2) {
        var e6 = s2.apply(this, n2(o2, arguments));
        return Object(e6) === e6 ? e6 : this;
      }
      return s2.apply(t2, n2(o2, arguments));
    }), s2.prototype) {
      var l2 = function() {
      };
      l2.prototype = s2.prototype, i2.prototype = new l2(), l2.prototype = null;
    }
    return i2;
  }, Ga;
}
function Xn() {
  if (Qa) return Ka;
  Qa = 1;
  var e5 = Yn();
  return Ka = Function.prototype.bind || e5;
}
function Zn() {
  return Xa ? Ya : (Xa = 1, Ya = Function.prototype.call);
}
function et() {
  return en ? Za : (en = 1, Za = Function.prototype.apply);
}
function at() {
  if (sn) return tn;
  sn = 1;
  var e5 = Xn(), a2 = et(), n2 = Zn(), t2 = nn ? an : (nn = 1, an = "undefined" != typeof Reflect && Reflect && Reflect.apply);
  return tn = t2 || e5.call(n2, a2);
}
function nt() {
  if (pn) return cn;
  pn = 1;
  var e5, a2 = function() {
    if (rn) return on;
    rn = 1;
    var e6 = Xn(), a3 = Dn(), n3 = Zn(), t3 = at();
    return on = function(s3) {
      if (s3.length < 1 || "function" != typeof s3[0]) throw new a3("a function is required");
      return t3(e6, n3, s3);
    };
  }(), n2 = Hn();
  try {
    e5 = [].__proto__ === Array.prototype;
  } catch (e6) {
    if (!e6 || "object" != typeof e6 || !("code" in e6) || "ERR_PROTO_ACCESS" !== e6.code) throw e6;
  }
  var t2 = !!e5 && n2 && n2(Object.prototype, "__proto__"), s2 = Object, i2 = s2.getPrototypeOf;
  return cn = t2 && "function" == typeof t2.get ? a2([t2.get]) : "function" == typeof i2 && function(e6) {
    return i2(null == e6 ? e6 : s2(e6));
  };
}
function tt() {
  if (un) return ln;
  un = 1;
  var e5 = Kn(), a2 = Qn(), n2 = nt();
  return ln = e5 ? function(a3) {
    return e5(a3);
  } : a2 ? function(e6) {
    if (!e6 || "object" != typeof e6 && "function" != typeof e6) throw new TypeError("getProto: not an object");
    return a2(e6);
  } : n2 ? function(e6) {
    return n2(e6);
  } : null;
}
function st() {
  if (mn) return dn;
  mn = 1;
  var e5 = Function.prototype.call, a2 = Object.prototype.hasOwnProperty, n2 = Xn();
  return dn = n2.call(e5, a2);
}
function it() {
  if (fn) return hn;
  var e5;
  fn = 1;
  var a2 = Tn(), n2 = qn(), t2 = Cn(), s2 = An(), i2 = On(), o2 = Fn(), r2 = Dn(), c2 = Pn(), p2 = Bn(), l2 = Ln(), u2 = Un(), d2 = zn(), m2 = In(), h2 = Nn(), f2 = $n(), x2 = Function, v2 = function(e6) {
    try {
      return x2('"use strict"; return (' + e6 + ").constructor;")();
    } catch (e7) {
    }
  }, b2 = Hn(), g2 = Vn(), y2 = function() {
    throw new r2();
  }, w2 = b2 ? function() {
    try {
      return y2;
    } catch (e6) {
      try {
        return b2(arguments, "callee").get;
      } catch (e7) {
        return y2;
      }
    }
  }() : y2, _2 = Jn()(), k2 = tt(), j2 = Qn(), R2 = Kn(), S2 = et(), E2 = Zn(), T2 = {}, q2 = "undefined" != typeof Uint8Array && k2 ? k2(Uint8Array) : e5, C2 = { __proto__: null, "%AggregateError%": "undefined" == typeof AggregateError ? e5 : AggregateError, "%Array%": Array, "%ArrayBuffer%": "undefined" == typeof ArrayBuffer ? e5 : ArrayBuffer, "%ArrayIteratorPrototype%": _2 && k2 ? k2([][Symbol.iterator]()) : e5, "%AsyncFromSyncIteratorPrototype%": e5, "%AsyncFunction%": T2, "%AsyncGenerator%": T2, "%AsyncGeneratorFunction%": T2, "%AsyncIteratorPrototype%": T2, "%Atomics%": "undefined" == typeof Atomics ? e5 : Atomics, "%BigInt%": "undefined" == typeof BigInt ? e5 : BigInt, "%BigInt64Array%": "undefined" == typeof BigInt64Array ? e5 : BigInt64Array, "%BigUint64Array%": "undefined" == typeof BigUint64Array ? e5 : BigUint64Array, "%Boolean%": Boolean, "%DataView%": "undefined" == typeof DataView ? e5 : DataView, "%Date%": Date, "%decodeURI%": decodeURI, "%decodeURIComponent%": decodeURIComponent, "%encodeURI%": encodeURI, "%encodeURIComponent%": encodeURIComponent, "%Error%": n2, "%eval%": eval, "%EvalError%": t2, "%Float32Array%": "undefined" == typeof Float32Array ? e5 : Float32Array, "%Float64Array%": "undefined" == typeof Float64Array ? e5 : Float64Array, "%FinalizationRegistry%": "undefined" == typeof FinalizationRegistry ? e5 : FinalizationRegistry, "%Function%": x2, "%GeneratorFunction%": T2, "%Int8Array%": "undefined" == typeof Int8Array ? e5 : Int8Array, "%Int16Array%": "undefined" == typeof Int16Array ? e5 : Int16Array, "%Int32Array%": "undefined" == typeof Int32Array ? e5 : Int32Array, "%isFinite%": isFinite, "%isNaN%": isNaN, "%IteratorPrototype%": _2 && k2 ? k2(k2([][Symbol.iterator]())) : e5, "%JSON%": "object" == typeof JSON ? JSON : e5, "%Map%": "undefined" == typeof Map ? e5 : Map, "%MapIteratorPrototype%": "undefined" != typeof Map && _2 && k2 ? k2((/* @__PURE__ */ new Map())[Symbol.iterator]()) : e5, "%Math%": Math, "%Number%": Number, "%Object%": a2, "%Object.getOwnPropertyDescriptor%": b2, "%parseFloat%": parseFloat, "%parseInt%": parseInt, "%Promise%": "undefined" == typeof Promise ? e5 : Promise, "%Proxy%": "undefined" == typeof Proxy ? e5 : Proxy, "%RangeError%": s2, "%ReferenceError%": i2, "%Reflect%": "undefined" == typeof Reflect ? e5 : Reflect, "%RegExp%": RegExp, "%Set%": "undefined" == typeof Set ? e5 : Set, "%SetIteratorPrototype%": "undefined" != typeof Set && _2 && k2 ? k2((/* @__PURE__ */ new Set())[Symbol.iterator]()) : e5, "%SharedArrayBuffer%": "undefined" == typeof SharedArrayBuffer ? e5 : SharedArrayBuffer, "%String%": String, "%StringIteratorPrototype%": _2 && k2 ? k2(""[Symbol.iterator]()) : e5, "%Symbol%": _2 ? Symbol : e5, "%SyntaxError%": o2, "%ThrowTypeError%": w2, "%TypedArray%": q2, "%TypeError%": r2, "%Uint8Array%": "undefined" == typeof Uint8Array ? e5 : Uint8Array, "%Uint8ClampedArray%": "undefined" == typeof Uint8ClampedArray ? e5 : Uint8ClampedArray, "%Uint16Array%": "undefined" == typeof Uint16Array ? e5 : Uint16Array, "%Uint32Array%": "undefined" == typeof Uint32Array ? e5 : Uint32Array, "%URIError%": c2, "%WeakMap%": "undefined" == typeof WeakMap ? e5 : WeakMap, "%WeakRef%": "undefined" == typeof WeakRef ? e5 : WeakRef, "%WeakSet%": "undefined" == typeof WeakSet ? e5 : WeakSet, "%Function.prototype.call%": E2, "%Function.prototype.apply%": S2, "%Object.defineProperty%": g2, "%Object.getPrototypeOf%": j2, "%Math.abs%": p2, "%Math.floor%": l2, "%Math.max%": u2, "%Math.min%": d2, "%Math.pow%": m2, "%Math.round%": h2, "%Math.sign%": f2, "%Reflect.getPrototypeOf%": R2 };
  if (k2) try {
    null.error;
  } catch (e6) {
    var A2 = k2(k2(e6));
    C2["%Error.prototype%"] = A2;
  }
  var O2 = function e6(a3) {
    var n3;
    if ("%AsyncFunction%" === a3) n3 = v2("async function () {}");
    else if ("%GeneratorFunction%" === a3) n3 = v2("function* () {}");
    else if ("%AsyncGeneratorFunction%" === a3) n3 = v2("async function* () {}");
    else if ("%AsyncGenerator%" === a3) {
      var t3 = e6("%AsyncGeneratorFunction%");
      t3 && (n3 = t3.prototype);
    } else if ("%AsyncIteratorPrototype%" === a3) {
      var s3 = e6("%AsyncGenerator%");
      s3 && k2 && (n3 = k2(s3.prototype));
    }
    return C2[a3] = n3, n3;
  }, F2 = { __proto__: null, "%ArrayBufferPrototype%": ["ArrayBuffer", "prototype"], "%ArrayPrototype%": ["Array", "prototype"], "%ArrayProto_entries%": ["Array", "prototype", "entries"], "%ArrayProto_forEach%": ["Array", "prototype", "forEach"], "%ArrayProto_keys%": ["Array", "prototype", "keys"], "%ArrayProto_values%": ["Array", "prototype", "values"], "%AsyncFunctionPrototype%": ["AsyncFunction", "prototype"], "%AsyncGenerator%": ["AsyncGeneratorFunction", "prototype"], "%AsyncGeneratorPrototype%": ["AsyncGeneratorFunction", "prototype", "prototype"], "%BooleanPrototype%": ["Boolean", "prototype"], "%DataViewPrototype%": ["DataView", "prototype"], "%DatePrototype%": ["Date", "prototype"], "%ErrorPrototype%": ["Error", "prototype"], "%EvalErrorPrototype%": ["EvalError", "prototype"], "%Float32ArrayPrototype%": ["Float32Array", "prototype"], "%Float64ArrayPrototype%": ["Float64Array", "prototype"], "%FunctionPrototype%": ["Function", "prototype"], "%Generator%": ["GeneratorFunction", "prototype"], "%GeneratorPrototype%": ["GeneratorFunction", "prototype", "prototype"], "%Int8ArrayPrototype%": ["Int8Array", "prototype"], "%Int16ArrayPrototype%": ["Int16Array", "prototype"], "%Int32ArrayPrototype%": ["Int32Array", "prototype"], "%JSONParse%": ["JSON", "parse"], "%JSONStringify%": ["JSON", "stringify"], "%MapPrototype%": ["Map", "prototype"], "%NumberPrototype%": ["Number", "prototype"], "%ObjectPrototype%": ["Object", "prototype"], "%ObjProto_toString%": ["Object", "prototype", "toString"], "%ObjProto_valueOf%": ["Object", "prototype", "valueOf"], "%PromisePrototype%": ["Promise", "prototype"], "%PromiseProto_then%": ["Promise", "prototype", "then"], "%Promise_all%": ["Promise", "all"], "%Promise_reject%": ["Promise", "reject"], "%Promise_resolve%": ["Promise", "resolve"], "%RangeErrorPrototype%": ["RangeError", "prototype"], "%ReferenceErrorPrototype%": ["ReferenceError", "prototype"], "%RegExpPrototype%": ["RegExp", "prototype"], "%SetPrototype%": ["Set", "prototype"], "%SharedArrayBufferPrototype%": ["SharedArrayBuffer", "prototype"], "%StringPrototype%": ["String", "prototype"], "%SymbolPrototype%": ["Symbol", "prototype"], "%SyntaxErrorPrototype%": ["SyntaxError", "prototype"], "%TypedArrayPrototype%": ["TypedArray", "prototype"], "%TypeErrorPrototype%": ["TypeError", "prototype"], "%Uint8ArrayPrototype%": ["Uint8Array", "prototype"], "%Uint8ClampedArrayPrototype%": ["Uint8ClampedArray", "prototype"], "%Uint16ArrayPrototype%": ["Uint16Array", "prototype"], "%Uint32ArrayPrototype%": ["Uint32Array", "prototype"], "%URIErrorPrototype%": ["URIError", "prototype"], "%WeakMapPrototype%": ["WeakMap", "prototype"], "%WeakSetPrototype%": ["WeakSet", "prototype"] }, D2 = Xn(), P2 = st(), B2 = D2.call(E2, Array.prototype.concat), L2 = D2.call(S2, Array.prototype.splice), U2 = D2.call(E2, String.prototype.replace), z2 = D2.call(E2, String.prototype.slice), I2 = D2.call(E2, RegExp.prototype.exec), N2 = /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g, M2 = /\\(\\)?/g, $2 = function(e6, a3) {
    var n3, t3 = e6;
    if (P2(F2, t3) && (t3 = "%" + (n3 = F2[t3])[0] + "%"), P2(C2, t3)) {
      var s3 = C2[t3];
      if (s3 === T2 && (s3 = O2(t3)), void 0 === s3 && !a3) throw new r2("intrinsic " + e6 + " exists, but is not available. Please file an issue!");
      return { alias: n3, name: t3, value: s3 };
    }
    throw new o2("intrinsic " + e6 + " does not exist!");
  };
  return hn = function(e6, a3) {
    if ("string" != typeof e6 || 0 === e6.length) throw new r2("intrinsic name must be a non-empty string");
    if (arguments.length > 1 && "boolean" != typeof a3) throw new r2('"allowMissing" argument must be a boolean');
    if (null === I2(/^%?[^%]*%?$/, e6)) throw new o2("`%` may not be present anywhere but at the beginning and end of the intrinsic name");
    var n3 = function(e7) {
      var a4 = z2(e7, 0, 1), n4 = z2(e7, -1);
      if ("%" === a4 && "%" !== n4) throw new o2("invalid intrinsic syntax, expected closing `%`");
      if ("%" === n4 && "%" !== a4) throw new o2("invalid intrinsic syntax, expected opening `%`");
      var t4 = [];
      return U2(e7, N2, function(e8, a5, n5, s4) {
        t4[t4.length] = n5 ? U2(s4, M2, "$1") : a5 || e8;
      }), t4;
    }(e6), t3 = n3.length > 0 ? n3[0] : "", s3 = $2("%" + t3 + "%", a3), i3 = s3.name, c3 = s3.value, p3 = false, l3 = s3.alias;
    l3 && (t3 = l3[0], L2(n3, B2([0, 1], l3)));
    for (var u3 = 1, d3 = true; u3 < n3.length; u3 += 1) {
      var m3 = n3[u3], h3 = z2(m3, 0, 1), f3 = z2(m3, -1);
      if (('"' === h3 || "'" === h3 || "`" === h3 || '"' === f3 || "'" === f3 || "`" === f3) && h3 !== f3) throw new o2("property names with quotes must have matching quotes");
      if ("constructor" !== m3 && d3 || (p3 = true), P2(C2, i3 = "%" + (t3 += "." + m3) + "%")) c3 = C2[i3];
      else if (null != c3) {
        if (!(m3 in c3)) {
          if (!a3) throw new r2("base intrinsic for " + e6 + " exists, but the property is not available.");
          return;
        }
        if (b2 && u3 + 1 >= n3.length) {
          var x3 = b2(c3, m3);
          c3 = (d3 = !!x3) && "get" in x3 && !("originalValue" in x3.get) ? x3.get : c3[m3];
        } else d3 = P2(c3, m3), c3 = c3[m3];
        d3 && !p3 && (C2[i3] = c3);
      }
    }
    return c3;
  }, hn;
}
function ot() {
  if (gn) return bn;
  gn = 1;
  var e5 = it()("%Object.defineProperty%", true), a2 = function() {
    if (vn) return xn;
    vn = 1;
    var e6 = Gn();
    return xn = function() {
      return e6() && !!Symbol.toStringTag;
    };
  }()(), n2 = st(), t2 = Dn(), s2 = a2 ? Symbol.toStringTag : null;
  return bn = function(a3, i2) {
    var o2 = arguments.length > 2 && !!arguments[2] && arguments[2].force, r2 = arguments.length > 2 && !!arguments[2] && arguments[2].nonConfigurable;
    if (void 0 !== o2 && "boolean" != typeof o2 || void 0 !== r2 && "boolean" != typeof r2) throw new t2("if provided, the `overrideIfSet` and `nonConfigurable` options must be booleans");
    !s2 || !o2 && n2(a3, s2) || (e5 ? e5(a3, s2, { configurable: !r2, enumerable: false, value: i2, writable: false }) : a3[s2] = i2);
  }, bn;
}
function rt() {
  return wn || (wn = 1, yn = function(e5, a2) {
    return Object.keys(a2).forEach(function(n2) {
      e5[n2] = e5[n2] || a2[n2];
    }), e5;
  }), yn;
}
var ct = function() {
  if (kn) return _n;
  kn = 1;
  var n2 = ke(), c2 = import_util.default, p2 = import_path.default, l2 = import_http.default, u2 = import_https.default, d2 = import_url.default.parse, m2 = import_fs.default, h2 = import_stream.default.Stream, f2 = $e(), x2 = En(), v2 = ot(), b2 = rt();
  function g2(e5) {
    if (!(this instanceof g2)) return new g2(e5);
    for (var a2 in this._overheadLength = 0, this._valueLength = 0, this._valuesToMeasure = [], n2.call(this), e5 = e5 || {}) this[a2] = e5[a2];
  }
  return _n = g2, c2.inherits(g2, n2), g2.LINE_BREAK = "\r\n", g2.DEFAULT_CONTENT_TYPE = "application/octet-stream", g2.prototype.append = function(e5, a2, t2) {
    "string" == typeof (t2 = t2 || {}) && (t2 = { filename: t2 });
    var s2 = n2.prototype.append.bind(this);
    if ("number" == typeof a2 && (a2 = "" + a2), Array.isArray(a2)) this._error(new Error("Arrays are not supported."));
    else {
      var i2 = this._multiPartHeader(e5, a2, t2), o2 = this._multiPartFooter();
      s2(i2), s2(a2), s2(o2), this._trackLength(i2, a2, t2);
    }
  }, g2.prototype._trackLength = function(e5, a2, n3) {
    var t2 = 0;
    null != n3.knownLength ? t2 += +n3.knownLength : Buffer.isBuffer(a2) ? t2 = a2.length : "string" == typeof a2 && (t2 = Buffer.byteLength(a2)), this._valueLength += t2, this._overheadLength += Buffer.byteLength(e5) + g2.LINE_BREAK.length, a2 && (a2.path || a2.readable && Object.prototype.hasOwnProperty.call(a2, "httpVersion") || a2 instanceof h2) && (n3.knownLength || this._valuesToMeasure.push(a2));
  }, g2.prototype._lengthRetriever = function(e5, a2) {
    Object.prototype.hasOwnProperty.call(e5, "fd") ? null != e5.end && e5.end != 1 / 0 && null != e5.start ? a2(null, e5.end + 1 - (e5.start ? e5.start : 0)) : m2.stat(e5.path, function(n3, t2) {
      var s2;
      n3 ? a2(n3) : (s2 = t2.size - (e5.start ? e5.start : 0), a2(null, s2));
    }) : Object.prototype.hasOwnProperty.call(e5, "httpVersion") ? a2(null, +e5.headers["content-length"]) : Object.prototype.hasOwnProperty.call(e5, "httpModule") ? (e5.on("response", function(n3) {
      e5.pause(), a2(null, +n3.headers["content-length"]);
    }), e5.resume()) : a2("Unknown stream");
  }, g2.prototype._multiPartHeader = function(e5, a2, n3) {
    if ("string" == typeof n3.header) return n3.header;
    var t2, s2 = this._getContentDisposition(a2, n3), i2 = this._getContentType(a2, n3), o2 = "", r2 = { "Content-Disposition": ["form-data", 'name="' + e5 + '"'].concat(s2 || []), "Content-Type": [].concat(i2 || []) };
    for (var c3 in "object" == typeof n3.header && b2(r2, n3.header), r2) if (Object.prototype.hasOwnProperty.call(r2, c3)) {
      if (null == (t2 = r2[c3])) continue;
      Array.isArray(t2) || (t2 = [t2]), t2.length && (o2 += c3 + ": " + t2.join("; ") + g2.LINE_BREAK);
    }
    return "--" + this.getBoundary() + g2.LINE_BREAK + o2 + g2.LINE_BREAK;
  }, g2.prototype._getContentDisposition = function(e5, a2) {
    var n3, t2;
    return "string" == typeof a2.filepath ? n3 = p2.normalize(a2.filepath).replace(/\\/g, "/") : a2.filename || e5.name || e5.path ? n3 = p2.basename(a2.filename || e5.name || e5.path) : e5.readable && Object.prototype.hasOwnProperty.call(e5, "httpVersion") && (n3 = p2.basename(e5.client._httpMessage.path || "")), n3 && (t2 = 'filename="' + n3 + '"'), t2;
  }, g2.prototype._getContentType = function(e5, a2) {
    var n3 = a2.contentType;
    return !n3 && e5.name && (n3 = f2.lookup(e5.name)), !n3 && e5.path && (n3 = f2.lookup(e5.path)), !n3 && e5.readable && Object.prototype.hasOwnProperty.call(e5, "httpVersion") && (n3 = e5.headers["content-type"]), n3 || !a2.filepath && !a2.filename || (n3 = f2.lookup(a2.filepath || a2.filename)), n3 || "object" != typeof e5 || (n3 = g2.DEFAULT_CONTENT_TYPE), n3;
  }, g2.prototype._multiPartFooter = function() {
    return function(e5) {
      var a2 = g2.LINE_BREAK;
      0 === this._streams.length && (a2 += this._lastBoundary()), e5(a2);
    }.bind(this);
  }, g2.prototype._lastBoundary = function() {
    return "--" + this.getBoundary() + "--" + g2.LINE_BREAK;
  }, g2.prototype.getHeaders = function(e5) {
    var a2, n3 = { "content-type": "multipart/form-data; boundary=" + this.getBoundary() };
    for (a2 in e5) Object.prototype.hasOwnProperty.call(e5, a2) && (n3[a2.toLowerCase()] = e5[a2]);
    return n3;
  }, g2.prototype.setBoundary = function(e5) {
    this._boundary = e5;
  }, g2.prototype.getBoundary = function() {
    return this._boundary || this._generateBoundary(), this._boundary;
  }, g2.prototype.getBuffer = function() {
    for (var e5 = new Buffer.alloc(0), a2 = this.getBoundary(), n3 = 0, t2 = this._streams.length; n3 < t2; n3++) "function" != typeof this._streams[n3] && (e5 = Buffer.isBuffer(this._streams[n3]) ? Buffer.concat([e5, this._streams[n3]]) : Buffer.concat([e5, Buffer.from(this._streams[n3])]), "string" == typeof this._streams[n3] && this._streams[n3].substring(2, a2.length + 2) === a2 || (e5 = Buffer.concat([e5, Buffer.from(g2.LINE_BREAK)])));
    return Buffer.concat([e5, Buffer.from(this._lastBoundary())]);
  }, g2.prototype._generateBoundary = function() {
    for (var e5 = "--------------------------", a2 = 0; a2 < 24; a2++) e5 += Math.floor(10 * Math.random()).toString(16);
    this._boundary = e5;
  }, g2.prototype.getLengthSync = function() {
    var e5 = this._overheadLength + this._valueLength;
    return this._streams.length && (e5 += this._lastBoundary().length), this.hasKnownLength() || this._error(new Error("Cannot calculate proper length in synchronous way.")), e5;
  }, g2.prototype.hasKnownLength = function() {
    var e5 = true;
    return this._valuesToMeasure.length && (e5 = false), e5;
  }, g2.prototype.getLength = function(e5) {
    var a2 = this._overheadLength + this._valueLength;
    this._streams.length && (a2 += this._lastBoundary().length), this._valuesToMeasure.length ? x2.parallel(this._valuesToMeasure, this._lengthRetriever, function(n3, t2) {
      n3 ? e5(n3) : (t2.forEach(function(e6) {
        a2 += e6;
      }), e5(null, a2));
    }) : process.nextTick(e5.bind(this, null, a2));
  }, g2.prototype.submit = function(e5, a2) {
    var n3, t2, s2 = { method: "post" };
    return "string" == typeof e5 ? (e5 = d2(e5), t2 = b2({ port: e5.port, path: e5.pathname, host: e5.hostname, protocol: e5.protocol }, s2)) : (t2 = b2(e5, s2)).port || (t2.port = "https:" == t2.protocol ? 443 : 80), t2.headers = this.getHeaders(e5.headers), n3 = "https:" == t2.protocol ? u2.request(t2) : l2.request(t2), this.getLength(function(e6, t3) {
      if (e6 && "Unknown stream" !== e6) this._error(e6);
      else if (t3 && n3.setHeader("Content-Length", t3), this.pipe(n3), a2) {
        var s3, i2 = function(e7, t4) {
          return n3.removeListener("error", i2), n3.removeListener("response", s3), a2.call(this, e7, t4);
        };
        s3 = i2.bind(this, null), n3.on("error", i2), n3.on("response", s3);
      }
    }.bind(this)), n3;
  }, g2.prototype._error = function(e5) {
    this.error || (this.error = e5, this.pause(), this.emit("error", e5));
  }, g2.prototype.toString = function() {
    return "[object FormData]";
  }, v2(g2, "FormData"), _n;
}();
var pt = h(ct);
function lt(e5) {
  return fe.isPlainObject(e5) || fe.isArray(e5);
}
function ut(e5) {
  return fe.endsWith(e5, "[]") ? e5.slice(0, -2) : e5;
}
function dt(e5, a2, n2) {
  return e5 ? e5.concat(a2).map(function(e6, a3) {
    return e6 = ut(e6), !n2 && a3 ? "[" + e6 + "]" : e6;
  }).join(n2 ? "." : "") : a2;
}
var mt = fe.toFlatObject(fe, {}, null, function(e5) {
  return /^is[A-Z]/.test(e5);
});
function ht(e5, a2, n2) {
  if (!fe.isObject(e5)) throw new TypeError("target must be an object");
  a2 = a2 || new (pt || FormData)();
  const t2 = (n2 = fe.toFlatObject(n2, { metaTokens: true, dots: false, indexes: false }, false, function(e6, a3) {
    return !fe.isUndefined(a3[e6]);
  })).metaTokens, s2 = n2.visitor || p2, i2 = n2.dots, o2 = n2.indexes, r2 = (n2.Blob || "undefined" != typeof Blob && Blob) && fe.isSpecCompliantForm(a2);
  if (!fe.isFunction(s2)) throw new TypeError("visitor must be a function");
  function c2(e6) {
    if (null === e6) return "";
    if (fe.isDate(e6)) return e6.toISOString();
    if (!r2 && fe.isBlob(e6)) throw new xe("Blob is not supported. Use a Buffer instead.");
    return fe.isArrayBuffer(e6) || fe.isTypedArray(e6) ? r2 && "function" == typeof Blob ? new Blob([e6]) : Buffer.from(e6) : e6;
  }
  function p2(e6, n3, s3) {
    let r3 = e6;
    if (e6 && !s3 && "object" == typeof e6) {
      if (fe.endsWith(n3, "{}")) n3 = t2 ? n3 : n3.slice(0, -2), e6 = JSON.stringify(e6);
      else if (fe.isArray(e6) && function(e7) {
        return fe.isArray(e7) && !e7.some(lt);
      }(e6) || (fe.isFileList(e6) || fe.endsWith(n3, "[]")) && (r3 = fe.toArray(e6))) return n3 = ut(n3), r3.forEach(function(e7, t3) {
        !fe.isUndefined(e7) && null !== e7 && a2.append(true === o2 ? dt([n3], t3, i2) : null === o2 ? n3 : n3 + "[]", c2(e7));
      }), false;
    }
    return !!lt(e6) || (a2.append(dt(s3, n3, i2), c2(e6)), false);
  }
  const l2 = [], u2 = Object.assign(mt, { defaultVisitor: p2, convertValue: c2, isVisitable: lt });
  if (!fe.isObject(e5)) throw new TypeError("data must be an object");
  return function e6(n3, t3) {
    if (!fe.isUndefined(n3)) {
      if (-1 !== l2.indexOf(n3)) throw Error("Circular reference detected in " + t3.join("."));
      l2.push(n3), fe.forEach(n3, function(n4, i3) {
        true === (!(fe.isUndefined(n4) || null === n4) && s2.call(a2, n4, fe.isString(i3) ? i3.trim() : i3, t3, u2)) && e6(n4, t3 ? t3.concat(i3) : [i3]);
      }), l2.pop();
    }
  }(e5), a2;
}
function ft(e5) {
  const a2 = { "!": "%21", "'": "%27", "(": "%28", ")": "%29", "~": "%7E", "%20": "+", "%00": "\0" };
  return encodeURIComponent(e5).replace(/[!'()~]|%20|%00/g, function(e6) {
    return a2[e6];
  });
}
function xt(e5, a2) {
  this._pairs = [], e5 && ht(e5, this, a2);
}
var vt = xt.prototype;
function bt(e5) {
  return encodeURIComponent(e5).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]");
}
function gt(e5, a2, n2) {
  if (!a2) return e5;
  const t2 = n2 && n2.encode || bt;
  fe.isFunction(n2) && (n2 = { serialize: n2 });
  const s2 = n2 && n2.serialize;
  let i2;
  if (i2 = s2 ? s2(a2, n2) : fe.isURLSearchParams(a2) ? a2.toString() : new xt(a2, n2).toString(t2), i2) {
    const a3 = e5.indexOf("#");
    -1 !== a3 && (e5 = e5.slice(0, a3)), e5 += (-1 === e5.indexOf("?") ? "?" : "&") + i2;
  }
  return e5;
}
vt.append = function(e5, a2) {
  this._pairs.push([e5, a2]);
}, vt.toString = function(e5) {
  const a2 = e5 ? function(a3) {
    return e5.call(this, a3, ft);
  } : ft;
  return this._pairs.map(function(e6) {
    return a2(e6[0]) + "=" + a2(e6[1]);
  }, "").join("&");
};
var yt = class {
  constructor() {
    this.handlers = [];
  }
  use(e5, a2, n2) {
    return this.handlers.push({ fulfilled: e5, rejected: a2, synchronous: !!n2 && n2.synchronous, runWhen: n2 ? n2.runWhen : null }), this.handlers.length - 1;
  }
  eject(e5) {
    this.handlers[e5] && (this.handlers[e5] = null);
  }
  clear() {
    this.handlers && (this.handlers = []);
  }
  forEach(e5) {
    fe.forEach(this.handlers, function(a2) {
      null !== a2 && e5(a2);
    });
  }
};
var wt = { silentJSONParsing: true, forcedJSONParsing: true, clarifyTimeoutError: false };
var _t = { isNode: true, classes: { URLSearchParams: import_url.default.URLSearchParams, FormData: pt, Blob: "undefined" != typeof Blob && Blob || null }, protocols: ["http", "https", "file", "data"] };
var kt = "undefined" != typeof window && "undefined" != typeof document;
var jt = "object" == typeof navigator && navigator || void 0;
var Rt = kt && (!jt || ["ReactNative", "NativeScript", "NS"].indexOf(jt.product) < 0);
var St = "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope && "function" == typeof self.importScripts;
var Et = kt && window.location.href || "http://localhost";
var Tt = { ...Object.freeze({ __proto__: null, hasBrowserEnv: kt, hasStandardBrowserEnv: Rt, hasStandardBrowserWebWorkerEnv: St, navigator: jt, origin: Et }), ..._t };
function qt(e5) {
  function a2(e6, n2, t2, s2) {
    let i2 = e6[s2++];
    if ("__proto__" === i2) return true;
    const o2 = Number.isFinite(+i2), r2 = s2 >= e6.length;
    if (i2 = !i2 && fe.isArray(t2) ? t2.length : i2, r2) return fe.hasOwnProp(t2, i2) ? t2[i2] = [t2[i2], n2] : t2[i2] = n2, !o2;
    t2[i2] && fe.isObject(t2[i2]) || (t2[i2] = []);
    return a2(e6, n2, t2[i2], s2) && fe.isArray(t2[i2]) && (t2[i2] = function(e7) {
      const a3 = {}, n3 = Object.keys(e7);
      let t3;
      const s3 = n3.length;
      let i3;
      for (t3 = 0; t3 < s3; t3++) i3 = n3[t3], a3[i3] = e7[i3];
      return a3;
    }(t2[i2])), !o2;
  }
  if (fe.isFormData(e5) && fe.isFunction(e5.entries)) {
    const n2 = {};
    return fe.forEachEntry(e5, (e6, t2) => {
      a2(function(e7) {
        return fe.matchAll(/\w+|\[(\w*)]/g, e7).map((e8) => "[]" === e8[0] ? "" : e8[1] || e8[0]);
      }(e6), t2, n2, 0);
    }), n2;
  }
  return null;
}
var Ct = { transitional: wt, adapter: ["xhr", "http", "fetch"], transformRequest: [function(e5, a2) {
  const n2 = a2.getContentType() || "", t2 = n2.indexOf("application/json") > -1, s2 = fe.isObject(e5);
  s2 && fe.isHTMLForm(e5) && (e5 = new FormData(e5));
  if (fe.isFormData(e5)) return t2 ? JSON.stringify(qt(e5)) : e5;
  if (fe.isArrayBuffer(e5) || fe.isBuffer(e5) || fe.isStream(e5) || fe.isFile(e5) || fe.isBlob(e5) || fe.isReadableStream(e5)) return e5;
  if (fe.isArrayBufferView(e5)) return e5.buffer;
  if (fe.isURLSearchParams(e5)) return a2.setContentType("application/x-www-form-urlencoded;charset=utf-8", false), e5.toString();
  let i2;
  if (s2) {
    if (n2.indexOf("application/x-www-form-urlencoded") > -1) return function(e6, a3) {
      return ht(e6, new Tt.classes.URLSearchParams(), Object.assign({ visitor: function(e7, a4, n3, t3) {
        return Tt.isNode && fe.isBuffer(e7) ? (this.append(a4, e7.toString("base64")), false) : t3.defaultVisitor.apply(this, arguments);
      } }, a3));
    }(e5, this.formSerializer).toString();
    if ((i2 = fe.isFileList(e5)) || n2.indexOf("multipart/form-data") > -1) {
      const a3 = this.env && this.env.FormData;
      return ht(i2 ? { "files[]": e5 } : e5, a3 && new a3(), this.formSerializer);
    }
  }
  return s2 || t2 ? (a2.setContentType("application/json", false), function(e6, a3, n3) {
    if (fe.isString(e6)) try {
      return (a3 || JSON.parse)(e6), fe.trim(e6);
    } catch (e7) {
      if ("SyntaxError" !== e7.name) throw e7;
    }
    return (n3 || JSON.stringify)(e6);
  }(e5)) : e5;
}], transformResponse: [function(e5) {
  const a2 = this.transitional || Ct.transitional, n2 = a2 && a2.forcedJSONParsing, t2 = "json" === this.responseType;
  if (fe.isResponse(e5) || fe.isReadableStream(e5)) return e5;
  if (e5 && fe.isString(e5) && (n2 && !this.responseType || t2)) {
    const n3 = !(a2 && a2.silentJSONParsing) && t2;
    try {
      return JSON.parse(e5);
    } catch (e6) {
      if (n3) {
        if ("SyntaxError" === e6.name) throw xe.from(e6, xe.ERR_BAD_RESPONSE, this, null, this.response);
        throw e6;
      }
    }
  }
  return e5;
}], timeout: 0, xsrfCookieName: "XSRF-TOKEN", xsrfHeaderName: "X-XSRF-TOKEN", maxContentLength: -1, maxBodyLength: -1, env: { FormData: Tt.classes.FormData, Blob: Tt.classes.Blob }, validateStatus: function(e5) {
  return e5 >= 200 && e5 < 300;
}, headers: { common: { Accept: "application/json, text/plain, */*", "Content-Type": void 0 } } };
fe.forEach(["delete", "get", "head", "post", "put", "patch"], (e5) => {
  Ct.headers[e5] = {};
});
var At = fe.toObjectSet(["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"]);
var Ot = Symbol("internals");
function Ft(e5) {
  return e5 && String(e5).trim().toLowerCase();
}
function Dt(e5) {
  return false === e5 || null == e5 ? e5 : fe.isArray(e5) ? e5.map(Dt) : String(e5);
}
function Pt(e5, a2, n2, t2, s2) {
  return fe.isFunction(t2) ? t2.call(this, a2, n2) : (s2 && (a2 = n2), fe.isString(a2) ? fe.isString(t2) ? -1 !== a2.indexOf(t2) : fe.isRegExp(t2) ? t2.test(a2) : void 0 : void 0);
}
var Bt = class {
  constructor(e5) {
    e5 && this.set(e5);
  }
  set(e5, a2, n2) {
    const t2 = this;
    function s2(e6, a3, n3) {
      const s3 = Ft(a3);
      if (!s3) throw new Error("header name must be a non-empty string");
      const i3 = fe.findKey(t2, s3);
      (!i3 || void 0 === t2[i3] || true === n3 || void 0 === n3 && false !== t2[i3]) && (t2[i3 || a3] = Dt(e6));
    }
    const i2 = (e6, a3) => fe.forEach(e6, (e7, n3) => s2(e7, n3, a3));
    if (fe.isPlainObject(e5) || e5 instanceof this.constructor) i2(e5, a2);
    else if (fe.isString(e5) && (e5 = e5.trim()) && !/^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(e5.trim())) i2(((e6) => {
      const a3 = {};
      let n3, t3, s3;
      return e6 && e6.split("\n").forEach(function(e7) {
        s3 = e7.indexOf(":"), n3 = e7.substring(0, s3).trim().toLowerCase(), t3 = e7.substring(s3 + 1).trim(), !n3 || a3[n3] && At[n3] || ("set-cookie" === n3 ? a3[n3] ? a3[n3].push(t3) : a3[n3] = [t3] : a3[n3] = a3[n3] ? a3[n3] + ", " + t3 : t3);
      }), a3;
    })(e5), a2);
    else if (fe.isHeaders(e5)) for (const [a3, t3] of e5.entries()) s2(t3, a3, n2);
    else null != e5 && s2(a2, e5, n2);
    return this;
  }
  get(e5, a2) {
    if (e5 = Ft(e5)) {
      const n2 = fe.findKey(this, e5);
      if (n2) {
        const e6 = this[n2];
        if (!a2) return e6;
        if (true === a2) return function(e7) {
          const a3 = /* @__PURE__ */ Object.create(null), n3 = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
          let t2;
          for (; t2 = n3.exec(e7); ) a3[t2[1]] = t2[2];
          return a3;
        }(e6);
        if (fe.isFunction(a2)) return a2.call(this, e6, n2);
        if (fe.isRegExp(a2)) return a2.exec(e6);
        throw new TypeError("parser must be boolean|regexp|function");
      }
    }
  }
  has(e5, a2) {
    if (e5 = Ft(e5)) {
      const n2 = fe.findKey(this, e5);
      return !(!n2 || void 0 === this[n2] || a2 && !Pt(0, this[n2], n2, a2));
    }
    return false;
  }
  delete(e5, a2) {
    const n2 = this;
    let t2 = false;
    function s2(e6) {
      if (e6 = Ft(e6)) {
        const s3 = fe.findKey(n2, e6);
        !s3 || a2 && !Pt(0, n2[s3], s3, a2) || (delete n2[s3], t2 = true);
      }
    }
    return fe.isArray(e5) ? e5.forEach(s2) : s2(e5), t2;
  }
  clear(e5) {
    const a2 = Object.keys(this);
    let n2 = a2.length, t2 = false;
    for (; n2--; ) {
      const s2 = a2[n2];
      e5 && !Pt(0, this[s2], s2, e5, true) || (delete this[s2], t2 = true);
    }
    return t2;
  }
  normalize(e5) {
    const a2 = this, n2 = {};
    return fe.forEach(this, (t2, s2) => {
      const i2 = fe.findKey(n2, s2);
      if (i2) return a2[i2] = Dt(t2), void delete a2[s2];
      const o2 = e5 ? function(e6) {
        return e6.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (e7, a3, n3) => a3.toUpperCase() + n3);
      }(s2) : String(s2).trim();
      o2 !== s2 && delete a2[s2], a2[o2] = Dt(t2), n2[o2] = true;
    }), this;
  }
  concat(...e5) {
    return this.constructor.concat(this, ...e5);
  }
  toJSON(e5) {
    const a2 = /* @__PURE__ */ Object.create(null);
    return fe.forEach(this, (n2, t2) => {
      null != n2 && false !== n2 && (a2[t2] = e5 && fe.isArray(n2) ? n2.join(", ") : n2);
    }), a2;
  }
  [Symbol.iterator]() {
    return Object.entries(this.toJSON())[Symbol.iterator]();
  }
  toString() {
    return Object.entries(this.toJSON()).map(([e5, a2]) => e5 + ": " + a2).join("\n");
  }
  get [Symbol.toStringTag]() {
    return "AxiosHeaders";
  }
  static from(e5) {
    return e5 instanceof this ? e5 : new this(e5);
  }
  static concat(e5, ...a2) {
    const n2 = new this(e5);
    return a2.forEach((e6) => n2.set(e6)), n2;
  }
  static accessor(e5) {
    const a2 = (this[Ot] = this[Ot] = { accessors: {} }).accessors, n2 = this.prototype;
    function t2(e6) {
      const t3 = Ft(e6);
      a2[t3] || (!function(e7, a3) {
        const n3 = fe.toCamelCase(" " + a3);
        ["get", "set", "has"].forEach((t4) => {
          Object.defineProperty(e7, t4 + n3, { value: function(e8, n4, s2) {
            return this[t4].call(this, a3, e8, n4, s2);
          }, configurable: true });
        });
      }(n2, e6), a2[t3] = true);
    }
    return fe.isArray(e5) ? e5.forEach(t2) : t2(e5), this;
  }
};
function Lt(e5, a2) {
  const n2 = this || Ct, t2 = a2 || n2, s2 = Bt.from(t2.headers);
  let i2 = t2.data;
  return fe.forEach(e5, function(e6) {
    i2 = e6.call(n2, i2, s2.normalize(), a2 ? a2.status : void 0);
  }), s2.normalize(), i2;
}
function Ut(e5) {
  return !(!e5 || !e5.__CANCEL__);
}
function zt(e5, a2, n2) {
  xe.call(this, null == e5 ? "canceled" : e5, xe.ERR_CANCELED, a2, n2), this.name = "CanceledError";
}
function It(e5, a2, n2) {
  const t2 = n2.config.validateStatus;
  n2.status && t2 && !t2(n2.status) ? a2(new xe("Request failed with status code " + n2.status, [xe.ERR_BAD_REQUEST, xe.ERR_BAD_RESPONSE][Math.floor(n2.status / 100) - 4], n2.config, n2.request, n2)) : e5(n2);
}
function Nt(e5, a2) {
  return e5 && !/^([a-z][a-z\d+\-.]*:)?\/\//i.test(a2) ? function(e6, a3) {
    return a3 ? e6.replace(/\/?\/$/, "") + "/" + a3.replace(/^\/+/, "") : e6;
  }(e5, a2) : a2;
}
Bt.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent", "Authorization"]), fe.reduceDescriptors(Bt.prototype, ({ value: e5 }, a2) => {
  let n2 = a2[0].toUpperCase() + a2.slice(1);
  return { get: () => e5, set(e6) {
    this[n2] = e6;
  } };
}), fe.freezeMethods(Bt), fe.inherits(zt, xe, { __CANCEL__: true });
var Mt;
var $t = {};
var Wt;
var Ht;
var Vt;
var Gt;
var Jt;
var Kt = h(function() {
  if (Mt) return $t;
  Mt = 1;
  var e5 = import_url.default.parse, a2 = { ftp: 21, gopher: 70, http: 80, https: 443, ws: 80, wss: 443 }, n2 = String.prototype.endsWith || function(e6) {
    return e6.length <= this.length && -1 !== this.indexOf(e6, this.length - e6.length);
  };
  function t2(e6) {
    return process.env[e6.toLowerCase()] || process.env[e6.toUpperCase()] || "";
  }
  return $t.getProxyForUrl = function(s2) {
    var i2 = "string" == typeof s2 ? e5(s2) : s2 || {}, o2 = i2.protocol, r2 = i2.host, c2 = i2.port;
    if ("string" != typeof r2 || !r2 || "string" != typeof o2) return "";
    if (o2 = o2.split(":", 1)[0], !function(e6, a3) {
      var s3 = (t2("npm_config_no_proxy") || t2("no_proxy")).toLowerCase();
      if (!s3) return true;
      if ("*" === s3) return false;
      return s3.split(/[,\s]/).every(function(t3) {
        if (!t3) return true;
        var s4 = t3.match(/^(.+):(\d+)$/), i3 = s4 ? s4[1] : t3, o3 = s4 ? parseInt(s4[2]) : 0;
        return !(!o3 || o3 === a3) || (/^[.*]/.test(i3) ? ("*" === i3.charAt(0) && (i3 = i3.slice(1)), !n2.call(e6, i3)) : e6 !== i3);
      });
    }(r2 = r2.replace(/:\d*$/, ""), c2 = parseInt(c2) || a2[o2] || 0)) return "";
    var p2 = t2("npm_config_" + o2 + "_proxy") || t2(o2 + "_proxy") || t2("npm_config_proxy") || t2("all_proxy");
    return p2 && -1 === p2.indexOf("://") && (p2 = o2 + "://" + p2), p2;
  }, $t;
}());
var Qt = { exports: {} };
var Yt = { exports: {} };
var Xt = { exports: {} };
function Zt() {
  if (Ht) return Wt;
  Ht = 1;
  var e5 = 1e3, a2 = 60 * e5, n2 = 60 * a2, t2 = 24 * n2, s2 = 7 * t2, i2 = 365.25 * t2;
  function o2(e6, a3, n3, t3) {
    var s3 = a3 >= 1.5 * n3;
    return Math.round(e6 / n3) + " " + t3 + (s3 ? "s" : "");
  }
  return Wt = function(r2, c2) {
    c2 = c2 || {};
    var p2 = typeof r2;
    if ("string" === p2 && r2.length > 0) return function(o3) {
      if ((o3 = String(o3)).length > 100) return;
      var r3 = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(o3);
      if (!r3) return;
      var c3 = parseFloat(r3[1]);
      switch ((r3[2] || "ms").toLowerCase()) {
        case "years":
        case "year":
        case "yrs":
        case "yr":
        case "y":
          return c3 * i2;
        case "weeks":
        case "week":
        case "w":
          return c3 * s2;
        case "days":
        case "day":
        case "d":
          return c3 * t2;
        case "hours":
        case "hour":
        case "hrs":
        case "hr":
        case "h":
          return c3 * n2;
        case "minutes":
        case "minute":
        case "mins":
        case "min":
        case "m":
          return c3 * a2;
        case "seconds":
        case "second":
        case "secs":
        case "sec":
        case "s":
          return c3 * e5;
        case "milliseconds":
        case "millisecond":
        case "msecs":
        case "msec":
        case "ms":
          return c3;
        default:
          return;
      }
    }(r2);
    if ("number" === p2 && isFinite(r2)) return c2.long ? function(s3) {
      var i3 = Math.abs(s3);
      if (i3 >= t2) return o2(s3, i3, t2, "day");
      if (i3 >= n2) return o2(s3, i3, n2, "hour");
      if (i3 >= a2) return o2(s3, i3, a2, "minute");
      if (i3 >= e5) return o2(s3, i3, e5, "second");
      return s3 + " ms";
    }(r2) : function(s3) {
      var i3 = Math.abs(s3);
      if (i3 >= t2) return Math.round(s3 / t2) + "d";
      if (i3 >= n2) return Math.round(s3 / n2) + "h";
      if (i3 >= a2) return Math.round(s3 / a2) + "m";
      if (i3 >= e5) return Math.round(s3 / e5) + "s";
      return s3 + "ms";
    }(r2);
    throw new Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(r2));
  }, Wt;
}
function es() {
  if (Gt) return Vt;
  return Gt = 1, Vt = function(e5) {
    function a2(e6) {
      let t3, s2, i2, o2 = null;
      function r2(...e7) {
        if (!r2.enabled) return;
        const n3 = r2, s3 = Number(/* @__PURE__ */ new Date()), i3 = s3 - (t3 || s3);
        n3.diff = i3, n3.prev = t3, n3.curr = s3, t3 = s3, e7[0] = a2.coerce(e7[0]), "string" != typeof e7[0] && e7.unshift("%O");
        let o3 = 0;
        e7[0] = e7[0].replace(/%([a-zA-Z%])/g, (t4, s4) => {
          if ("%%" === t4) return "%";
          o3++;
          const i4 = a2.formatters[s4];
          if ("function" == typeof i4) {
            const a3 = e7[o3];
            t4 = i4.call(n3, a3), e7.splice(o3, 1), o3--;
          }
          return t4;
        }), a2.formatArgs.call(n3, e7);
        (n3.log || a2.log).apply(n3, e7);
      }
      return r2.namespace = e6, r2.useColors = a2.useColors(), r2.color = a2.selectColor(e6), r2.extend = n2, r2.destroy = a2.destroy, Object.defineProperty(r2, "enabled", { enumerable: true, configurable: false, get: () => null !== o2 ? o2 : (s2 !== a2.namespaces && (s2 = a2.namespaces, i2 = a2.enabled(e6)), i2), set: (e7) => {
        o2 = e7;
      } }), "function" == typeof a2.init && a2.init(r2), r2;
    }
    function n2(e6, n3) {
      const t3 = a2(this.namespace + (void 0 === n3 ? ":" : n3) + e6);
      return t3.log = this.log, t3;
    }
    function t2(e6, a3) {
      let n3 = 0, t3 = 0, s2 = -1, i2 = 0;
      for (; n3 < e6.length; ) if (t3 < a3.length && (a3[t3] === e6[n3] || "*" === a3[t3])) "*" === a3[t3] ? (s2 = t3, i2 = n3, t3++) : (n3++, t3++);
      else {
        if (-1 === s2) return false;
        t3 = s2 + 1, i2++, n3 = i2;
      }
      for (; t3 < a3.length && "*" === a3[t3]; ) t3++;
      return t3 === a3.length;
    }
    return a2.debug = a2, a2.default = a2, a2.coerce = function(e6) {
      if (e6 instanceof Error) return e6.stack || e6.message;
      return e6;
    }, a2.disable = function() {
      const e6 = [...a2.names, ...a2.skips.map((e7) => "-" + e7)].join(",");
      return a2.enable(""), e6;
    }, a2.enable = function(e6) {
      a2.save(e6), a2.namespaces = e6, a2.names = [], a2.skips = [];
      const n3 = ("string" == typeof e6 ? e6 : "").trim().replace(" ", ",").split(",").filter(Boolean);
      for (const e7 of n3) "-" === e7[0] ? a2.skips.push(e7.slice(1)) : a2.names.push(e7);
    }, a2.enabled = function(e6) {
      for (const n3 of a2.skips) if (t2(e6, n3)) return false;
      for (const n3 of a2.names) if (t2(e6, n3)) return true;
      return false;
    }, a2.humanize = Zt(), a2.destroy = function() {
      console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
    }, Object.keys(e5).forEach((n3) => {
      a2[n3] = e5[n3];
    }), a2.names = [], a2.skips = [], a2.formatters = {}, a2.selectColor = function(e6) {
      let n3 = 0;
      for (let a3 = 0; a3 < e6.length; a3++) n3 = (n3 << 5) - n3 + e6.charCodeAt(a3), n3 |= 0;
      return a2.colors[Math.abs(n3) % a2.colors.length];
    }, a2.enable(a2.load()), a2;
  }, Vt;
}
var as;
var ns;
var ts;
var ss;
var is;
var os;
var rs;
var cs;
var ps;
var ls = { exports: {} };
function us() {
  return ns ? as : (ns = 1, as = (e5, a2 = process.argv) => {
    const n2 = e5.startsWith("-") ? "" : 1 === e5.length ? "-" : "--", t2 = a2.indexOf(n2 + e5), s2 = a2.indexOf("--");
    return -1 !== t2 && (-1 === s2 || t2 < s2);
  });
}
function ds() {
  return is || (is = 1, function(a2, n2) {
    const t2 = import_tty.default, s2 = import_util.default;
    n2.init = function(e5) {
      e5.inspectOpts = {};
      const a3 = Object.keys(n2.inspectOpts);
      for (let t3 = 0; t3 < a3.length; t3++) e5.inspectOpts[a3[t3]] = n2.inspectOpts[a3[t3]];
    }, n2.log = function(...e5) {
      return process.stderr.write(s2.formatWithOptions(n2.inspectOpts, ...e5) + "\n");
    }, n2.formatArgs = function(e5) {
      const { namespace: t3, useColors: s3 } = this;
      if (s3) {
        const n3 = this.color, s4 = "\x1B[3" + (n3 < 8 ? n3 : "8;5;" + n3), i3 = `  ${s4};1m${t3} \x1B[0m`;
        e5[0] = i3 + e5[0].split("\n").join("\n" + i3), e5.push(s4 + "m+" + a2.exports.humanize(this.diff) + "\x1B[0m");
      } else e5[0] = function() {
        if (n2.inspectOpts.hideDate) return "";
        return (/* @__PURE__ */ new Date()).toISOString() + " ";
      }() + t3 + " " + e5[0];
    }, n2.save = function(e5) {
      e5 ? process.env.DEBUG = e5 : delete process.env.DEBUG;
    }, n2.load = function() {
      return process.env.DEBUG;
    }, n2.useColors = function() {
      return "colors" in n2.inspectOpts ? Boolean(n2.inspectOpts.colors) : t2.isatty(process.stderr.fd);
    }, n2.destroy = s2.deprecate(() => {
    }, "Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."), n2.colors = [6, 2, 3, 4, 5, 1];
    try {
      const e5 = function() {
        if (ss) return ts;
        ss = 1;
        const e6 = import_os.default, a3 = import_tty.default, n3 = us(), { env: t3 } = process;
        let s3;
        function i3(e7) {
          return 0 !== e7 && { level: e7, hasBasic: true, has256: e7 >= 2, has16m: e7 >= 3 };
        }
        function o2(a4, i4) {
          if (0 === s3) return 0;
          if (n3("color=16m") || n3("color=full") || n3("color=truecolor")) return 3;
          if (n3("color=256")) return 2;
          if (a4 && !i4 && void 0 === s3) return 0;
          const o3 = s3 || 0;
          if ("dumb" === t3.TERM) return o3;
          if ("win32" === process.platform) {
            const a5 = e6.release().split(".");
            return Number(a5[0]) >= 10 && Number(a5[2]) >= 10586 ? Number(a5[2]) >= 14931 ? 3 : 2 : 1;
          }
          if ("CI" in t3) return ["TRAVIS", "CIRCLECI", "APPVEYOR", "GITLAB_CI", "GITHUB_ACTIONS", "BUILDKITE"].some((e7) => e7 in t3) || "codeship" === t3.CI_NAME ? 1 : o3;
          if ("TEAMCITY_VERSION" in t3) return /^(9\.(0*[1-9]\d*)\.|\d{2,}\.)/.test(t3.TEAMCITY_VERSION) ? 1 : 0;
          if ("truecolor" === t3.COLORTERM) return 3;
          if ("TERM_PROGRAM" in t3) {
            const e7 = parseInt((t3.TERM_PROGRAM_VERSION || "").split(".")[0], 10);
            switch (t3.TERM_PROGRAM) {
              case "iTerm.app":
                return e7 >= 3 ? 3 : 2;
              case "Apple_Terminal":
                return 2;
            }
          }
          return /-256(color)?$/i.test(t3.TERM) ? 2 : /^screen|^xterm|^vt100|^vt220|^rxvt|color|ansi|cygwin|linux/i.test(t3.TERM) || "COLORTERM" in t3 ? 1 : o3;
        }
        return n3("no-color") || n3("no-colors") || n3("color=false") || n3("color=never") ? s3 = 0 : (n3("color") || n3("colors") || n3("color=true") || n3("color=always")) && (s3 = 1), "FORCE_COLOR" in t3 && (s3 = "true" === t3.FORCE_COLOR ? 1 : "false" === t3.FORCE_COLOR ? 0 : 0 === t3.FORCE_COLOR.length ? 1 : Math.min(parseInt(t3.FORCE_COLOR, 10), 3)), ts = { supportsColor: function(e7) {
          return i3(o2(e7, e7 && e7.isTTY));
        }, stdout: i3(o2(true, a3.isatty(1))), stderr: i3(o2(true, a3.isatty(2))) }, ts;
      }();
      e5 && (e5.stderr || e5).level >= 2 && (n2.colors = [20, 21, 26, 27, 32, 33, 38, 39, 40, 41, 42, 43, 44, 45, 56, 57, 62, 63, 68, 69, 74, 75, 76, 77, 78, 79, 80, 81, 92, 93, 98, 99, 112, 113, 128, 129, 134, 135, 148, 149, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 178, 179, 184, 185, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 214, 215, 220, 221]);
    } catch (e5) {
    }
    n2.inspectOpts = Object.keys(process.env).filter((e5) => /^debug_/i.test(e5)).reduce((e5, a3) => {
      const n3 = a3.substring(6).toLowerCase().replace(/_([a-z])/g, (e6, a4) => a4.toUpperCase());
      let t3 = process.env[a3];
      return t3 = !!/^(yes|on|true|enabled)$/i.test(t3) || !/^(no|off|false|disabled)$/i.test(t3) && ("null" === t3 ? null : Number(t3)), e5[n3] = t3, e5;
    }, {}), a2.exports = es()(n2);
    const { formatters: i2 } = a2.exports;
    i2.o = function(e5) {
      return this.inspectOpts.colors = this.useColors, s2.inspect(e5, this.inspectOpts).split("\n").map((e6) => e6.trim()).join(" ");
    }, i2.O = function(e5) {
      return this.inspectOpts.colors = this.useColors, s2.inspect(e5, this.inspectOpts);
    };
  }(ls, ls.exports)), ls.exports;
}
function ms() {
  return os || (os = 1, "undefined" == typeof process || "renderer" === process.type || true === process.browser || process.__nwjs ? Yt.exports = (Jt || (Jt = 1, function(e5, a2) {
    a2.formatArgs = function(a3) {
      if (a3[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + a3[0] + (this.useColors ? "%c " : " ") + "+" + e5.exports.humanize(this.diff), !this.useColors) return;
      const n3 = "color: " + this.color;
      a3.splice(1, 0, n3, "color: inherit");
      let t2 = 0, s2 = 0;
      a3[0].replace(/%[a-zA-Z%]/g, (e6) => {
        "%%" !== e6 && (t2++, "%c" === e6 && (s2 = t2));
      }), a3.splice(s2, 0, n3);
    }, a2.save = function(e6) {
      try {
        e6 ? a2.storage.setItem("debug", e6) : a2.storage.removeItem("debug");
      } catch (e7) {
      }
    }, a2.load = function() {
      let e6;
      try {
        e6 = a2.storage.getItem("debug");
      } catch (e7) {
      }
      return !e6 && "undefined" != typeof process && "env" in process && (e6 = process.env.DEBUG), e6;
    }, a2.useColors = function() {
      if ("undefined" != typeof window && window.process && ("renderer" === window.process.type || window.process.__nwjs)) return true;
      if ("undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) return false;
      let e6;
      return "undefined" != typeof document && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || "undefined" != typeof window && window.console && (window.console.firebug || window.console.exception && window.console.table) || "undefined" != typeof navigator && navigator.userAgent && (e6 = navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)) && parseInt(e6[1], 10) >= 31 || "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/);
    }, a2.storage = function() {
      try {
        return localStorage;
      } catch (e6) {
      }
    }(), a2.destroy = /* @__PURE__ */ (() => {
      let e6 = false;
      return () => {
        e6 || (e6 = true, console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."));
      };
    })(), a2.colors = ["#0000CC", "#0000FF", "#0033CC", "#0033FF", "#0066CC", "#0066FF", "#0099CC", "#0099FF", "#00CC00", "#00CC33", "#00CC66", "#00CC99", "#00CCCC", "#00CCFF", "#3300CC", "#3300FF", "#3333CC", "#3333FF", "#3366CC", "#3366FF", "#3399CC", "#3399FF", "#33CC00", "#33CC33", "#33CC66", "#33CC99", "#33CCCC", "#33CCFF", "#6600CC", "#6600FF", "#6633CC", "#6633FF", "#66CC00", "#66CC33", "#9900CC", "#9900FF", "#9933CC", "#9933FF", "#99CC00", "#99CC33", "#CC0000", "#CC0033", "#CC0066", "#CC0099", "#CC00CC", "#CC00FF", "#CC3300", "#CC3333", "#CC3366", "#CC3399", "#CC33CC", "#CC33FF", "#CC6600", "#CC6633", "#CC9900", "#CC9933", "#CCCC00", "#CCCC33", "#FF0000", "#FF0033", "#FF0066", "#FF0099", "#FF00CC", "#FF00FF", "#FF3300", "#FF3333", "#FF3366", "#FF3399", "#FF33CC", "#FF33FF", "#FF6600", "#FF6633", "#FF9900", "#FF9933", "#FFCC00", "#FFCC33"], a2.log = console.debug || console.log || (() => {
    }), e5.exports = es()(a2);
    const { formatters: n2 } = e5.exports;
    n2.j = function(e6) {
      try {
        return JSON.stringify(e6);
      } catch (e7) {
        return "[UnexpectedJSONParseError]: " + e7.message;
      }
    };
  }(Xt, Xt.exports)), Xt.exports) : Yt.exports = ds()), Yt.exports;
}
var hs = function() {
  if (ps) return Qt.exports;
  ps = 1;
  var e5, n2, t2, r2 = import_url.default, p2 = r2.URL, l2 = import_http.default, u2 = import_https.default, d2 = import_stream.default.Writable, m2 = import_assert.default, h2 = function() {
    return cs || (cs = 1, rs = function() {
      if (!e6) {
        try {
          e6 = ms()("follow-redirects");
        } catch (e7) {
        }
        "function" != typeof e6 && (e6 = function() {
        });
      }
      e6.apply(null, arguments);
    }), rs;
    var e6;
  }();
  e5 = "undefined" != typeof process, n2 = "undefined" != typeof window && "undefined" != typeof document, t2 = P2(Error.captureStackTrace), e5 || !n2 && t2 || console.warn("The follow-redirects package should be excluded from browser builds.");
  var f2 = false;
  try {
    m2(new p2(""));
  } catch (e6) {
    f2 = "ERR_INVALID_URL" === e6.code;
  }
  var x2 = ["auth", "host", "hostname", "href", "path", "pathname", "port", "protocol", "query", "search", "hash"], v2 = ["abort", "aborted", "connect", "error", "socket", "timeout"], b2 = /* @__PURE__ */ Object.create(null);
  v2.forEach(function(e6) {
    b2[e6] = function(a2, n3, t3) {
      this._redirectable.emit(e6, a2, n3, t3);
    };
  });
  var g2 = O2("ERR_INVALID_URL", "Invalid URL", TypeError), y2 = O2("ERR_FR_REDIRECTION_FAILURE", "Redirected request failed"), w2 = O2("ERR_FR_TOO_MANY_REDIRECTS", "Maximum number of redirects exceeded", y2), _2 = O2("ERR_FR_MAX_BODY_LENGTH_EXCEEDED", "Request body larger than maxBodyLength limit"), k2 = O2("ERR_STREAM_WRITE_AFTER_END", "write after end"), j2 = d2.prototype.destroy || E2;
  function R2(e6, a2) {
    d2.call(this), this._sanitizeOptions(e6), this._options = e6, this._ended = false, this._ending = false, this._redirectCount = 0, this._redirects = [], this._requestBodyLength = 0, this._requestBodyBuffers = [], a2 && this.on("response", a2);
    var n3 = this;
    this._onNativeResponse = function(e7) {
      try {
        n3._processResponse(e7);
      } catch (e8) {
        n3.emit("error", e8 instanceof y2 ? e8 : new y2({ cause: e8 }));
      }
    }, this._performRequest();
  }
  function S2(e6) {
    var a2 = { maxRedirects: 21, maxBodyLength: 10485760 }, n3 = {};
    return Object.keys(e6).forEach(function(t3) {
      var s2 = t3 + ":", i2 = n3[s2] = e6[t3], o2 = a2[t3] = Object.create(i2);
      Object.defineProperties(o2, { request: { value: function(e7, t4, i3) {
        var o3;
        return o3 = e7, p2 && o3 instanceof p2 ? e7 = C2(e7) : D2(e7) ? e7 = C2(T2(e7)) : (i3 = t4, t4 = q2(e7), e7 = { protocol: s2 }), P2(t4) && (i3 = t4, t4 = null), (t4 = Object.assign({ maxRedirects: a2.maxRedirects, maxBodyLength: a2.maxBodyLength }, e7, t4)).nativeProtocols = n3, D2(t4.host) || D2(t4.hostname) || (t4.hostname = "::1"), m2.equal(t4.protocol, s2, "protocol mismatch"), h2("options", t4), new R2(t4, i3);
      }, configurable: true, enumerable: true, writable: true }, get: { value: function(e7, a3, n4) {
        var t4 = o2.request(e7, a3, n4);
        return t4.end(), t4;
      }, configurable: true, enumerable: true, writable: true } });
    }), a2;
  }
  function E2() {
  }
  function T2(e6) {
    var a2;
    if (f2) a2 = new p2(e6);
    else if (!D2((a2 = q2(r2.parse(e6))).protocol)) throw new g2({ input: e6 });
    return a2;
  }
  function q2(e6) {
    if (/^\[/.test(e6.hostname) && !/^\[[:0-9a-f]+\]$/i.test(e6.hostname)) throw new g2({ input: e6.href || e6 });
    if (/^\[/.test(e6.host) && !/^\[[:0-9a-f]+\](:\d+)?$/i.test(e6.host)) throw new g2({ input: e6.href || e6 });
    return e6;
  }
  function C2(e6, a2) {
    var n3 = a2 || {};
    for (var t3 of x2) n3[t3] = e6[t3];
    return n3.hostname.startsWith("[") && (n3.hostname = n3.hostname.slice(1, -1)), "" !== n3.port && (n3.port = Number(n3.port)), n3.path = n3.search ? n3.pathname + n3.search : n3.pathname, n3;
  }
  function A2(e6, a2) {
    var n3;
    for (var t3 in a2) e6.test(t3) && (n3 = a2[t3], delete a2[t3]);
    return null == n3 ? void 0 : String(n3).trim();
  }
  function O2(e6, a2, n3) {
    function t3(n4) {
      P2(Error.captureStackTrace) && Error.captureStackTrace(this, this.constructor), Object.assign(this, n4 || {}), this.code = e6, this.message = this.cause ? a2 + ": " + this.cause.message : a2;
    }
    return t3.prototype = new (n3 || Error)(), Object.defineProperties(t3.prototype, { constructor: { value: t3, enumerable: false }, name: { value: "Error [" + e6 + "]", enumerable: false } }), t3;
  }
  function F2(e6, a2) {
    for (var n3 of v2) e6.removeListener(n3, b2[n3]);
    e6.on("error", E2), e6.destroy(a2);
  }
  function D2(e6) {
    return "string" == typeof e6 || e6 instanceof String;
  }
  function P2(e6) {
    return "function" == typeof e6;
  }
  return R2.prototype = Object.create(d2.prototype), R2.prototype.abort = function() {
    F2(this._currentRequest), this._currentRequest.abort(), this.emit("abort");
  }, R2.prototype.destroy = function(e6) {
    return F2(this._currentRequest, e6), j2.call(this, e6), this;
  }, R2.prototype.write = function(e6, a2, n3) {
    if (this._ending) throw new k2();
    if (!D2(e6) && ("object" != typeof (t3 = e6) || !("length" in t3))) throw new TypeError("data should be a string, Buffer or Uint8Array");
    var t3;
    P2(a2) && (n3 = a2, a2 = null), 0 !== e6.length ? this._requestBodyLength + e6.length <= this._options.maxBodyLength ? (this._requestBodyLength += e6.length, this._requestBodyBuffers.push({ data: e6, encoding: a2 }), this._currentRequest.write(e6, a2, n3)) : (this.emit("error", new _2()), this.abort()) : n3 && n3();
  }, R2.prototype.end = function(e6, a2, n3) {
    if (P2(e6) ? (n3 = e6, e6 = a2 = null) : P2(a2) && (n3 = a2, a2 = null), e6) {
      var t3 = this, s2 = this._currentRequest;
      this.write(e6, a2, function() {
        t3._ended = true, s2.end(null, null, n3);
      }), this._ending = true;
    } else this._ended = this._ending = true, this._currentRequest.end(null, null, n3);
  }, R2.prototype.setHeader = function(e6, a2) {
    this._options.headers[e6] = a2, this._currentRequest.setHeader(e6, a2);
  }, R2.prototype.removeHeader = function(e6) {
    delete this._options.headers[e6], this._currentRequest.removeHeader(e6);
  }, R2.prototype.setTimeout = function(e6, a2) {
    var n3 = this;
    function t3(a3) {
      a3.setTimeout(e6), a3.removeListener("timeout", a3.destroy), a3.addListener("timeout", a3.destroy);
    }
    function s2(a3) {
      n3._timeout && clearTimeout(n3._timeout), n3._timeout = setTimeout(function() {
        n3.emit("timeout"), i2();
      }, e6), t3(a3);
    }
    function i2() {
      n3._timeout && (clearTimeout(n3._timeout), n3._timeout = null), n3.removeListener("abort", i2), n3.removeListener("error", i2), n3.removeListener("response", i2), n3.removeListener("close", i2), a2 && n3.removeListener("timeout", a2), n3.socket || n3._currentRequest.removeListener("socket", s2);
    }
    return a2 && this.on("timeout", a2), this.socket ? s2(this.socket) : this._currentRequest.once("socket", s2), this.on("socket", t3), this.on("abort", i2), this.on("error", i2), this.on("response", i2), this.on("close", i2), this;
  }, ["flushHeaders", "getHeader", "setNoDelay", "setSocketKeepAlive"].forEach(function(e6) {
    R2.prototype[e6] = function(a2, n3) {
      return this._currentRequest[e6](a2, n3);
    };
  }), ["aborted", "connection", "socket"].forEach(function(e6) {
    Object.defineProperty(R2.prototype, e6, { get: function() {
      return this._currentRequest[e6];
    } });
  }), R2.prototype._sanitizeOptions = function(e6) {
    if (e6.headers || (e6.headers = {}), e6.host && (e6.hostname || (e6.hostname = e6.host), delete e6.host), !e6.pathname && e6.path) {
      var a2 = e6.path.indexOf("?");
      a2 < 0 ? e6.pathname = e6.path : (e6.pathname = e6.path.substring(0, a2), e6.search = e6.path.substring(a2));
    }
  }, R2.prototype._performRequest = function() {
    var e6 = this._options.protocol, a2 = this._options.nativeProtocols[e6];
    if (!a2) throw new TypeError("Unsupported protocol " + e6);
    if (this._options.agents) {
      var n3 = e6.slice(0, -1);
      this._options.agent = this._options.agents[n3];
    }
    var t3 = this._currentRequest = a2.request(this._options, this._onNativeResponse);
    for (var s2 of (t3._redirectable = this, v2)) t3.on(s2, b2[s2]);
    if (this._currentUrl = /^\//.test(this._options.path) ? r2.format(this._options) : this._options.path, this._isRedirect) {
      var i2 = 0, o2 = this, c2 = this._requestBodyBuffers;
      !function e7(a3) {
        if (t3 === o2._currentRequest) if (a3) o2.emit("error", a3);
        else if (i2 < c2.length) {
          var n4 = c2[i2++];
          t3.finished || t3.write(n4.data, n4.encoding, e7);
        } else o2._ended && t3.end();
      }();
    }
  }, R2.prototype._processResponse = function(e6) {
    var a2 = e6.statusCode;
    this._options.trackRedirects && this._redirects.push({ url: this._currentUrl, headers: e6.headers, statusCode: a2 });
    var n3, t3 = e6.headers.location;
    if (!t3 || false === this._options.followRedirects || a2 < 300 || a2 >= 400) return e6.responseUrl = this._currentUrl, e6.redirects = this._redirects, this.emit("response", e6), void (this._requestBodyBuffers = []);
    if (F2(this._currentRequest), e6.destroy(), ++this._redirectCount > this._options.maxRedirects) throw new w2();
    var s2 = this._options.beforeRedirect;
    s2 && (n3 = Object.assign({ Host: e6.req.getHeader("host") }, this._options.headers));
    var i2 = this._options.method;
    ((301 === a2 || 302 === a2) && "POST" === this._options.method || 303 === a2 && !/^(?:GET|HEAD)$/.test(this._options.method)) && (this._options.method = "GET", this._requestBodyBuffers = [], A2(/^content-/i, this._options.headers));
    var o2, c2, l3 = A2(/^host$/i, this._options.headers), u3 = T2(this._currentUrl), d3 = l3 || u3.host, x3 = /^\w+:/.test(t3) ? this._currentUrl : r2.format(Object.assign(u3, { host: d3 })), v3 = (o2 = t3, c2 = x3, f2 ? new p2(o2, c2) : T2(r2.resolve(c2, o2)));
    if (h2("redirecting to", v3.href), this._isRedirect = true, C2(v3, this._options), (v3.protocol !== u3.protocol && "https:" !== v3.protocol || v3.host !== d3 && !function(e7, a3) {
      m2(D2(e7) && D2(a3));
      var n4 = e7.length - a3.length - 1;
      return n4 > 0 && "." === e7[n4] && e7.endsWith(a3);
    }(v3.host, d3)) && A2(/^(?:(?:proxy-)?authorization|cookie)$/i, this._options.headers), P2(s2)) {
      var b3 = { headers: e6.headers, statusCode: a2 }, g3 = { url: x3, method: i2, headers: n3 };
      s2(this._options, b3, g3), this._sanitizeOptions(this._options);
    }
    this._performRequest();
  }, Qt.exports = S2({ http: l2, https: u2 }), Qt.exports.wrap = S2, Qt.exports;
}();
var fs = h(hs);
var xs = "1.7.9";
function vs(e5) {
  const a2 = /^([-+\w]{1,25})(:?\/\/|:)/.exec(e5);
  return a2 && a2[1] || "";
}
var bs = /^(?:([^;]+);)?(?:[^;]+;)?(base64|),([\s\S]*)$/;
var gs = Symbol("internals");
var ys = class extends import_stream.default.Transform {
  constructor(e5) {
    super({ readableHighWaterMark: (e5 = fe.toFlatObject(e5, { maxRate: 0, chunkSize: 65536, minChunkSize: 100, timeWindow: 500, ticksRate: 2, samplesCount: 15 }, null, (e6, a3) => !fe.isUndefined(a3[e6]))).chunkSize });
    const a2 = this[gs] = { timeWindow: e5.timeWindow, chunkSize: e5.chunkSize, maxRate: e5.maxRate, minChunkSize: e5.minChunkSize, bytesSeen: 0, isCaptured: false, notifiedBytesLoaded: 0, ts: Date.now(), bytes: 0, onReadCallback: null };
    this.on("newListener", (e6) => {
      "progress" === e6 && (a2.isCaptured || (a2.isCaptured = true));
    });
  }
  _read(e5) {
    const a2 = this[gs];
    return a2.onReadCallback && a2.onReadCallback(), super._read(e5);
  }
  _transform(e5, a2, n2) {
    const t2 = this[gs], s2 = t2.maxRate, i2 = this.readableHighWaterMark, o2 = t2.timeWindow, r2 = s2 / (1e3 / o2), c2 = false !== t2.minChunkSize ? Math.max(t2.minChunkSize, 0.01 * r2) : 0, p2 = (e6, a3) => {
      const n3 = Buffer.byteLength(e6);
      t2.bytesSeen += n3, t2.bytes += n3, t2.isCaptured && this.emit("progress", t2.bytesSeen), this.push(e6) ? process.nextTick(a3) : t2.onReadCallback = () => {
        t2.onReadCallback = null, process.nextTick(a3);
      };
    }, l2 = (e6, a3) => {
      const n3 = Buffer.byteLength(e6);
      let l3, u2 = null, d2 = i2, m2 = 0;
      if (s2) {
        const e7 = Date.now();
        (!t2.ts || (m2 = e7 - t2.ts) >= o2) && (t2.ts = e7, l3 = r2 - t2.bytes, t2.bytes = l3 < 0 ? -l3 : 0, m2 = 0), l3 = r2 - t2.bytes;
      }
      if (s2) {
        if (l3 <= 0) return setTimeout(() => {
          a3(null, e6);
        }, o2 - m2);
        l3 < d2 && (d2 = l3);
      }
      d2 && n3 > d2 && n3 - d2 > c2 && (u2 = e6.subarray(d2), e6 = e6.subarray(0, d2)), p2(e6, u2 ? () => {
        process.nextTick(a3, null, u2);
      } : a3);
    };
    l2(e5, function e6(a3, t3) {
      if (a3) return n2(a3);
      t3 ? l2(t3, e6) : n2(null);
    });
  }
};
var { asyncIterator: ws } = Symbol;
var _s = async function* (e5) {
  e5.stream ? yield* e5.stream() : e5.arrayBuffer ? yield await e5.arrayBuffer() : e5[ws] ? yield* e5[ws]() : yield e5;
};
var ks = fe.ALPHABET.ALPHA_DIGIT + "-_";
var js = "function" == typeof TextEncoder ? new TextEncoder() : new import_util.default.TextEncoder();
var Rs = "\r\n";
var Ss = js.encode(Rs);
var Es = class {
  constructor(e5, a2) {
    const { escapeName: n2 } = this.constructor, t2 = fe.isString(a2);
    let s2 = `Content-Disposition: form-data; name="${n2(e5)}"${!t2 && a2.name ? `; filename="${n2(a2.name)}"` : ""}${Rs}`;
    t2 ? a2 = js.encode(String(a2).replace(/\r?\n|\r\n?/g, Rs)) : s2 += `Content-Type: ${a2.type || "application/octet-stream"}${Rs}`, this.headers = js.encode(s2 + Rs), this.contentLength = t2 ? a2.byteLength : a2.size, this.size = this.headers.byteLength + this.contentLength + 2, this.name = e5, this.value = a2;
  }
  async *encode() {
    yield this.headers;
    const { value: e5 } = this;
    fe.isTypedArray(e5) ? yield e5 : yield* _s(e5), yield Ss;
  }
  static escapeName(e5) {
    return String(e5).replace(/[\r\n"]/g, (e6) => ({ "\r": "%0D", "\n": "%0A", '"': "%22" })[e6]);
  }
};
var Ts = class extends import_stream.default.Transform {
  __transform(e5, a2, n2) {
    this.push(e5), n2();
  }
  _transform(e5, a2, n2) {
    if (0 !== e5.length && (this._transform = this.__transform, 120 !== e5[0])) {
      const e6 = Buffer.alloc(2);
      e6[0] = 120, e6[1] = 156, this.push(e6, a2);
    }
    this.__transform(e5, a2, n2);
  }
};
var qs = (e5, a2) => fe.isAsyncFn(e5) ? function(...n2) {
  const t2 = n2.pop();
  e5.apply(this, n2).then((e6) => {
    try {
      a2 ? t2(null, ...a2(e6)) : t2(null, e6);
    } catch (e7) {
      t2(e7);
    }
  }, t2);
} : e5;
var Cs = (e5, a2, n2 = 3) => {
  let t2 = 0;
  const s2 = function(e6, a3) {
    e6 = e6 || 10;
    const n3 = new Array(e6), t3 = new Array(e6);
    let s3, i2 = 0, o2 = 0;
    return a3 = void 0 !== a3 ? a3 : 1e3, function(r2) {
      const c2 = Date.now(), p2 = t3[o2];
      s3 || (s3 = c2), n3[i2] = r2, t3[i2] = c2;
      let l2 = o2, u2 = 0;
      for (; l2 !== i2; ) u2 += n3[l2++], l2 %= e6;
      if (i2 = (i2 + 1) % e6, i2 === o2 && (o2 = (o2 + 1) % e6), c2 - s3 < a3) return;
      const d2 = p2 && c2 - p2;
      return d2 ? Math.round(1e3 * u2 / d2) : void 0;
    };
  }(50, 250);
  return function(e6, a3) {
    let n3, t3, s3 = 0, i2 = 1e3 / a3;
    const o2 = (a4, i3 = Date.now()) => {
      s3 = i3, n3 = null, t3 && (clearTimeout(t3), t3 = null), e6.apply(null, a4);
    };
    return [(...e7) => {
      const a4 = Date.now(), r2 = a4 - s3;
      r2 >= i2 ? o2(e7, a4) : (n3 = e7, t3 || (t3 = setTimeout(() => {
        t3 = null, o2(n3);
      }, i2 - r2)));
    }, () => n3 && o2(n3)];
  }((n3) => {
    const i2 = n3.loaded, o2 = n3.lengthComputable ? n3.total : void 0, r2 = i2 - t2, c2 = s2(r2);
    t2 = i2;
    e5({ loaded: i2, total: o2, progress: o2 ? i2 / o2 : void 0, bytes: r2, rate: c2 || void 0, estimated: c2 && o2 && i2 <= o2 ? (o2 - i2) / c2 : void 0, event: n3, lengthComputable: null != o2, [a2 ? "download" : "upload"]: true });
  }, n2);
};
var As = (e5, a2) => {
  const n2 = null != e5;
  return [(t2) => a2[0]({ lengthComputable: n2, total: e5, loaded: t2 }), a2[1]];
};
var Os = (e5) => (...a2) => fe.asap(() => e5(...a2));
var Fs = { flush: import_zlib.default.constants.Z_SYNC_FLUSH, finishFlush: import_zlib.default.constants.Z_SYNC_FLUSH };
var Ds = { flush: import_zlib.default.constants.BROTLI_OPERATION_FLUSH, finishFlush: import_zlib.default.constants.BROTLI_OPERATION_FLUSH };
var Ps = fe.isFunction(import_zlib.default.createBrotliDecompress);
var { http: Bs, https: Ls } = fs;
var Us = /https:?/;
var zs = Tt.protocols.map((e5) => e5 + ":");
var Is = (e5, [a2, n2]) => (e5.on("end", n2).on("error", n2), a2);
function Ns(e5, a2) {
  e5.beforeRedirects.proxy && e5.beforeRedirects.proxy(e5), e5.beforeRedirects.config && e5.beforeRedirects.config(e5, a2);
}
function Ms(e5, a2, n2) {
  let t2 = a2;
  if (!t2 && false !== t2) {
    const e6 = Kt.getProxyForUrl(n2);
    e6 && (t2 = new URL(e6));
  }
  if (t2) {
    if (t2.username && (t2.auth = (t2.username || "") + ":" + (t2.password || "")), t2.auth) {
      (t2.auth.username || t2.auth.password) && (t2.auth = (t2.auth.username || "") + ":" + (t2.auth.password || ""));
      const a4 = Buffer.from(t2.auth, "utf8").toString("base64");
      e5.headers["Proxy-Authorization"] = "Basic " + a4;
    }
    e5.headers.host = e5.hostname + (e5.port ? ":" + e5.port : "");
    const a3 = t2.hostname || t2.host;
    e5.hostname = a3, e5.host = a3, e5.port = t2.port, e5.path = n2, t2.protocol && (e5.protocol = t2.protocol.includes(":") ? t2.protocol : `${t2.protocol}:`);
  }
  e5.beforeRedirects.proxy = function(e6) {
    Ms(e6, a2, e6.href);
  };
}
var $s = "undefined" != typeof process && "process" === fe.kindOf(process);
var Ws = (e5, a2) => (({ address: e6, family: a3 }) => {
  if (!fe.isString(e6)) throw TypeError("address must be a string");
  return { address: e6, family: a3 || (e6.indexOf(".") < 0 ? 6 : 4) };
})(fe.isObject(e5) ? e5 : { address: e5, family: a2 });
var Hs = $s && function(t2) {
  return o2 = async function(o3, r2, c2) {
    let { data: p2, lookup: l2, family: m2 } = t2;
    const { responseType: h2, responseEncoding: f2 } = t2, x2 = t2.method.toUpperCase();
    let v2, b2, g2 = false;
    if (l2) {
      const e5 = qs(l2, (e6) => fe.isArray(e6) ? e6 : [e6]);
      l2 = (a2, n2, t3) => {
        e5(a2, n2, (e6, a3, s2) => {
          if (e6) return t3(e6);
          const i2 = fe.isArray(a3) ? a3.map((e7) => Ws(e7)) : [Ws(a3, s2)];
          n2.all ? t3(e6, i2) : t3(e6, i2[0].address, i2[0].family);
        });
      };
    }
    const y2 = new import_events.EventEmitter(), w2 = () => {
      t2.cancelToken && t2.cancelToken.unsubscribe(_2), t2.signal && t2.signal.removeEventListener("abort", _2), y2.removeAllListeners();
    };
    function _2(e5) {
      y2.emit("abort", !e5 || e5.type ? new zt(null, t2, b2) : e5);
    }
    c2((e5, a2) => {
      v2 = true, a2 && (g2 = true, w2());
    }), y2.once("abort", r2), (t2.cancelToken || t2.signal) && (t2.cancelToken && t2.cancelToken.subscribe(_2), t2.signal && (t2.signal.aborted ? _2() : t2.signal.addEventListener("abort", _2)));
    const k2 = Nt(t2.baseURL, t2.url), j2 = new URL(k2, Tt.hasBrowserEnv ? Tt.origin : void 0), R2 = j2.protocol || zs[0];
    if ("data:" === R2) {
      let e5;
      if ("GET" !== x2) return It(o3, r2, { status: 405, statusText: "method not allowed", headers: {}, config: t2 });
      try {
        e5 = function(e6, a2, n2) {
          const t3 = n2 && n2.Blob || Tt.classes.Blob, s2 = vs(e6);
          if (void 0 === a2 && t3 && (a2 = true), "data" === s2) {
            e6 = s2.length ? e6.slice(s2.length + 1) : e6;
            const n3 = bs.exec(e6);
            if (!n3) throw new xe("Invalid URL", xe.ERR_INVALID_URL);
            const i2 = n3[1], o4 = n3[2], r3 = n3[3], c3 = Buffer.from(decodeURIComponent(r3), o4 ? "base64" : "utf8");
            if (a2) {
              if (!t3) throw new xe("Blob is not supported", xe.ERR_NOT_SUPPORT);
              return new t3([c3], { type: i2 });
            }
            return c3;
          }
          throw new xe("Unsupported protocol " + s2, xe.ERR_NOT_SUPPORT);
        }(t2.url, "blob" === h2, { Blob: t2.env && t2.env.Blob });
      } catch (e6) {
        throw xe.from(e6, xe.ERR_BAD_REQUEST, t2);
      }
      return "text" === h2 ? (e5 = e5.toString(f2), f2 && "utf8" !== f2 || (e5 = fe.stripBOM(e5))) : "stream" === h2 && (e5 = import_stream.default.Readable.from(e5)), It(o3, r2, { data: e5, status: 200, statusText: "OK", headers: new Bt(), config: t2 });
    }
    if (-1 === zs.indexOf(R2)) return r2(new xe("Unsupported protocol " + R2, xe.ERR_BAD_REQUEST, t2));
    const S2 = Bt.from(t2.headers).normalize();
    S2.set("User-Agent", "axios/" + xs, false);
    const { onUploadProgress: E2, onDownloadProgress: T2 } = t2, q2 = t2.maxRate;
    let C2, A2;
    if (fe.isSpecCompliantForm(p2)) {
      const e5 = S2.getContentType(/boundary=([-_\w\d]{10,70})/i);
      p2 = ((e6, a2, t3) => {
        const { tag: s2 = "form-data-boundary", size: i2 = 25, boundary: o4 = s2 + "-" + fe.generateString(i2, ks) } = t3 || {};
        if (!fe.isFormData(e6)) throw TypeError("FormData instance required");
        if (o4.length < 1 || o4.length > 70) throw Error("boundary must be 10-70 characters long");
        const r3 = js.encode("--" + o4 + Rs), c3 = js.encode("--" + o4 + "--" + Rs + Rs);
        let p3 = c3.byteLength;
        const l3 = Array.from(e6.entries()).map(([e7, a3]) => {
          const n2 = new Es(e7, a3);
          return p3 += n2.size, n2;
        });
        p3 += r3.byteLength * l3.length, p3 = fe.toFiniteNumber(p3);
        const u2 = { "Content-Type": `multipart/form-data; boundary=${o4}` };
        return Number.isFinite(p3) && (u2["Content-Length"] = p3), a2 && a2(u2), import_stream.Readable.from(async function* () {
          for (const e7 of l3) yield r3, yield* e7.encode();
          yield c3;
        }());
      })(p2, (e6) => {
        S2.set(e6);
      }, { tag: `axios-${xs}-boundary`, boundary: e5 && e5[1] || void 0 });
    } else if (fe.isFormData(p2) && fe.isFunction(p2.getHeaders)) {
      if (S2.set(p2.getHeaders()), !S2.hasContentLength()) try {
        const a2 = await import_util.default.promisify(p2.getLength).call(p2);
        Number.isFinite(a2) && a2 >= 0 && S2.setContentLength(a2);
      } catch (e5) {
      }
    } else if (fe.isBlob(p2) || fe.isFile(p2)) p2.size && S2.setContentType(p2.type || "application/octet-stream"), S2.setContentLength(p2.size || 0), p2 = import_stream.default.Readable.from(_s(p2));
    else if (p2 && !fe.isStream(p2)) {
      if (Buffer.isBuffer(p2)) ;
      else if (fe.isArrayBuffer(p2)) p2 = Buffer.from(new Uint8Array(p2));
      else {
        if (!fe.isString(p2)) return r2(new xe("Data after transformation must be a string, an ArrayBuffer, a Buffer, or a Stream", xe.ERR_BAD_REQUEST, t2));
        p2 = Buffer.from(p2, "utf-8");
      }
      if (S2.setContentLength(p2.length, false), t2.maxBodyLength > -1 && p2.length > t2.maxBodyLength) return r2(new xe("Request body larger than maxBodyLength limit", xe.ERR_BAD_REQUEST, t2));
    }
    const O2 = fe.toFiniteNumber(S2.getContentLength());
    let F2, D2;
    fe.isArray(q2) ? (C2 = q2[0], A2 = q2[1]) : C2 = A2 = q2, p2 && (E2 || C2) && (fe.isStream(p2) || (p2 = import_stream.default.Readable.from(p2, { objectMode: false })), p2 = import_stream.default.pipeline([p2, new ys({ maxRate: fe.toFiniteNumber(C2) })], fe.noop), E2 && p2.on("progress", Is(p2, As(O2, Cs(Os(E2), false, 3))))), t2.auth && (F2 = (t2.auth.username || "") + ":" + (t2.auth.password || "")), !F2 && j2.username && (F2 = j2.username + ":" + j2.password), F2 && S2.delete("authorization");
    try {
      D2 = gt(j2.pathname + j2.search, t2.params, t2.paramsSerializer).replace(/^\?/, "");
    } catch (e5) {
      const a2 = new Error(e5.message);
      return a2.config = t2, a2.url = t2.url, a2.exists = true, r2(a2);
    }
    S2.set("Accept-Encoding", "gzip, compress, deflate" + (Ps ? ", br" : ""), false);
    const P2 = { path: D2, method: x2, headers: S2.toJSON(), agents: { http: t2.httpAgent, https: t2.httpsAgent }, auth: F2, protocol: R2, family: m2, beforeRedirect: Ns, beforeRedirects: {} };
    let B2;
    !fe.isUndefined(l2) && (P2.lookup = l2), t2.socketPath ? P2.socketPath = t2.socketPath : (P2.hostname = j2.hostname.startsWith("[") ? j2.hostname.slice(1, -1) : j2.hostname, P2.port = j2.port, Ms(P2, t2.proxy, R2 + "//" + j2.hostname + (j2.port ? ":" + j2.port : "") + P2.path));
    const L2 = Us.test(P2.protocol);
    if (P2.agent = L2 ? t2.httpsAgent : t2.httpAgent, t2.transport ? B2 = t2.transport : 0 === t2.maxRedirects ? B2 = L2 ? import_https.default : import_http.default : (t2.maxRedirects && (P2.maxRedirects = t2.maxRedirects), t2.beforeRedirect && (P2.beforeRedirects.config = t2.beforeRedirect), B2 = L2 ? Ls : Bs), t2.maxBodyLength > -1 ? P2.maxBodyLength = t2.maxBodyLength : P2.maxBodyLength = 1 / 0, t2.insecureHTTPParser && (P2.insecureHTTPParser = t2.insecureHTTPParser), b2 = B2.request(P2, function(e5) {
      if (b2.destroyed) return;
      const n2 = [e5], s2 = +e5.headers["content-length"];
      if (T2 || A2) {
        const e6 = new ys({ maxRate: fe.toFiniteNumber(A2) });
        T2 && e6.on("progress", Is(e6, As(s2, Cs(Os(T2), true, 3)))), n2.push(e6);
      }
      let i2 = e5;
      const c3 = e5.req || b2;
      if (false !== t2.decompress && e5.headers["content-encoding"]) switch ("HEAD" !== x2 && 204 !== e5.statusCode || delete e5.headers["content-encoding"], (e5.headers["content-encoding"] || "").toLowerCase()) {
        case "gzip":
        case "x-gzip":
        case "compress":
        case "x-compress":
          n2.push(import_zlib.default.createUnzip(Fs)), delete e5.headers["content-encoding"];
          break;
        case "deflate":
          n2.push(new Ts()), n2.push(import_zlib.default.createUnzip(Fs)), delete e5.headers["content-encoding"];
          break;
        case "br":
          Ps && (n2.push(import_zlib.default.createBrotliDecompress(Ds)), delete e5.headers["content-encoding"]);
      }
      i2 = n2.length > 1 ? import_stream.default.pipeline(n2, fe.noop) : n2[0];
      const p3 = import_stream.default.finished(i2, () => {
        p3(), w2();
      }), l3 = { status: e5.statusCode, statusText: e5.statusMessage, headers: new Bt(e5.headers), config: t2, request: c3 };
      if ("stream" === h2) l3.data = i2, It(o3, r2, l3);
      else {
        const e6 = [];
        let a2 = 0;
        i2.on("data", function(n3) {
          e6.push(n3), a2 += n3.length, t2.maxContentLength > -1 && a2 > t2.maxContentLength && (g2 = true, i2.destroy(), r2(new xe("maxContentLength size of " + t2.maxContentLength + " exceeded", xe.ERR_BAD_RESPONSE, t2, c3)));
        }), i2.on("aborted", function() {
          if (g2) return;
          const e7 = new xe("stream has been aborted", xe.ERR_BAD_RESPONSE, t2, c3);
          i2.destroy(e7), r2(e7);
        }), i2.on("error", function(e7) {
          b2.destroyed || r2(xe.from(e7, null, t2, c3));
        }), i2.on("end", function() {
          try {
            let a3 = 1 === e6.length ? e6[0] : Buffer.concat(e6);
            "arraybuffer" !== h2 && (a3 = a3.toString(f2), f2 && "utf8" !== f2 || (a3 = fe.stripBOM(a3))), l3.data = a3;
          } catch (e7) {
            return r2(xe.from(e7, null, t2, l3.request, l3));
          }
          It(o3, r2, l3);
        });
      }
      y2.once("abort", (e6) => {
        i2.destroyed || (i2.emit("error", e6), i2.destroy());
      });
    }), y2.once("abort", (e5) => {
      r2(e5), b2.destroy(e5);
    }), b2.on("error", function(e5) {
      r2(xe.from(e5, null, t2, b2));
    }), b2.on("socket", function(e5) {
      e5.setKeepAlive(true, 6e4);
    }), t2.timeout) {
      const e5 = parseInt(t2.timeout, 10);
      if (Number.isNaN(e5)) return void r2(new xe("error trying to parse `config.timeout` to int", xe.ERR_BAD_OPTION_VALUE, t2, b2));
      b2.setTimeout(e5, function() {
        if (v2) return;
        let e6 = t2.timeout ? "timeout of " + t2.timeout + "ms exceeded" : "timeout exceeded";
        const a2 = t2.transitional || wt;
        t2.timeoutErrorMessage && (e6 = t2.timeoutErrorMessage), r2(new xe(e6, a2.clarifyTimeoutError ? xe.ETIMEDOUT : xe.ECONNABORTED, t2, b2)), _2();
      });
    }
    if (fe.isStream(p2)) {
      let e5 = false, a2 = false;
      p2.on("end", () => {
        e5 = true;
      }), p2.once("error", (e6) => {
        a2 = true, b2.destroy(e6);
      }), p2.on("close", () => {
        e5 || a2 || _2(new zt("Request stream has been aborted", t2, b2));
      }), p2.pipe(b2);
    } else b2.end(p2);
  }, new Promise((e5, a2) => {
    let n2, t3;
    const s2 = (e6, a3) => {
      t3 || (t3 = true, n2 && n2(e6, a3));
    }, i2 = (e6) => {
      s2(e6, true), a2(e6);
    };
    o2((a3) => {
      s2(a3), e5(a3);
    }, i2, (e6) => n2 = e6).catch(i2);
  });
  var o2;
};
var Vs = Tt.hasStandardBrowserEnv ? /* @__PURE__ */ ((e5, a2) => (n2) => (n2 = new URL(n2, Tt.origin), e5.protocol === n2.protocol && e5.host === n2.host && (a2 || e5.port === n2.port)))(new URL(Tt.origin), Tt.navigator && /(msie|trident)/i.test(Tt.navigator.userAgent)) : () => true;
var Gs = Tt.hasStandardBrowserEnv ? { write(e5, a2, n2, t2, s2, i2) {
  const o2 = [e5 + "=" + encodeURIComponent(a2)];
  fe.isNumber(n2) && o2.push("expires=" + new Date(n2).toGMTString()), fe.isString(t2) && o2.push("path=" + t2), fe.isString(s2) && o2.push("domain=" + s2), true === i2 && o2.push("secure"), document.cookie = o2.join("; ");
}, read(e5) {
  const a2 = document.cookie.match(new RegExp("(^|;\\s*)(" + e5 + ")=([^;]*)"));
  return a2 ? decodeURIComponent(a2[3]) : null;
}, remove(e5) {
  this.write(e5, "", Date.now() - 864e5);
} } : { write() {
}, read: () => null, remove() {
} };
var Js = (e5) => e5 instanceof Bt ? { ...e5 } : e5;
function Ks(e5, a2) {
  a2 = a2 || {};
  const n2 = {};
  function t2(e6, a3, n3, t3) {
    return fe.isPlainObject(e6) && fe.isPlainObject(a3) ? fe.merge.call({ caseless: t3 }, e6, a3) : fe.isPlainObject(a3) ? fe.merge({}, a3) : fe.isArray(a3) ? a3.slice() : a3;
  }
  function s2(e6, a3, n3, s3) {
    return fe.isUndefined(a3) ? fe.isUndefined(e6) ? void 0 : t2(void 0, e6, 0, s3) : t2(e6, a3, 0, s3);
  }
  function i2(e6, a3) {
    if (!fe.isUndefined(a3)) return t2(void 0, a3);
  }
  function o2(e6, a3) {
    return fe.isUndefined(a3) ? fe.isUndefined(e6) ? void 0 : t2(void 0, e6) : t2(void 0, a3);
  }
  function r2(n3, s3, i3) {
    return i3 in a2 ? t2(n3, s3) : i3 in e5 ? t2(void 0, n3) : void 0;
  }
  const c2 = { url: i2, method: i2, data: i2, baseURL: o2, transformRequest: o2, transformResponse: o2, paramsSerializer: o2, timeout: o2, timeoutMessage: o2, withCredentials: o2, withXSRFToken: o2, adapter: o2, responseType: o2, xsrfCookieName: o2, xsrfHeaderName: o2, onUploadProgress: o2, onDownloadProgress: o2, decompress: o2, maxContentLength: o2, maxBodyLength: o2, beforeRedirect: o2, transport: o2, httpAgent: o2, httpsAgent: o2, cancelToken: o2, socketPath: o2, responseEncoding: o2, validateStatus: r2, headers: (e6, a3, n3) => s2(Js(e6), Js(a3), 0, true) };
  return fe.forEach(Object.keys(Object.assign({}, e5, a2)), function(t3) {
    const i3 = c2[t3] || s2, o3 = i3(e5[t3], a2[t3], t3);
    fe.isUndefined(o3) && i3 !== r2 || (n2[t3] = o3);
  }), n2;
}
var Qs = (e5) => {
  const a2 = Ks({}, e5);
  let n2, { data: t2, withXSRFToken: s2, xsrfHeaderName: i2, xsrfCookieName: o2, headers: r2, auth: c2 } = a2;
  if (a2.headers = r2 = Bt.from(r2), a2.url = gt(Nt(a2.baseURL, a2.url), e5.params, e5.paramsSerializer), c2 && r2.set("Authorization", "Basic " + btoa((c2.username || "") + ":" + (c2.password ? unescape(encodeURIComponent(c2.password)) : ""))), fe.isFormData(t2)) {
    if (Tt.hasStandardBrowserEnv || Tt.hasStandardBrowserWebWorkerEnv) r2.setContentType(void 0);
    else if (false !== (n2 = r2.getContentType())) {
      const [e6, ...a3] = n2 ? n2.split(";").map((e7) => e7.trim()).filter(Boolean) : [];
      r2.setContentType([e6 || "multipart/form-data", ...a3].join("; "));
    }
  }
  if (Tt.hasStandardBrowserEnv && (s2 && fe.isFunction(s2) && (s2 = s2(a2)), s2 || false !== s2 && Vs(a2.url))) {
    const e6 = i2 && o2 && Gs.read(o2);
    e6 && r2.set(i2, e6);
  }
  return a2;
};
var Ys = "undefined" != typeof XMLHttpRequest && function(e5) {
  return new Promise(function(a2, n2) {
    const t2 = Qs(e5);
    let s2 = t2.data;
    const i2 = Bt.from(t2.headers).normalize();
    let o2, r2, c2, p2, l2, { responseType: u2, onUploadProgress: d2, onDownloadProgress: m2 } = t2;
    function h2() {
      p2 && p2(), l2 && l2(), t2.cancelToken && t2.cancelToken.unsubscribe(o2), t2.signal && t2.signal.removeEventListener("abort", o2);
    }
    let f2 = new XMLHttpRequest();
    function x2() {
      if (!f2) return;
      const t3 = Bt.from("getAllResponseHeaders" in f2 && f2.getAllResponseHeaders());
      It(function(e6) {
        a2(e6), h2();
      }, function(e6) {
        n2(e6), h2();
      }, { data: u2 && "text" !== u2 && "json" !== u2 ? f2.response : f2.responseText, status: f2.status, statusText: f2.statusText, headers: t3, config: e5, request: f2 }), f2 = null;
    }
    f2.open(t2.method.toUpperCase(), t2.url, true), f2.timeout = t2.timeout, "onloadend" in f2 ? f2.onloadend = x2 : f2.onreadystatechange = function() {
      f2 && 4 === f2.readyState && (0 !== f2.status || f2.responseURL && 0 === f2.responseURL.indexOf("file:")) && setTimeout(x2);
    }, f2.onabort = function() {
      f2 && (n2(new xe("Request aborted", xe.ECONNABORTED, e5, f2)), f2 = null);
    }, f2.onerror = function() {
      n2(new xe("Network Error", xe.ERR_NETWORK, e5, f2)), f2 = null;
    }, f2.ontimeout = function() {
      let a3 = t2.timeout ? "timeout of " + t2.timeout + "ms exceeded" : "timeout exceeded";
      const s3 = t2.transitional || wt;
      t2.timeoutErrorMessage && (a3 = t2.timeoutErrorMessage), n2(new xe(a3, s3.clarifyTimeoutError ? xe.ETIMEDOUT : xe.ECONNABORTED, e5, f2)), f2 = null;
    }, void 0 === s2 && i2.setContentType(null), "setRequestHeader" in f2 && fe.forEach(i2.toJSON(), function(e6, a3) {
      f2.setRequestHeader(a3, e6);
    }), fe.isUndefined(t2.withCredentials) || (f2.withCredentials = !!t2.withCredentials), u2 && "json" !== u2 && (f2.responseType = t2.responseType), m2 && ([c2, l2] = Cs(m2, true), f2.addEventListener("progress", c2)), d2 && f2.upload && ([r2, p2] = Cs(d2), f2.upload.addEventListener("progress", r2), f2.upload.addEventListener("loadend", p2)), (t2.cancelToken || t2.signal) && (o2 = (a3) => {
      f2 && (n2(!a3 || a3.type ? new zt(null, e5, f2) : a3), f2.abort(), f2 = null);
    }, t2.cancelToken && t2.cancelToken.subscribe(o2), t2.signal && (t2.signal.aborted ? o2() : t2.signal.addEventListener("abort", o2)));
    const v2 = vs(t2.url);
    v2 && -1 === Tt.protocols.indexOf(v2) ? n2(new xe("Unsupported protocol " + v2 + ":", xe.ERR_BAD_REQUEST, e5)) : f2.send(s2 || null);
  });
};
var Xs = (e5, a2) => {
  const { length: n2 } = e5 = e5 ? e5.filter(Boolean) : [];
  if (a2 || n2) {
    let n3, t2 = new AbortController();
    const s2 = function(e6) {
      if (!n3) {
        n3 = true, o2();
        const a3 = e6 instanceof Error ? e6 : this.reason;
        t2.abort(a3 instanceof xe ? a3 : new zt(a3 instanceof Error ? a3.message : a3));
      }
    };
    let i2 = a2 && setTimeout(() => {
      i2 = null, s2(new xe(`timeout ${a2} of ms exceeded`, xe.ETIMEDOUT));
    }, a2);
    const o2 = () => {
      e5 && (i2 && clearTimeout(i2), i2 = null, e5.forEach((e6) => {
        e6.unsubscribe ? e6.unsubscribe(s2) : e6.removeEventListener("abort", s2);
      }), e5 = null);
    };
    e5.forEach((e6) => e6.addEventListener("abort", s2));
    const { signal: r2 } = t2;
    return r2.unsubscribe = () => fe.asap(o2), r2;
  }
};
var Zs = function* (e5, a2) {
  let n2 = e5.byteLength;
  if (n2 < a2) return void (yield e5);
  let t2, s2 = 0;
  for (; s2 < n2; ) t2 = s2 + a2, yield e5.slice(s2, t2), s2 = t2;
};
var ei = async function* (e5) {
  if (e5[Symbol.asyncIterator]) return void (yield* e5);
  const a2 = e5.getReader();
  try {
    for (; ; ) {
      const { done: e6, value: n2 } = await a2.read();
      if (e6) break;
      yield n2;
    }
  } finally {
    await a2.cancel();
  }
};
var ai = (e5, a2, n2, t2) => {
  const s2 = async function* (e6, a3) {
    for await (const n3 of ei(e6)) yield* Zs(n3, a3);
  }(e5, a2);
  let i2, o2 = 0, r2 = (e6) => {
    i2 || (i2 = true, t2 && t2(e6));
  };
  return new ReadableStream({ async pull(e6) {
    try {
      const { done: a3, value: t3 } = await s2.next();
      if (a3) return r2(), void e6.close();
      let i3 = t3.byteLength;
      if (n2) {
        let e7 = o2 += i3;
        n2(e7);
      }
      e6.enqueue(new Uint8Array(t3));
    } catch (e7) {
      throw r2(e7), e7;
    }
  }, cancel: (e6) => (r2(e6), s2.return()) }, { highWaterMark: 2 });
};
var ni = "function" == typeof fetch && "function" == typeof Request && "function" == typeof Response;
var ti = ni && "function" == typeof ReadableStream;
var si = ni && ("function" == typeof TextEncoder ? (ii = new TextEncoder(), (e5) => ii.encode(e5)) : async (e5) => new Uint8Array(await new Response(e5).arrayBuffer()));
var ii;
var oi = (e5, ...a2) => {
  try {
    return !!e5(...a2);
  } catch (e6) {
    return false;
  }
};
var ri = ti && oi(() => {
  let e5 = false;
  const a2 = new Request(Tt.origin, { body: new ReadableStream(), method: "POST", get duplex() {
    return e5 = true, "half";
  } }).headers.has("Content-Type");
  return e5 && !a2;
});
var ci = ti && oi(() => fe.isReadableStream(new Response("").body));
var pi = { stream: ci && ((e5) => e5.body) };
var li;
ni && (li = new Response(), ["text", "arrayBuffer", "blob", "formData", "stream"].forEach((e5) => {
  !pi[e5] && (pi[e5] = fe.isFunction(li[e5]) ? (a2) => a2[e5]() : (a2, n2) => {
    throw new xe(`Response type '${e5}' is not supported`, xe.ERR_NOT_SUPPORT, n2);
  });
}));
var ui = async (e5, a2) => {
  const n2 = fe.toFiniteNumber(e5.getContentLength());
  return null == n2 ? (async (e6) => {
    if (null == e6) return 0;
    if (fe.isBlob(e6)) return e6.size;
    if (fe.isSpecCompliantForm(e6)) {
      const a3 = new Request(Tt.origin, { method: "POST", body: e6 });
      return (await a3.arrayBuffer()).byteLength;
    }
    return fe.isArrayBufferView(e6) || fe.isArrayBuffer(e6) ? e6.byteLength : (fe.isURLSearchParams(e6) && (e6 += ""), fe.isString(e6) ? (await si(e6)).byteLength : void 0);
  })(a2) : n2;
};
var di = { http: Hs, xhr: Ys, fetch: ni && (async (e5) => {
  let { url: a2, method: n2, data: t2, signal: s2, cancelToken: i2, timeout: o2, onDownloadProgress: r2, onUploadProgress: c2, responseType: p2, headers: l2, withCredentials: u2 = "same-origin", fetchOptions: d2 } = Qs(e5);
  p2 = p2 ? (p2 + "").toLowerCase() : "text";
  let m2, h2 = Xs([s2, i2 && i2.toAbortSignal()], o2);
  const f2 = h2 && h2.unsubscribe && (() => {
    h2.unsubscribe();
  });
  let x2;
  try {
    if (c2 && ri && "get" !== n2 && "head" !== n2 && 0 !== (x2 = await ui(l2, t2))) {
      let e6, n3 = new Request(a2, { method: "POST", body: t2, duplex: "half" });
      if (fe.isFormData(t2) && (e6 = n3.headers.get("content-type")) && l2.setContentType(e6), n3.body) {
        const [e7, a3] = As(x2, Cs(Os(c2)));
        t2 = ai(n3.body, 65536, e7, a3);
      }
    }
    fe.isString(u2) || (u2 = u2 ? "include" : "omit");
    const s3 = "credentials" in Request.prototype;
    m2 = new Request(a2, { ...d2, signal: h2, method: n2.toUpperCase(), headers: l2.normalize().toJSON(), body: t2, duplex: "half", credentials: s3 ? u2 : void 0 });
    let i3 = await fetch(m2);
    const o3 = ci && ("stream" === p2 || "response" === p2);
    if (ci && (r2 || o3 && f2)) {
      const e6 = {};
      ["status", "statusText", "headers"].forEach((a4) => {
        e6[a4] = i3[a4];
      });
      const a3 = fe.toFiniteNumber(i3.headers.get("content-length")), [n3, t3] = r2 && As(a3, Cs(Os(r2), true)) || [];
      i3 = new Response(ai(i3.body, 65536, n3, () => {
        t3 && t3(), f2 && f2();
      }), e6);
    }
    p2 = p2 || "text";
    let v2 = await pi[fe.findKey(pi, p2) || "text"](i3, e5);
    return !o3 && f2 && f2(), await new Promise((a3, n3) => {
      It(a3, n3, { data: v2, headers: Bt.from(i3.headers), status: i3.status, statusText: i3.statusText, config: e5, request: m2 });
    });
  } catch (a3) {
    if (f2 && f2(), a3 && "TypeError" === a3.name && /fetch/i.test(a3.message)) throw Object.assign(new xe("Network Error", xe.ERR_NETWORK, e5, m2), { cause: a3.cause || a3 });
    throw xe.from(a3, a3 && a3.code, e5, m2);
  }
}) };
fe.forEach(di, (e5, a2) => {
  if (e5) {
    try {
      Object.defineProperty(e5, "name", { value: a2 });
    } catch (e6) {
    }
    Object.defineProperty(e5, "adapterName", { value: a2 });
  }
});
var mi = (e5) => `- ${e5}`;
var hi = (e5) => fe.isFunction(e5) || null === e5 || false === e5;
var fi = (e5) => {
  e5 = fe.isArray(e5) ? e5 : [e5];
  const { length: a2 } = e5;
  let n2, t2;
  const s2 = {};
  for (let i2 = 0; i2 < a2; i2++) {
    let a3;
    if (n2 = e5[i2], t2 = n2, !hi(n2) && (t2 = di[(a3 = String(n2)).toLowerCase()], void 0 === t2)) throw new xe(`Unknown adapter '${a3}'`);
    if (t2) break;
    s2[a3 || "#" + i2] = t2;
  }
  if (!t2) {
    const e6 = Object.entries(s2).map(([e7, a3]) => `adapter ${e7} ` + (false === a3 ? "is not supported by the environment" : "is not available in the build"));
    throw new xe("There is no suitable adapter to dispatch the request " + (a2 ? e6.length > 1 ? "since :\n" + e6.map(mi).join("\n") : " " + mi(e6[0]) : "as no adapter specified"), "ERR_NOT_SUPPORT");
  }
  return t2;
};
function xi(e5) {
  if (e5.cancelToken && e5.cancelToken.throwIfRequested(), e5.signal && e5.signal.aborted) throw new zt(null, e5);
}
function vi(e5) {
  xi(e5), e5.headers = Bt.from(e5.headers), e5.data = Lt.call(e5, e5.transformRequest), -1 !== ["post", "put", "patch"].indexOf(e5.method) && e5.headers.setContentType("application/x-www-form-urlencoded", false);
  return fi(e5.adapter || Ct.adapter)(e5).then(function(a2) {
    return xi(e5), a2.data = Lt.call(e5, e5.transformResponse, a2), a2.headers = Bt.from(a2.headers), a2;
  }, function(a2) {
    return Ut(a2) || (xi(e5), a2 && a2.response && (a2.response.data = Lt.call(e5, e5.transformResponse, a2.response), a2.response.headers = Bt.from(a2.response.headers))), Promise.reject(a2);
  });
}
var bi = {};
["object", "boolean", "number", "function", "string", "symbol"].forEach((e5, a2) => {
  bi[e5] = function(n2) {
    return typeof n2 === e5 || "a" + (a2 < 1 ? "n " : " ") + e5;
  };
});
var gi = {};
bi.transitional = function(e5, a2, n2) {
  function t2(e6, a3) {
    return "[Axios v1.7.9] Transitional option '" + e6 + "'" + a3 + (n2 ? ". " + n2 : "");
  }
  return (n3, s2, i2) => {
    if (false === e5) throw new xe(t2(s2, " has been removed" + (a2 ? " in " + a2 : "")), xe.ERR_DEPRECATED);
    return a2 && !gi[s2] && (gi[s2] = true, console.warn(t2(s2, " has been deprecated since v" + a2 + " and will be removed in the near future"))), !e5 || e5(n3, s2, i2);
  };
}, bi.spelling = function(e5) {
  return (a2, n2) => (console.warn(`${n2} is likely a misspelling of ${e5}`), true);
};
var yi = { assertOptions: function(e5, a2, n2) {
  if ("object" != typeof e5) throw new xe("options must be an object", xe.ERR_BAD_OPTION_VALUE);
  const t2 = Object.keys(e5);
  let s2 = t2.length;
  for (; s2-- > 0; ) {
    const i2 = t2[s2], o2 = a2[i2];
    if (o2) {
      const a3 = e5[i2], n3 = void 0 === a3 || o2(a3, i2, e5);
      if (true !== n3) throw new xe("option " + i2 + " must be " + n3, xe.ERR_BAD_OPTION_VALUE);
    } else if (true !== n2) throw new xe("Unknown option " + i2, xe.ERR_BAD_OPTION);
  }
}, validators: bi };
var wi = yi.validators;
var _i = class {
  constructor(e5) {
    this.defaults = e5, this.interceptors = { request: new yt(), response: new yt() };
  }
  async request(e5, a2) {
    try {
      return await this._request(e5, a2);
    } catch (e6) {
      if (e6 instanceof Error) {
        let a3 = {};
        Error.captureStackTrace ? Error.captureStackTrace(a3) : a3 = new Error();
        const n2 = a3.stack ? a3.stack.replace(/^.+\n/, "") : "";
        try {
          e6.stack ? n2 && !String(e6.stack).endsWith(n2.replace(/^.+\n.+\n/, "")) && (e6.stack += "\n" + n2) : e6.stack = n2;
        } catch (e7) {
        }
      }
      throw e6;
    }
  }
  _request(e5, a2) {
    "string" == typeof e5 ? (a2 = a2 || {}).url = e5 : a2 = e5 || {}, a2 = Ks(this.defaults, a2);
    const { transitional: n2, paramsSerializer: t2, headers: s2 } = a2;
    void 0 !== n2 && yi.assertOptions(n2, { silentJSONParsing: wi.transitional(wi.boolean), forcedJSONParsing: wi.transitional(wi.boolean), clarifyTimeoutError: wi.transitional(wi.boolean) }, false), null != t2 && (fe.isFunction(t2) ? a2.paramsSerializer = { serialize: t2 } : yi.assertOptions(t2, { encode: wi.function, serialize: wi.function }, true)), yi.assertOptions(a2, { baseUrl: wi.spelling("baseURL"), withXsrfToken: wi.spelling("withXSRFToken") }, true), a2.method = (a2.method || this.defaults.method || "get").toLowerCase();
    let i2 = s2 && fe.merge(s2.common, s2[a2.method]);
    s2 && fe.forEach(["delete", "get", "head", "post", "put", "patch", "common"], (e6) => {
      delete s2[e6];
    }), a2.headers = Bt.concat(i2, s2);
    const o2 = [];
    let r2 = true;
    this.interceptors.request.forEach(function(e6) {
      "function" == typeof e6.runWhen && false === e6.runWhen(a2) || (r2 = r2 && e6.synchronous, o2.unshift(e6.fulfilled, e6.rejected));
    });
    const c2 = [];
    let p2;
    this.interceptors.response.forEach(function(e6) {
      c2.push(e6.fulfilled, e6.rejected);
    });
    let l2, u2 = 0;
    if (!r2) {
      const e6 = [vi.bind(this), void 0];
      for (e6.unshift.apply(e6, o2), e6.push.apply(e6, c2), l2 = e6.length, p2 = Promise.resolve(a2); u2 < l2; ) p2 = p2.then(e6[u2++], e6[u2++]);
      return p2;
    }
    l2 = o2.length;
    let d2 = a2;
    for (u2 = 0; u2 < l2; ) {
      const e6 = o2[u2++], a3 = o2[u2++];
      try {
        d2 = e6(d2);
      } catch (e7) {
        a3.call(this, e7);
        break;
      }
    }
    try {
      p2 = vi.call(this, d2);
    } catch (e6) {
      return Promise.reject(e6);
    }
    for (u2 = 0, l2 = c2.length; u2 < l2; ) p2 = p2.then(c2[u2++], c2[u2++]);
    return p2;
  }
  getUri(e5) {
    return gt(Nt((e5 = Ks(this.defaults, e5)).baseURL, e5.url), e5.params, e5.paramsSerializer);
  }
};
fe.forEach(["delete", "get", "head", "options"], function(e5) {
  _i.prototype[e5] = function(a2, n2) {
    return this.request(Ks(n2 || {}, { method: e5, url: a2, data: (n2 || {}).data }));
  };
}), fe.forEach(["post", "put", "patch"], function(e5) {
  function a2(a3) {
    return function(n2, t2, s2) {
      return this.request(Ks(s2 || {}, { method: e5, headers: a3 ? { "Content-Type": "multipart/form-data" } : {}, url: n2, data: t2 }));
    };
  }
  _i.prototype[e5] = a2(), _i.prototype[e5 + "Form"] = a2(true);
});
var ki = { Continue: 100, SwitchingProtocols: 101, Processing: 102, EarlyHints: 103, Ok: 200, Created: 201, Accepted: 202, NonAuthoritativeInformation: 203, NoContent: 204, ResetContent: 205, PartialContent: 206, MultiStatus: 207, AlreadyReported: 208, ImUsed: 226, MultipleChoices: 300, MovedPermanently: 301, Found: 302, SeeOther: 303, NotModified: 304, UseProxy: 305, Unused: 306, TemporaryRedirect: 307, PermanentRedirect: 308, BadRequest: 400, Unauthorized: 401, PaymentRequired: 402, Forbidden: 403, NotFound: 404, MethodNotAllowed: 405, NotAcceptable: 406, ProxyAuthenticationRequired: 407, RequestTimeout: 408, Conflict: 409, Gone: 410, LengthRequired: 411, PreconditionFailed: 412, PayloadTooLarge: 413, UriTooLong: 414, UnsupportedMediaType: 415, RangeNotSatisfiable: 416, ExpectationFailed: 417, ImATeapot: 418, MisdirectedRequest: 421, UnprocessableEntity: 422, Locked: 423, FailedDependency: 424, TooEarly: 425, UpgradeRequired: 426, PreconditionRequired: 428, TooManyRequests: 429, RequestHeaderFieldsTooLarge: 431, UnavailableForLegalReasons: 451, InternalServerError: 500, NotImplemented: 501, BadGateway: 502, ServiceUnavailable: 503, GatewayTimeout: 504, HttpVersionNotSupported: 505, VariantAlsoNegotiates: 506, InsufficientStorage: 507, LoopDetected: 508, NotExtended: 510, NetworkAuthenticationRequired: 511 };
Object.entries(ki).forEach(([e5, a2]) => {
  ki[a2] = e5;
});
var ji = function e3(a2) {
  const n2 = new _i(a2), t2 = R(_i.prototype.request, n2);
  return fe.extend(t2, _i.prototype, n2, { allOwnKeys: true }), fe.extend(t2, n2, null, { allOwnKeys: true }), t2.create = function(n3) {
    return e3(Ks(a2, n3));
  }, t2;
}(Ct);
ji.Axios = _i, ji.CanceledError = zt, ji.CancelToken = class e4 {
  constructor(e5) {
    if ("function" != typeof e5) throw new TypeError("executor must be a function.");
    let a2;
    this.promise = new Promise(function(e6) {
      a2 = e6;
    });
    const n2 = this;
    this.promise.then((e6) => {
      if (!n2._listeners) return;
      let a3 = n2._listeners.length;
      for (; a3-- > 0; ) n2._listeners[a3](e6);
      n2._listeners = null;
    }), this.promise.then = (e6) => {
      let a3;
      const t2 = new Promise((e7) => {
        n2.subscribe(e7), a3 = e7;
      }).then(e6);
      return t2.cancel = function() {
        n2.unsubscribe(a3);
      }, t2;
    }, e5(function(e6, t2, s2) {
      n2.reason || (n2.reason = new zt(e6, t2, s2), a2(n2.reason));
    });
  }
  throwIfRequested() {
    if (this.reason) throw this.reason;
  }
  subscribe(e5) {
    this.reason ? e5(this.reason) : this._listeners ? this._listeners.push(e5) : this._listeners = [e5];
  }
  unsubscribe(e5) {
    if (!this._listeners) return;
    const a2 = this._listeners.indexOf(e5);
    -1 !== a2 && this._listeners.splice(a2, 1);
  }
  toAbortSignal() {
    const e5 = new AbortController(), a2 = (a3) => {
      e5.abort(a3);
    };
    return this.subscribe(a2), e5.signal.unsubscribe = () => this.unsubscribe(a2), e5.signal;
  }
  static source() {
    let a2;
    return { token: new e4(function(e5) {
      a2 = e5;
    }), cancel: a2 };
  }
}, ji.isCancel = Ut, ji.VERSION = xs, ji.toFormData = ht, ji.AxiosError = xe, ji.Cancel = ji.CanceledError, ji.all = function(e5) {
  return Promise.all(e5);
}, ji.spread = function(e5) {
  return function(a2) {
    return e5.apply(null, a2);
  };
}, ji.isAxiosError = function(e5) {
  return fe.isObject(e5) && true === e5.isAxiosError;
}, ji.mergeConfig = Ks, ji.AxiosHeaders = Bt, ji.formToJSON = (e5) => qt(fe.isHTMLForm(e5) ? new FormData(e5) : e5), ji.getAdapter = fi, ji.HttpStatusCode = ki, ji.default = ji;
var { Axios: Ri, AxiosError: Si, CanceledError: Ei, isCancel: Ti, CancelToken: qi, VERSION: Ci, all: Ai, Cancel: Oi, isAxiosError: Fi, spread: Di, toFormData: Pi, AxiosHeaders: Bi, HttpStatusCode: Li, formToJSON: Ui, getAdapter: zi, mergeConfig: Ii } = ji;
var Ni = class extends Error {
  status;
  stack;
  details;
  type;
  static getUserDataError(e5, a2) {
    return new this({ status: 400, statusText: e5, body: { message: a2 } });
  }
  constructor({ status: e5, statusText: a2, message: n2, body: t2 = {} }) {
    let s2 = "", i2 = "";
    "string" == typeof t2 ? s2 = t2 : (s2 = t2?.message || "", i2 = t2?.error || ""), super(), this.stack = "", this.status = e5, this.message = n2 || i2 || a2 || "", this.details = s2, this.type = "MailgunAPIError";
  }
};
var Mi = class {
  _stream;
  size;
  constructor(e5, a2) {
    this._stream = e5, this.size = a2;
  }
  stream() {
    return this._stream;
  }
  get [Symbol.toStringTag]() {
    return "Blob";
  }
};
var $i = class {
  getAttachmentOptions(e5) {
    const { filename: a2, contentType: n2, knownLength: t2 } = e5;
    return { ...a2 ? { filename: a2 } : { filename: "file" }, ...n2 && { contentType: n2 }, ...t2 && { knownLength: t2 } };
  }
  getFileInfo(e5) {
    const { name: a2, type: n2, size: t2 } = e5;
    return this.getAttachmentOptions({ filename: a2, contentType: n2, knownLength: t2 });
  }
  getCustomFileInfo(e5) {
    const { filename: a2, contentType: n2, knownLength: t2 } = e5;
    return this.getAttachmentOptions({ filename: a2, contentType: n2, knownLength: t2 });
  }
  getBufferInfo(e5) {
    const { byteLength: a2 } = e5;
    return this.getAttachmentOptions({ filename: "file", contentType: "", knownLength: a2 });
  }
  isStream(e5) {
    return "object" == typeof e5 && "function" == typeof e5.pipe;
  }
  isCustomFile(e5) {
    return "object" == typeof e5 && !!e5.data;
  }
  isBrowserFile(e5) {
    return "object" == typeof e5 && (!!e5.name || "undefined" != typeof Blob && e5 instanceof Blob);
  }
  isBuffer(e5) {
    return "undefined" != typeof Buffer && Buffer.isBuffer(e5);
  }
  getAttachmentInfo(e5) {
    const a2 = this.isBrowserFile(e5), n2 = this.isCustomFile(e5);
    if (!("string" == typeof e5)) {
      if (a2) return this.getFileInfo(e5);
      if ("undefined" != typeof Buffer && Buffer.isBuffer(e5)) return this.getBufferInfo(e5);
      if (n2) return this.getCustomFileInfo(e5);
    }
    return { filename: "file", contentType: void 0, knownLength: void 0 };
  }
  convertToFDexpectedShape(e5) {
    const a2 = this.isStream(e5), n2 = this.isBrowserFile(e5), t2 = this.isCustomFile(e5);
    let s2;
    if (a2 || "string" == typeof e5 || n2 || this.isBuffer(e5)) s2 = e5;
    else {
      if (!t2) throw Ni.getUserDataError("Unknown attachment type " + typeof e5, 'The "attachment" property expects either Buffer, Blob, or String.\n          Also, It is possible to provide an object that has the property "data" with a value that is equal to one of the types counted before.\n          Additionally, you may use an array to send more than one attachment.');
      s2 = e5.data;
    }
    return s2;
  }
  getBlobFromStream(e5, a2) {
    return new Mi(e5, a2);
  }
};
var Wi = class {
  FormDataConstructor;
  fileKeys;
  attachmentsHandler;
  constructor(e5) {
    this.FormDataConstructor = e5, this.fileKeys = ["attachment", "inline", "multipleValidationFile"], this.attachmentsHandler = new $i();
  }
  createFormData(e5) {
    if (!e5) throw new Error("Please provide data object");
    return Object.keys(e5).filter(function(a2) {
      return e5[a2];
    }).reduce((a2, n2) => {
      if (this.fileKeys.includes(n2)) {
        const t2 = e5[n2];
        if (this.isMessageAttachment(t2)) return this.addFilesToFD(n2, t2, a2), a2;
        throw Ni.getUserDataError(`Unknown value ${e5[n2]} with type ${typeof e5[n2]} for property "${n2}"`, `The key "${n2}" should have type of Buffer, Stream, File, or String `);
      }
      if ("message" === n2) {
        const t2 = e5[n2];
        if (!t2 || !this.isMIME(t2)) throw Ni.getUserDataError(`Unknown data type for "${n2}" property`, "The mime data should have type of Buffer, String or Blob");
        return this.addMimeDataToFD(n2, t2, a2), a2;
      }
      return this.addCommonPropertyToFD(n2, e5[n2], a2), a2;
    }, new this.FormDataConstructor());
  }
  addMimeDataToFD(e5, a2, n2) {
    if ("string" != typeof a2) {
      if (this.isFormDataPackage(n2)) {
        n2.append(e5, a2, { filename: "MimeMessage" });
      } else if (void 0 !== typeof Blob) {
        const t2 = n2;
        if (a2 instanceof Blob) return void t2.append(e5, a2, "MimeMessage");
        if (this.attachmentsHandler.isBuffer(a2)) {
          const n3 = new Blob([a2]);
          t2.append(e5, n3, "MimeMessage");
        }
      }
    } else n2.append(e5, a2);
  }
  isMIME(e5) {
    return "string" == typeof e5 || "undefined" != typeof Blob && e5 instanceof Blob || this.attachmentsHandler.isBuffer(e5) || "undefined" != typeof ReadableStream && e5 instanceof ReadableStream;
  }
  isFormDataPackage(e5) {
    return "object" == typeof e5 && null !== e5 && "function" == typeof e5.getHeaders;
  }
  isMessageAttachment(e5) {
    return this.attachmentsHandler.isCustomFile(e5) || "string" == typeof e5 || "undefined" != typeof File && e5 instanceof File || "undefined" != typeof Blob && e5 instanceof Blob || this.attachmentsHandler.isBuffer(e5) || this.attachmentsHandler.isStream(e5) || Array.isArray(e5) && e5.every((a2) => this.attachmentsHandler.isCustomFile(a2) || "undefined" != typeof File && a2 instanceof File || "undefined" != typeof Blob && e5 instanceof Blob || this.attachmentsHandler.isBuffer(a2) || this.attachmentsHandler.isStream(a2));
  }
  addFilesToFD(e5, a2, n2) {
    const t2 = (e6, a3, t3) => {
      const s2 = "multipleValidationFile" === e6 ? "file" : e6, i2 = this.attachmentsHandler.convertToFDexpectedShape(a3), o2 = this.attachmentsHandler.getAttachmentInfo(a3);
      if (this.isFormDataPackage(t3)) {
        const e7 = t3, a4 = "string" == typeof i2 ? Buffer.from(i2) : i2;
        e7.append(s2, a4, o2);
      } else if (void 0 !== typeof Blob) {
        const e7 = n2;
        if ("string" == typeof i2 || this.attachmentsHandler.isBuffer(i2)) {
          const a4 = new Blob([i2]);
          return void e7.append(s2, a4, o2.filename);
        }
        if (i2 instanceof Blob) return void e7.append(s2, i2, o2.filename);
        if (this.attachmentsHandler.isStream(i2)) {
          const a4 = this.attachmentsHandler.getBlobFromStream(i2, o2.knownLength);
          e7.set(s2, a4, o2.filename);
        }
      }
    };
    Array.isArray(a2) ? a2.forEach(function(a3) {
      t2(e5, a3, n2);
    }) : t2(e5, a2, n2);
  }
  addCommonPropertyToFD(e5, a2, n2) {
    const t2 = (e6, a3) => {
      if (this.isFormDataPackage(n2)) return "object" == typeof a3 ? (console.warn('The received value is an object. \n"JSON.Stringify" will be used to avoid TypeError \nTo remove this warning: \nConsider switching to built-in FormData or converting the value on your own.\n'), n2.append(e6, JSON.stringify(a3))) : n2.append(e6, a3);
      if ("string" == typeof a3) return n2.append(e6, a3);
      if (void 0 !== typeof Blob && a3 instanceof Blob) return n2.append(e6, a3);
      throw Ni.getUserDataError("Unknown value type for Form Data. String or Blob expected", "Browser compliant FormData allows only string or Blob values for properties that are not attachments.");
    };
    Array.isArray(a2) ? a2.forEach(function(a3) {
      t2(e5, a3);
    }) : null != a2 && t2(e5, a2);
  }
};
var Hi = class {
  request;
  static SUBACCOUNT_HEADER = "X-Mailgun-On-Behalf-Of";
  constructor(e5) {
    this.request = e5;
  }
  list(e5) {
    return this.request.get("/v5/accounts/subaccounts", e5).then((e6) => e6.body);
  }
  get(e5) {
    return this.request.get(`/v5/accounts/subaccounts/${e5}`).then((e6) => e6.body);
  }
  create(e5) {
    return this.request.postWithFD("/v5/accounts/subaccounts", { name: e5 }).then((e6) => e6.body);
  }
  enable(e5) {
    return this.request.post(`/v5/accounts/subaccounts/${e5}/enable`).then((e6) => e6.body);
  }
  disable(e5) {
    return this.request.post(`/v5/accounts/subaccounts/${e5}/disable`).then((e6) => e6.body);
  }
};
var Vi = class {
  username;
  key;
  url;
  timeout;
  headers;
  formDataBuilder;
  maxBodyLength;
  proxy;
  constructor(e5, a2) {
    this.username = e5.username, this.key = e5.key, this.url = e5.url, this.timeout = e5.timeout, this.headers = this.makeHeadersFromObject(e5.headers), this.formDataBuilder = new Wi(a2), this.maxBodyLength = 52428800, this.proxy = e5?.proxy;
  }
  async request(e5, a2, n2) {
    const t2 = { ...n2 };
    delete t2?.headers;
    const s2 = this.joinAndTransformHeaders(n2), i2 = { ...t2 };
    if (t2?.query && Object.getOwnPropertyNames(t2?.query).length > 0 && (i2.params = new URLSearchParams(t2.query), delete i2.query), t2?.body) {
      const e6 = t2?.body;
      i2.data = e6, delete i2.body;
    }
    let o2;
    const r2 = j(this.url, a2);
    try {
      o2 = await ji.request({ method: e5.toLocaleUpperCase(), timeout: this.timeout, url: r2, headers: s2, ...i2, maxBodyLength: this.maxBodyLength, proxy: this.proxy });
    } catch (e6) {
      const a3 = e6;
      throw new Ni({ status: a3?.response?.status || 400, statusText: a3?.response?.statusText || a3.code, body: a3?.response?.data || a3.message });
    }
    return await this.getResponseBody(o2);
  }
  async getResponseBody(e5) {
    const a2 = { body: {}, status: e5?.status };
    if ("string" == typeof e5.data) {
      if ("Mailgun Magnificent API" === e5.data) throw new Ni({ status: 400, statusText: "Incorrect url", body: e5.data });
      a2.body = { message: e5.data };
    } else a2.body = e5.data;
    return a2;
  }
  joinAndTransformHeaders(e5) {
    const a2 = new Bi(), n2 = y.encode(`${this.username}:${this.key}`);
    a2.setAuthorization(`Basic ${n2}`), a2.set(this.headers);
    const t2 = e5 && e5.headers, s2 = this.makeHeadersFromObject(t2);
    return a2.set(s2), a2;
  }
  makeHeadersFromObject(e5 = {}) {
    let a2 = new Bi();
    return a2 = Object.entries(e5).reduce((e6, a3) => {
      const [n2, t2] = a3;
      return e6.set(n2, t2), e6;
    }, a2), a2;
  }
  setSubaccountHeader(e5) {
    const a2 = this.makeHeadersFromObject({ ...this.headers, [Hi.SUBACCOUNT_HEADER]: e5 });
    this.headers.set(a2);
  }
  resetSubaccountHeader() {
    this.headers.delete(Hi.SUBACCOUNT_HEADER);
  }
  query(e5, a2, n2, t2) {
    return this.request(e5, a2, { query: n2, ...t2 });
  }
  command(e5, a2, n2, t2, s2 = true) {
    let i2 = {};
    s2 && (i2 = { "Content-Type": "application/x-www-form-urlencoded" });
    const o2 = { ...i2, body: n2, ...t2 };
    return this.request(e5, a2, o2);
  }
  get(e5, a2, n2) {
    return this.query("get", e5, a2, n2);
  }
  post(e5, a2, n2) {
    return this.command("post", e5, a2, n2);
  }
  postWithFD(e5, a2) {
    const n2 = this.formDataBuilder.createFormData(a2);
    return this.command("post", e5, n2, { headers: { "Content-Type": "multipart/form-data" } }, false);
  }
  putWithFD(e5, a2) {
    const n2 = this.formDataBuilder.createFormData(a2);
    return this.command("put", e5, n2, { headers: { "Content-Type": "multipart/form-data" } }, false);
  }
  patchWithFD(e5, a2) {
    const n2 = this.formDataBuilder.createFormData(a2);
    return this.command("patch", e5, n2, { headers: { "Content-Type": "multipart/form-data" } }, false);
  }
  put(e5, a2, n2) {
    return this.command("put", e5, a2, n2);
  }
  delete(e5, a2) {
    return this.command("delete", e5, a2);
  }
};
var Gi = class {
  name;
  require_tls;
  skip_verification;
  state;
  wildcard;
  spam_action;
  created_at;
  smtp_password;
  smtp_login;
  type;
  receiving_dns_records;
  sending_dns_records;
  id;
  is_disabled;
  web_prefix;
  web_scheme;
  use_automatic_sender_security;
  dkim_host;
  mailfrom_host;
  constructor(e5, a2, n2) {
    this.name = e5.name, this.require_tls = e5.require_tls, this.skip_verification = e5.skip_verification, this.state = e5.state, this.wildcard = e5.wildcard, this.spam_action = e5.spam_action, this.created_at = new Date(e5.created_at), this.smtp_password = e5.smtp_password, this.smtp_login = e5.smtp_login, this.type = e5.type, this.receiving_dns_records = a2 || null, this.sending_dns_records = n2 || null, this.id = e5.id, this.is_disabled = e5.is_disabled, this.web_prefix = e5.web_prefix, this.web_scheme = e5.web_scheme, this.use_automatic_sender_security = e5.use_automatic_sender_security;
    const t2 = ["dkim_host", "mailfrom_host"].reduce((a3, n3) => {
      if (e5[n3]) {
        a3[n3] = e5[n3];
      }
      return a3;
    }, {});
    Object.assign(this, t2);
  }
};
var Ji = class {
  request;
  domainCredentials;
  domainTemplates;
  domainTags;
  domainTracking;
  logger;
  constructor(e5, a2, n2, t2, s2, i2 = console) {
    this.request = e5, this.domainCredentials = a2, this.domainTemplates = n2, this.domainTags = t2, this.logger = i2, this.domainTracking = s2;
  }
  _handleBoolValues(e5) {
    const a2 = e5, n2 = Object.keys(a2).reduce((e6, n3) => {
      const t2 = n3;
      if ("boolean" == typeof a2[t2]) {
        const n4 = a2[t2];
        e6[t2] = "true" === n4.toString() ? "true" : "false";
      }
      return e6;
    }, {});
    return { ...e5, ...n2 };
  }
  _parseMessage(e5) {
    return e5.body;
  }
  parseDomainList(e5) {
    return e5.body && e5.body.items ? e5.body.items.map(function(e6) {
      return new Gi(e6);
    }) : [];
  }
  _parseDomain(e5) {
    return new Gi(e5.body.domain, e5.body.receiving_dns_records, e5.body.sending_dns_records);
  }
  list(e5) {
    return this.request.get("/v4/domains", e5).then((e6) => this.parseDomainList(e6));
  }
  get(e5, a2) {
    const n2 = a2 ? { "h:extended": a2?.extended ?? false, "h:with_dns": a2?.with_dns ?? true } : {};
    return this.request.get(`/v4/domains/${e5}`, n2).then((e6) => this._parseDomain(e6));
  }
  create(e5) {
    const a2 = this._handleBoolValues(e5);
    return this.request.postWithFD("/v4/domains", a2).then((e6) => this._parseDomain(e6));
  }
  update(e5, a2) {
    const n2 = this._handleBoolValues(a2);
    return this.request.putWithFD(`/v4/domains/${e5}`, n2).then((e6) => this._parseDomain(e6));
  }
  verify(e5) {
    return this.request.put(`/v4/domains/${e5}/verify`).then((e6) => this._parseDomain(e6));
  }
  destroy(e5) {
    return this.request.delete(`/v3/domains/${e5}`).then((e6) => this._parseMessage(e6));
  }
  getConnection(e5) {
    return this.request.get(`/v3/domains/${e5}/connection`).then((e6) => e6).then((e6) => e6.body);
  }
  updateConnection(e5, a2) {
    return this.request.put(`/v3/domains/${e5}/connection`, a2).then((e6) => e6).then((e6) => e6.body);
  }
  getTracking(e5) {
    return this.logger.warn("\n      'domains.getTracking' method is deprecated, and will be removed. Please use 'domains.domainTracking.getTracking' instead.\n    "), this.domainTracking.getTracking(e5);
  }
  updateTracking(e5, a2, n2) {
    return this.logger.warn("\n      'domains.updateTracking' method is deprecated, and will be removed. Please use 'domains.domainTracking.updateTracking' instead.\n    "), this.domainTracking.updateTracking(e5, a2, n2);
  }
  getIps(e5) {
    return this.logger.warn('"domains.getIps" method is deprecated and will be removed in the future releases.'), this.request.get(j("/v3/domains", e5, "ips")).then((e6) => e6?.body?.items);
  }
  assignIp(e5, a2) {
    return this.logger.warn('"domains.assignIp" method is deprecated and will be removed in the future releases.'), this.request.postWithFD(j("/v3/domains", e5, "ips"), { ip: a2 });
  }
  deleteIp(e5, a2) {
    return this.logger.warn('"domains.deleteIp" method is deprecated and will be moved into the IpsClient in the future releases.'), this.request.delete(j("/v3/domains", e5, "ips", a2));
  }
  linkIpPool(e5, a2) {
    return this.logger.warn('"domains.linkIpPool" method is deprecated, and will be removed in the future releases.'), this.request.postWithFD(j("/v3/domains", e5, "ips"), { pool_id: a2 });
  }
  unlinkIpPoll(e5, a2) {
    this.logger.warn('"domains.unlinkIpPoll" method is deprecated, and will be moved into the IpsClient in the future releases.');
    let n2 = "";
    if (a2.pool_id && a2.ip) throw Ni.getUserDataError("Too much data for replacement", "Please specify either pool_id or ip (not both)");
    return a2.pool_id ? n2 = `?pool_id=${a2.pool_id}` : a2.ip && (n2 = `?ip=${a2.ip}`), this.request.delete(j("/v3/domains", e5, "ips", "ip_pool", n2));
  }
  updateDKIMAuthority(e5, a2) {
    return this.request.put(`/v3/domains/${e5}/dkim_authority`, {}, { query: `self=${a2.self}` }).then((e6) => e6).then((e6) => e6.body);
  }
  async updateDKIMSelector(e5, a2) {
    const n2 = await this.request.put(`/v3/domains/${e5}/dkim_selector`, {}, { query: `dkim_selector=${a2.dkimSelector}` });
    return { status: n2.status, message: n2?.body?.message };
  }
  updateWebPrefix(e5, a2) {
    return this.logger.warn('"domains.updateWebPrefix" method is deprecated, please use domains.update to set new "web_prefix". Current method will be removed in the future releases.'), this.request.put(`/v3/domains/${e5}/web_prefix`, {}, { query: `web_prefix=${a2.webPrefix}` }).then((e6) => e6);
  }
};
var Ki = class {
  request;
  constructor(e5) {
    e5 && (this.request = e5);
  }
  parsePage(e5, a2, n2, t2) {
    const s2 = new URL(a2), { searchParams: i2 } = s2, o2 = a2 && "string" == typeof a2 && a2.split(n2).pop() || "";
    let r2 = null;
    return t2 && (r2 = i2.has(t2) ? i2.get(t2) : void 0), { id: e5, page: "?" === n2 ? `?${o2}` : o2, iteratorPosition: r2, url: a2 };
  }
  parsePageLinks(e5, a2, n2) {
    return Object.entries(e5.body.paging).reduce((e6, [t2, s2]) => (e6[t2] = this.parsePage(t2, s2, a2, n2), e6), {});
  }
  updateUrlAndQuery(e5, a2) {
    let n2 = e5;
    const t2 = { ...a2 };
    return t2.page && (n2 = j(e5, t2.page), delete t2.page), { url: n2, updatedQuery: t2 };
  }
  async requestListWithPages(e5, a2, n2) {
    const { url: t2, updatedQuery: s2 } = this.updateUrlAndQuery(e5, a2);
    if (this.request) {
      const e6 = await this.request.get(t2, s2);
      return this.parseList(e6, n2);
    }
    throw new Ni({ status: 500, statusText: "Request property is empty", body: { message: "" } });
  }
};
var Qi = class extends Ki {
  request;
  constructor(e5) {
    super(e5), this.request = e5;
  }
  parseList(e5) {
    const a2 = {};
    return a2.items = e5.body.items, a2.pages = this.parsePageLinks(e5, "/"), a2.status = e5.status, a2;
  }
  async get(e5, a2) {
    return this.requestListWithPages(j("/v3", e5, "events"), a2);
  }
};
var Yi = class {
  start;
  end;
  resolution;
  stats;
  constructor(e5) {
    this.start = new Date(e5.start), this.end = new Date(e5.end), this.resolution = e5.resolution, this.stats = e5.stats.map(function(e6) {
      const a2 = { ...e6 };
      return a2.time = new Date(e6.time), a2;
    });
  }
};
var Xi = class {
  request;
  logger;
  constructor(e5, a2 = console) {
    this.request = e5, this.logger = a2;
  }
  convertDateToUTC(e5, a2) {
    return this.logger.warn(`Date:"${a2}" was auto-converted to UTC time zone.
Value "${a2.toUTCString()}" will be used for request.
Consider using string type for property "${e5}" to avoid auto-converting`), [e5, a2.toUTCString()];
  }
  prepareSearchParams(e5) {
    let a2 = [];
    return "object" == typeof e5 && Object.keys(e5).length && (a2 = Object.entries(e5).reduce((e6, a3) => {
      const [n2, t2] = a3;
      if (Array.isArray(t2) && t2.length) {
        const a4 = t2.map((e7) => [n2, e7]);
        return [...e6, ...a4];
      }
      return t2 instanceof Date ? (e6.push(this.convertDateToUTC(n2, t2)), e6) : ("string" == typeof t2 && e6.push([n2, t2]), e6);
    }, [])), a2;
  }
  parseStats(e5) {
    return new Yi(e5.body);
  }
  getDomain(e5, a2) {
    const n2 = this.prepareSearchParams(a2);
    return this.request.get(j("/v3", e5, "stats/total"), n2).then(this.parseStats);
  }
  getAccount(e5) {
    const a2 = this.prepareSearchParams(e5);
    return this.request.get("/v3/stats/total", a2).then(this.parseStats);
  }
};
var Zi;
var eo;
var ao;
var no;
!function(e5) {
  e5.HOUR = "hour", e5.DAY = "day", e5.MONTH = "month";
}(Zi = Zi || (Zi = {})), function(e5) {
  e5.BOUNCES = "bounces", e5.COMPLAINTS = "complaints", e5.UNSUBSCRIBES = "unsubscribes", e5.WHITELISTS = "whitelists";
}(eo = eo || (eo = {})), function(e5) {
  e5.CLICKED = "clicked", e5.COMPLAINED = "complained", e5.DELIVERED = "delivered", e5.OPENED = "opened", e5.PERMANENT_FAIL = "permanent_fail", e5.TEMPORARY_FAIL = "temporary_fail", e5.UNSUBSCRIBED = "unsubscribe";
}(ao = ao || (ao = {})), function(e5) {
  e5.YES = "yes", e5.NO = "no";
}(no = no || (no = {}));
var to = class {
  type;
  constructor(e5) {
    this.type = e5;
  }
};
var so = class extends to {
  address;
  code;
  error;
  created_at;
  constructor(e5) {
    super(eo.BOUNCES), this.address = e5.address, this.code = +e5.code, this.error = e5.error, this.created_at = new Date(e5.created_at);
  }
};
var io = class extends to {
  address;
  created_at;
  constructor(e5) {
    super(eo.COMPLAINTS), this.address = e5.address, this.created_at = new Date(e5.created_at);
  }
};
var oo = class extends to {
  address;
  tags;
  created_at;
  constructor(e5) {
    super(eo.UNSUBSCRIBES), this.address = e5.address, this.tags = e5.tags, this.created_at = new Date(e5.created_at);
  }
};
var ro = class extends to {
  value;
  reason;
  createdAt;
  constructor(e5) {
    super(eo.WHITELISTS), this.value = e5.value, this.reason = e5.reason, this.createdAt = new Date(e5.createdAt);
  }
};
var co = { headers: { "Content-Type": "application/json" } };
var po = class extends Ki {
  request;
  models;
  constructor(e5) {
    super(e5), this.request = e5, this.models = { bounces: so, complaints: io, unsubscribes: oo, whitelists: ro };
  }
  parseList(e5, a2) {
    const n2 = {};
    return n2.items = e5.body.items?.map((e6) => new a2(e6)) || [], n2.pages = this.parsePageLinks(e5, "?", "address"), n2.status = e5.status, n2;
  }
  _parseItem(e5, a2) {
    return new a2(e5);
  }
  createWhiteList(e5, a2, n2) {
    if (n2) throw Ni.getUserDataError("Data property should be an object", "Whitelist's creation process does not support multiple creations. Data property should be an object");
    return this.request.postWithFD(j("v3", e5, "whitelists"), a2).then(this.prepareResponse);
  }
  createUnsubscribe(e5, a2) {
    if (Array.isArray(a2)) {
      if (a2.some((e6) => e6.tag)) throw Ni.getUserDataError("Tag property should not be used for creating multiple unsubscribes.", "Tag property can be used only if one unsubscribe provided as second argument of create method. Please use tags instead.");
      return this.request.post(j("v3", e5, "unsubscribes"), JSON.stringify(a2), co).then(this.prepareResponse);
    }
    if (a2?.tags) throw Ni.getUserDataError("Tags property should not be used for creating one unsubscribe.", "Tags property can be used if you provides an array of unsubscribes as second argument of create method. Please use tag instead");
    if (Array.isArray(a2.tag)) throw Ni.getUserDataError("Tag property can not be an array", "Please use array of unsubscribes as second argument of create method to be able to provide few tags");
    return this.request.postWithFD(j("v3", e5, "unsubscribes"), a2).then(this.prepareResponse);
  }
  getModel(e5) {
    if (e5 in this.models) return this.models[e5];
    throw Ni.getUserDataError("Unknown type value", "Type may be only one of [bounces, complaints, unsubscribes, whitelists]");
  }
  prepareResponse(e5) {
    return { message: e5.body.message, type: e5.body.type || "", value: e5.body.value || "", status: e5.status };
  }
  async list(e5, a2, n2) {
    const t2 = this.getModel(a2);
    return this.requestListWithPages(j("v3", e5, a2), n2, t2);
  }
  get(e5, a2, n2) {
    const t2 = this.getModel(a2);
    return this.request.get(j("v3", e5, a2, encodeURIComponent(n2))).then((e6) => this._parseItem(e6.body, t2));
  }
  create(e5, a2, n2) {
    let t2;
    this.getModel(a2);
    const s2 = Array.isArray(n2);
    return "whitelists" === a2 ? this.createWhiteList(e5, n2, s2) : "unsubscribes" === a2 ? this.createUnsubscribe(e5, n2) : (t2 = s2 ? [...n2] : [n2], this.request.post(j("v3", e5, a2), JSON.stringify(t2), co).then(this.prepareResponse));
  }
  destroy(e5, a2, n2) {
    return this.getModel(a2), this.request.delete(j("v3", e5, a2, encodeURIComponent(n2))).then((e6) => ({ message: e6.body.message, value: e6.body.value || "", address: e6.body.address || "", status: e6.status }));
  }
};
var lo = class {
  id;
  url;
  urls;
  constructor(e5, a2, n2) {
    this.id = e5, this.url = a2, this.urls = n2;
  }
};
var uo = class {
  request;
  constructor(e5) {
    this.request = e5;
  }
  _parseWebhookList(e5) {
    return e5.body.webhooks;
  }
  _parseWebhookWithID(e5) {
    return function(a2) {
      const n2 = a2?.body?.webhook;
      let t2 = n2?.url, s2 = n2?.urls;
      return t2 || (t2 = s2 && s2.length ? s2[0] : void 0), s2 && 0 !== s2.length || !t2 || (s2 = [t2]), new lo(e5, t2, s2);
    };
  }
  _parseWebhookTest(e5) {
    return { code: e5.body.code, message: e5.body.message };
  }
  list(e5, a2) {
    return this.request.get(j("/v3/domains", e5, "webhooks"), a2).then(this._parseWebhookList);
  }
  get(e5, a2) {
    return this.request.get(j("/v3/domains", e5, "webhooks", a2)).then(this._parseWebhookWithID(a2));
  }
  create(e5, a2, n2, t2 = false) {
    return t2 ? this.request.putWithFD(j("/v3/domains", e5, "webhooks", a2, "test"), { url: n2 }).then(this._parseWebhookTest) : this.request.postWithFD(j("/v3/domains", e5, "webhooks"), { id: a2, url: n2 }).then(this._parseWebhookWithID(a2));
  }
  update(e5, a2, n2) {
    return this.request.putWithFD(j("/v3/domains", e5, "webhooks", a2), { url: n2 }).then(this._parseWebhookWithID(a2));
  }
  destroy(e5, a2) {
    return this.request.delete(j("/v3/domains", e5, "webhooks", a2)).then(this._parseWebhookWithID(a2));
  }
};
var mo = class {
  request;
  constructor(e5) {
    this.request = e5;
  }
  prepareBooleanValues(e5) {
    const a2 = /* @__PURE__ */ new Set(["o:testmode", "t:text", "o:dkim", "o:tracking", "o:tracking-clicks", "o:tracking-opens", "o:require-tls", "o:skip-verification"]);
    if (!e5 || 0 === Object.keys(e5).length) throw Ni.getUserDataError("Message data object can not be empty", "Message data object can not be empty");
    return Object.keys(e5).reduce((n2, t2) => (a2.has(t2) && "boolean" == typeof e5[t2] ? n2[t2] = e5[t2] ? "yes" : "no" : n2[t2] = e5[t2], n2), {});
  }
  _parseResponse(e5) {
    return { status: e5.status, ...e5.body };
  }
  create(e5, a2) {
    if (a2.message) return this.request.postWithFD(`/v3/${e5}/messages.mime`, a2).then(this._parseResponse);
    const n2 = this.prepareBooleanValues(a2);
    return this.request.postWithFD(`/v3/${e5}/messages`, n2).then(this._parseResponse);
  }
};
var ho = class {
  request;
  constructor(e5) {
    this.request = e5;
  }
  list(e5) {
    return this.request.get("/v3/routes", e5).then((e6) => e6.body.items);
  }
  get(e5) {
    return this.request.get(`/v3/routes/${e5}`).then((e6) => e6.body.route);
  }
  create(e5) {
    return this.request.postWithFD("/v3/routes", e5).then((e6) => e6.body.route);
  }
  update(e5, a2) {
    return this.request.putWithFD(`/v3/routes/${e5}`, a2).then((e6) => e6.body);
  }
  destroy(e5) {
    return this.request.delete(`/v3/routes/${e5}`).then((e6) => e6.body);
  }
};
var fo = class {
  multipleValidation;
  request;
  constructor(e5, a2) {
    this.request = e5, this.multipleValidation = a2;
  }
  async get(e5) {
    const a2 = { address: e5 };
    return (await this.request.get("/v4/address/validate", a2)).body;
  }
};
var xo = class {
  request;
  constructor(e5) {
    this.request = e5;
  }
  async list(e5) {
    const a2 = await this.request.get("/v3/ips", e5);
    return this.parseIpsResponse(a2);
  }
  async get(e5) {
    const a2 = await this.request.get(`/v3/ips/${e5}`);
    return this.parseIpsResponse(a2);
  }
  parseIpsResponse(e5) {
    return e5.body;
  }
};
var vo = class {
  request;
  constructor(e5) {
    this.request = e5;
  }
  list() {
    return this.request.get("/v1/ip_pools").then((e5) => this.parseIpPoolsResponse(e5));
  }
  async create(e5) {
    const a2 = await this.request.postWithFD("/v1/ip_pools", e5);
    return { status: a2.status, ...a2.body };
  }
  async update(e5, a2) {
    const n2 = await this.request.patchWithFD(`/v1/ip_pools/${e5}`, a2);
    return { status: n2.status, ...n2.body };
  }
  async delete(e5, a2) {
    const n2 = await this.request.delete(`/v1/ip_pools/${e5}`, a2);
    return { status: n2.status, ...n2.body };
  }
  parseIpPoolsResponse(e5) {
    return { status: e5.status, ...e5.body };
  }
};
var bo = class extends Ki {
  baseRoute;
  request;
  members;
  constructor(e5, a2) {
    super(e5), this.request = e5, this.baseRoute = "/v3/lists", this.members = a2;
  }
  parseValidationResult(e5, a2) {
    return { status: e5, validationResult: { ...a2, created_at: new Date(1e3 * a2.created_at) } };
  }
  parseList(e5) {
    const a2 = {};
    return a2.items = e5.body.items, a2.pages = this.parsePageLinks(e5, "?", "address"), a2.status = e5.status, a2;
  }
  async list(e5) {
    return this.requestListWithPages(`${this.baseRoute}/pages`, e5);
  }
  get(e5) {
    return this.request.get(`${this.baseRoute}/${e5}`).then((e6) => e6.body.list);
  }
  create(e5) {
    return this.request.postWithFD(this.baseRoute, e5).then((e6) => e6.body.list);
  }
  update(e5, a2) {
    return this.request.putWithFD(`${this.baseRoute}/${e5}`, a2).then((e6) => e6.body.list);
  }
  destroy(e5) {
    return this.request.delete(`${this.baseRoute}/${e5}`).then((e6) => e6.body);
  }
  validate(e5) {
    return this.request.post(`${this.baseRoute}/${e5}/validate`, {}).then((e6) => ({ status: e6.status, ...e6.body }));
  }
  validationResult(e5) {
    return this.request.get(`${this.baseRoute}/${e5}/validate`).then((e6) => this.parseValidationResult(e6.status, e6.body));
  }
  cancelValidation(e5) {
    return this.request.delete(`${this.baseRoute}/${e5}/validate`).then((e6) => ({ status: e6.status, message: e6.body.message }));
  }
};
var go = class extends Ki {
  baseRoute;
  request;
  constructor(e5) {
    super(e5), this.request = e5, this.baseRoute = "/v3/lists";
  }
  checkAndUpdateData(e5) {
    const a2 = { ...e5 };
    return "object" == typeof e5.vars && (a2.vars = JSON.stringify(a2.vars)), "boolean" == typeof e5.subscribed && (a2.subscribed = e5.subscribed ? "yes" : "no"), a2;
  }
  parseList(e5) {
    const a2 = {};
    return a2.items = e5.body.items, a2.pages = this.parsePageLinks(e5, "?", "address"), a2;
  }
  async listMembers(e5, a2) {
    return this.requestListWithPages(`${this.baseRoute}/${e5}/members/pages`, a2);
  }
  getMember(e5, a2) {
    return this.request.get(`${this.baseRoute}/${e5}/members/${a2}`).then((e6) => e6.body.member);
  }
  createMember(e5, a2) {
    const n2 = this.checkAndUpdateData(a2);
    return this.request.postWithFD(`${this.baseRoute}/${e5}/members`, n2).then((e6) => e6.body.member);
  }
  createMembers(e5, a2) {
    const n2 = { members: Array.isArray(a2.members) ? JSON.stringify(a2.members) : a2.members, upsert: a2.upsert };
    return this.request.postWithFD(`${this.baseRoute}/${e5}/members.json`, n2).then((e6) => e6.body);
  }
  updateMember(e5, a2, n2) {
    const t2 = this.checkAndUpdateData(n2);
    return this.request.putWithFD(`${this.baseRoute}/${e5}/members/${a2}`, t2).then((e6) => e6.body.member);
  }
  destroyMember(e5, a2) {
    return this.request.delete(`${this.baseRoute}/${e5}/members/${a2}`).then((e6) => e6.body);
  }
};
var yo = class {
  baseRoute;
  request;
  constructor(e5) {
    this.request = e5, this.baseRoute = "/v3/domains/";
  }
  _parseDomainCredentialsList(e5) {
    return { items: e5.body.items, totalCount: e5.body.total_count };
  }
  _parseMessageResponse(e5) {
    return { status: e5.status, message: e5.body.message };
  }
  _parseDeletedResponse(e5) {
    return { status: e5.status, message: e5.body.message, spec: e5.body.spec };
  }
  list(e5, a2) {
    return this.request.get(j(this.baseRoute, e5, "/credentials"), a2).then((e6) => this._parseDomainCredentialsList(e6));
  }
  create(e5, a2) {
    return this.request.postWithFD(`${this.baseRoute}${e5}/credentials`, a2).then((e6) => this._parseMessageResponse(e6));
  }
  update(e5, a2, n2) {
    return this.request.putWithFD(`${this.baseRoute}${e5}/credentials/${a2}`, n2).then((e6) => this._parseMessageResponse(e6));
  }
  destroy(e5, a2) {
    return this.request.delete(`${this.baseRoute}${e5}/credentials/${a2}`).then((e6) => this._parseDeletedResponse(e6));
  }
};
var wo = class {
  createdAt;
  id;
  quantity;
  recordsProcessed;
  status;
  downloadUrl;
  responseStatusCode;
  summary;
  constructor(e5, a2) {
    this.createdAt = new Date(e5.created_at), this.id = e5.id, this.quantity = e5.quantity, this.recordsProcessed = e5.records_processed, this.status = e5.status, this.responseStatusCode = a2, e5.download_url && (this.downloadUrl = { csv: e5.download_url?.csv, json: e5.download_url?.json }), e5.summary && (this.summary = { result: { catchAll: e5.summary.result.catch_all, deliverable: e5.summary.result.deliverable, doNotSend: e5.summary.result.do_not_send, undeliverable: e5.summary.result.undeliverable, unknown: e5.summary.result.unknown }, risk: { high: e5.summary.risk.high, low: e5.summary.risk.low, medium: e5.summary.risk.medium, unknown: e5.summary.risk.unknown } });
  }
};
var _o = class extends Ki {
  request;
  attachmentsHandler;
  constructor(e5) {
    super(), this.request = e5, this.attachmentsHandler = new $i();
  }
  handleResponse(e5) {
    return { status: e5.status, ...e5?.body };
  }
  parseList(e5) {
    const a2 = {};
    return a2.jobs = e5.body.jobs.map((a3) => new wo(a3, e5.status)), a2.pages = this.parsePageLinks(e5, "?", "pivot"), a2.total = e5.body.total, a2.status = e5.status, a2;
  }
  async list(e5) {
    return this.requestListWithPages("/v4/address/validate/bulk", e5);
  }
  async get(e5) {
    const a2 = await this.request.get(`/v4/address/validate/bulk/${e5}`);
    return new wo(a2.body, a2.status);
  }
  convertToExpectedShape(e5) {
    let a2;
    return a2 = this.attachmentsHandler.isBuffer(e5.file) ? { multipleValidationFile: e5.file } : "string" == typeof e5.file ? { multipleValidationFile: { data: e5.file } } : (this.attachmentsHandler.isStream(e5.file), { multipleValidationFile: e5.file }), a2;
  }
  async create(e5, a2) {
    if (!a2 || !a2.file) throw Ni.getUserDataError('"file" property expected.', 'Make sure second argument has "file" property.');
    const n2 = this.convertToExpectedShape(a2), t2 = await this.request.postWithFD(`/v4/address/validate/bulk/${e5}`, n2);
    return this.handleResponse(t2);
  }
  async destroy(e5) {
    const a2 = await this.request.delete(`/v4/address/validate/bulk/${e5}`);
    return this.handleResponse(a2);
  }
};
var ko = class {
  name;
  description;
  createdAt;
  createdBy;
  id;
  version;
  versions;
  constructor(e5) {
    this.name = e5.name, this.description = e5.description, this.createdAt = e5.createdAt ? new Date(e5.createdAt) : "", this.createdBy = e5.createdBy, this.id = e5.id, e5.version && (this.version = e5.version, this.version && e5.version.createdAt && (this.version.createdAt = new Date(e5.version.createdAt))), e5.versions && e5.versions.length && (this.versions = e5.versions.map((e6) => {
      const a2 = { ...e6 };
      return a2.createdAt = new Date(e6.createdAt), a2;
    }));
  }
};
var jo = class extends Ki {
  baseRoute;
  request;
  constructor(e5) {
    super(e5), this.request = e5, this.baseRoute = "/v3/";
  }
  parseCreationResponse(e5) {
    return new ko(e5.body.template);
  }
  parseCreationVersionResponse(e5) {
    const a2 = {};
    return a2.status = e5.status, a2.message = e5.body.message, e5.body && e5.body.template && (a2.template = new ko(e5.body.template)), a2;
  }
  parseMutationResponse(e5) {
    const a2 = {};
    return a2.status = e5.status, a2.message = e5.body.message, e5.body && e5.body.template && (a2.templateName = e5.body.template.name), a2;
  }
  parseNotificationResponse(e5) {
    const a2 = {};
    return a2.status = e5.status, a2.message = e5.body.message, a2;
  }
  parseMutateTemplateVersionResponse(e5) {
    const a2 = {};
    return a2.status = e5.status, a2.message = e5.body.message, e5.body.template && (a2.templateName = e5.body.template.name, a2.templateVersion = { tag: e5.body.template.version.tag }), a2;
  }
  parseList(e5) {
    const a2 = {};
    return a2.items = e5.body.items.map((e6) => new ko(e6)), a2.pages = this.parsePageLinks(e5, "?", "p"), a2.status = e5.status, a2;
  }
  parseListTemplateVersions(e5) {
    const a2 = {};
    return a2.template = new ko(e5.body.template), a2.pages = this.parsePageLinks(e5, "?", "p"), a2;
  }
  async list(e5, a2) {
    return this.requestListWithPages(j(this.baseRoute, e5, "/templates"), a2);
  }
  get(e5, a2, n2) {
    return this.request.get(j(this.baseRoute, e5, "/templates/", a2), n2).then((e6) => new ko(e6.body.template));
  }
  create(e5, a2) {
    return this.request.postWithFD(j(this.baseRoute, e5, "/templates"), a2).then((e6) => this.parseCreationResponse(e6));
  }
  update(e5, a2, n2) {
    return this.request.putWithFD(j(this.baseRoute, e5, "/templates/", a2), n2).then((e6) => this.parseMutationResponse(e6));
  }
  destroy(e5, a2) {
    return this.request.delete(j(this.baseRoute, e5, "/templates/", a2)).then((e6) => this.parseMutationResponse(e6));
  }
  destroyAll(e5) {
    return this.request.delete(j(this.baseRoute, e5, "/templates")).then((e6) => this.parseNotificationResponse(e6));
  }
  listVersions(e5, a2, n2) {
    return this.request.get(j(this.baseRoute, e5, "/templates", a2, "/versions"), n2).then((e6) => this.parseListTemplateVersions(e6));
  }
  getVersion(e5, a2, n2) {
    return this.request.get(j(this.baseRoute, e5, "/templates/", a2, "/versions/", n2)).then((e6) => new ko(e6.body.template));
  }
  createVersion(e5, a2, n2) {
    return this.request.postWithFD(j(this.baseRoute, e5, "/templates/", a2, "/versions"), n2).then((e6) => this.parseCreationVersionResponse(e6));
  }
  updateVersion(e5, a2, n2, t2) {
    return this.request.putWithFD(j(this.baseRoute, e5, "/templates/", a2, "/versions/", n2), t2).then((e6) => this.parseMutateTemplateVersionResponse(e6));
  }
  destroyVersion(e5, a2, n2) {
    return this.request.delete(j(this.baseRoute, e5, "/templates/", a2, "/versions/", n2)).then((e6) => this.parseMutateTemplateVersionResponse(e6));
  }
};
var Ro = class {
  tag;
  description;
  "first-seen";
  "last-seen";
  constructor(e5) {
    this.tag = e5.tag, this.description = e5.description, this["first-seen"] = new Date(e5["first-seen"]), this["last-seen"] = new Date(e5["last-seen"]);
  }
};
var So = class {
  tag;
  description;
  start;
  end;
  resolution;
  stats;
  constructor(e5) {
    this.tag = e5.body.tag, this.description = e5.body.description, this.start = new Date(e5.body.start), this.end = new Date(e5.body.end), this.resolution = e5.body.resolution, this.stats = e5.body.stats.map(function(e6) {
      return { ...e6, time: new Date(e6.time) };
    });
  }
};
var Eo = class extends Ki {
  baseRoute;
  request;
  constructor(e5) {
    super(e5), this.request = e5, this.baseRoute = "/v3/";
  }
  parseList(e5) {
    const a2 = {};
    return a2.items = e5.body.items.map((e6) => new Ro(e6)), a2.pages = this.parsePageLinks(e5, "?", "tag"), a2.status = e5.status, a2;
  }
  _parseTagStatistic(e5) {
    return new So(e5);
  }
  async list(e5, a2) {
    return this.requestListWithPages(j(this.baseRoute, e5, "/tags"), a2);
  }
  get(e5, a2) {
    return this.request.get(j(this.baseRoute, e5, "/tags", a2)).then((e6) => new Ro(e6.body));
  }
  update(e5, a2, n2) {
    return this.request.put(j(this.baseRoute, e5, "/tags", a2), n2).then((e6) => e6.body);
  }
  destroy(e5, a2) {
    return this.request.delete(`${this.baseRoute}${e5}/tags/${a2}`).then((e6) => ({ message: e6.body.message, status: e6.status }));
  }
  statistic(e5, a2, n2) {
    return this.request.get(j(this.baseRoute, e5, "/tags", a2, "stats"), n2).then((e6) => this._parseTagStatistic(e6));
  }
  countries(e5, a2) {
    return this.request.get(j(this.baseRoute, e5, "/tags", a2, "stats/aggregates/countries")).then((e6) => e6.body);
  }
  providers(e5, a2) {
    return this.request.get(j(this.baseRoute, e5, "/tags", a2, "stats/aggregates/providers")).then((e6) => e6.body);
  }
  devices(e5, a2) {
    return this.request.get(j(this.baseRoute, e5, "/tags", a2, "stats/aggregates/devices")).then((e6) => e6.body);
  }
};
var To = class extends Ki {
  request;
  attributes;
  filters;
  logger;
  constructor(e5, a2, n2, t2 = console) {
    super(e5), this.request = e5, this.attributes = a2, this.filters = n2, this.logger = t2;
  }
  convertDateToUTC(e5, a2) {
    return this.logger.warn(`Date: "${a2}" was auto-converted to UTC time zone.
Value "${a2.toISOString()}" will be used for request.
Consider using string type for property "${e5}" to avoid auto-converting`), a2.toISOString();
  }
  prepareQueryData(e5) {
    const a2 = e5, n2 = Object.keys(a2).reduce((n3, t2) => {
      const s2 = t2;
      if (a2[s2] && "object" == typeof a2[s2]) {
        const a3 = e5[s2];
        n3[s2] = this.convertDateToUTC(s2, a3);
      }
      return n3;
    }, {});
    return { ...e5, ...n2 };
  }
  prepareResult(e5) {
    let a2 = {};
    return a2 = { ...this.prepareSeedList(e5.body), status: e5.status }, a2;
  }
  prepareSeedList(e5) {
    let a2;
    const n2 = { created_at: new Date(e5.created_at), updated_at: new Date(e5.updated_at), last_result_at: new Date(e5.last_result_at) };
    a2 = e5.Seeds ? e5.Seeds.map((e6) => {
      let a3 = {};
      const n3 = { created_at: new Date(e6.created_at), updated_at: new Date(e6.updated_at), max_email_count_hit_at: new Date(e6.max_email_count_hit_at), last_sent_to_at: new Date(e6.last_sent_to_at), last_delivered_at: new Date(e6.last_delivered_at) };
      return a3 = { ...e6, ...n3 }, a3;
    }) : null;
    const t2 = { ...e5, Seeds: a2, ...n2 };
    return delete t2.Id, t2;
  }
  parseList(e5) {
    const a2 = { items: [] };
    return a2.items = e5.body.items?.map((e6) => this.prepareSeedList(e6)), a2.pages = this.parsePageLinks(e5, "?", "address"), a2.status = e5.status, a2;
  }
  async list(e5) {
    const a2 = this.prepareQueryData(e5), n2 = await this.request.get("/v4/inbox/seedlists", a2);
    return { ...this.parseList(n2), status: 200 };
  }
  async get(e5) {
    const a2 = await this.request.get(`/v4/inbox/seedlists/${e5}`);
    return { ...this.prepareSeedList(a2.body.seedlist), status: a2.status };
  }
  async create(e5) {
    const a2 = await this.request.postWithFD("/v4/inbox/seedlists", e5);
    return this.prepareResult(a2);
  }
  async update(e5, a2) {
    const n2 = await this.request.put(`/v4/inbox/seedlists/${e5}`, a2);
    return this.prepareResult(n2);
  }
  async destroy(e5) {
    return this.request.delete(`/v4/inbox/seedlists/${e5}`);
  }
};
var qo = class {
  request;
  seedsLists;
  results;
  providers;
  constructor(e5, a2, n2, t2) {
    this.request = e5, this.seedsLists = a2, this.seedsLists = a2, this.results = n2, this.providers = t2;
  }
  async runTest(e5) {
    const a2 = await this.request.post("/v4/inbox/tests", e5);
    return { ...a2.body, status: a2.status };
  }
};
var Co = class extends Ki {
  request;
  attributes;
  filters;
  sharing;
  logger;
  constructor(e5, a2, n2, t2, s2 = console) {
    super(e5), this.request = e5, this.attributes = a2, this.filters = n2, this.sharing = t2, this.logger = s2;
  }
  convertDateToUTC(e5, a2) {
    return this.logger.warn(`Date: "${a2}" was auto-converted to UTC time zone.
Value "${a2.toISOString()}" will be used for request.
Consider using string type for property "${e5}" to avoid auto-converting`), a2.toISOString();
  }
  prepareQueryData(e5) {
    const a2 = e5, n2 = Object.keys(a2).reduce((n3, t2) => {
      const s2 = t2;
      if (a2[s2] && "object" == typeof a2[s2]) {
        const a3 = e5[s2];
        n3[s2] = this.convertDateToUTC(s2, a3);
      }
      return n3;
    }, {});
    return { ...e5, ...n2 };
  }
  prepareInboxPlacementsResult(e5) {
    let a2 = {};
    const n2 = { created_at: new Date(e5.created_at), updated_at: new Date(e5.updated_at), sharing_expires_at: new Date(e5.sharing_expires_at) };
    e5.Box && (a2 = { ...e5.Box, created_at: new Date(e5.Box.created_at), updated_at: new Date(e5.Box.updated_at), last_result_at: new Date(e5.Box.last_result_at) }, delete a2.ID);
    const t2 = { ...e5, Box: a2, ...n2, id: e5.Id };
    return delete t2.ID, t2;
  }
  parseList(e5) {
    const a2 = {};
    return a2.items = e5.body.items.map((e6) => this.prepareInboxPlacementsResult(e6)), a2.pages = this.parsePageLinks(e5, "?", "address"), a2.status = e5.status, a2;
  }
  async list(e5) {
    const a2 = this.prepareQueryData(e5), n2 = await this.request.get("/v4/inbox/results", a2);
    return this.parseList(n2);
  }
  async get(e5) {
    const a2 = await this.request.get(`/v4/inbox/results/${e5}`), n2 = this.prepareInboxPlacementsResult(a2.body.result);
    return { status: a2.status, inboxPlacementResult: n2 };
  }
  async destroy(e5) {
    const a2 = await this.request.delete(`/v4/inbox/results/${e5}`);
    return { status: a2.status, ...a2.body };
  }
  async getResultByShareId(e5) {
    const a2 = await this.request.get(`/v4/inbox/sharing/public/${e5}`), n2 = this.prepareInboxPlacementsResult(a2.body.result);
    return { status: a2.status, inboxPlacementResult: n2 };
  }
};
var Ao = class {
  request;
  path;
  constructor(e5, a2) {
    this.path = a2, this.request = e5;
  }
  async list() {
    const e5 = await this.request.get(this.path);
    return { items: e5.body.items, status: e5.status };
  }
  async get(e5) {
    const a2 = await this.request.get(`${this.path}/${e5}`);
    return { ...a2.body, status: a2.status };
  }
};
var Oo = class {
  request;
  path;
  constructor(e5, a2) {
    this.request = e5, this.path = a2;
  }
  async list() {
    const e5 = await this.request.get(this.path);
    return { status: e5.status, supported_filters: e5.body.supported_filters };
  }
};
var Fo = class {
  request;
  constructor(e5) {
    this.request = e5;
  }
  prepareInboxPlacementsResultSharing(e5) {
    const a2 = { expires_at: new Date(e5.expires_at) };
    return { ...e5, ...a2 };
  }
  async get(e5) {
    const a2 = await this.request.get(`/v4/inbox/sharing/${e5}`), n2 = this.prepareInboxPlacementsResultSharing(a2.body.sharing);
    return { status: a2.status, ...n2 };
  }
  async update(e5, a2) {
    const n2 = await this.request.put(`/v4/inbox/sharing/${e5}`, {}, { query: `enabled=${a2.enabled}` });
    return { ...this.prepareInboxPlacementsResultSharing(n2.body.sharing), status: n2.status };
  }
};
var Do = class {
  request;
  path;
  constructor(e5) {
    this.path = "/v4/inbox/providers", this.request = e5;
  }
  parseList(e5) {
    const a2 = {};
    return a2.items = e5.body.items.map((e6) => {
      const a3 = { created_at: new Date(e6.created_at), updated_at: new Date(e6.updated_at) };
      return { ...e6, ...a3 };
    }), a2.status = e5.status, a2;
  }
  async list() {
    const e5 = await this.request.get(this.path);
    return this.parseList(e5);
  }
};
var Po = class {
  request;
  logger;
  constructor(e5, a2 = console) {
    this.request = e5, this.logger = a2;
  }
  convertDateToUTC(e5, a2) {
    return this.logger.warn(`Date:"${a2}" was auto-converted to UTC time zone.
Value "${a2.toUTCString()}" will be used for request.
Consider using string type for property "${e5}" to avoid auto-converting`), a2.toUTCString();
  }
  prepareQuery(e5) {
    let a2, n2;
    if (e5) {
      const t2 = e5?.start, s2 = e5?.end;
      a2 = t2 instanceof Date ? this.convertDateToUTC("start", t2) : t2 ?? "", n2 = s2 && s2 instanceof Date ? this.convertDateToUTC("end", s2) : s2 ?? "";
    }
    return { ...e5, start: a2, end: n2 };
  }
  handleResponse(e5) {
    const a2 = e5.body, n2 = Date.parse(a2.start) ? new Date(a2.start) : null, t2 = Date.parse(a2.end) ? new Date(a2.end) : null;
    return { ...a2, status: e5.status, start: n2, end: t2 };
  }
  async getAccount(e5) {
    const a2 = this.prepareQuery(e5), n2 = await this.request.post("/v1/analytics/metrics", a2);
    return this.handleResponse(n2);
  }
  async getAccountUsage(e5) {
    const a2 = this.prepareQuery(e5), n2 = await this.request.post("/v1/analytics/usage/metrics", a2);
    return this.handleResponse(n2);
  }
};
var Bo = class {
  request;
  constructor(e5) {
    this.request = e5;
  }
  _parseTrackingSettings(e5) {
    return e5.body.tracking;
  }
  _parseTrackingUpdate(e5) {
    return e5.body;
  }
  _isOpenTrackingInfoWitPlace(e5) {
    return "object" == typeof e5 && "place_at_the_top" in e5;
  }
  async get(e5) {
    const a2 = await this.request.get(`/v2/x509/${e5}/status`);
    return { ...a2.body, responseStatusCode: a2.status };
  }
  async generate(e5) {
    const a2 = await this.request.post(`/v2/x509/${e5}`);
    return { ...a2.body, status: a2.status };
  }
  async regenerate(e5) {
    const a2 = await this.request.put(`/v2/x509/${e5}`);
    return { ...a2.body, status: a2.status };
  }
  async getTracking(e5) {
    const a2 = await this.request.get(j("/v3/domains", e5, "tracking"));
    return this._parseTrackingSettings(a2);
  }
  async updateTracking(e5, a2, n2) {
    const t2 = { ...n2 };
    "boolean" == typeof n2?.active && (t2.active = n2?.active ? "yes" : "no"), this._isOpenTrackingInfoWitPlace(n2) && "boolean" == typeof n2?.place_at_the_top && (t2.place_at_the_top = n2?.place_at_the_top ? "yes" : "no");
    const s2 = await this.request.putWithFD(j("/v3/domains", e5, "tracking", a2), t2);
    return this._parseTrackingUpdate(s2);
  }
};
var Lo = class {
  request;
  domains;
  webhooks;
  events;
  stats;
  metrics;
  suppressions;
  messages;
  routes;
  validate;
  ips;
  ip_pools;
  lists;
  subaccounts;
  inboxPlacements;
  constructor(e5, a2) {
    const n2 = { ...e5 };
    if (n2.url || (n2.url = "https://api.mailgun.net"), !n2.username) throw new Error('Parameter "username" is required');
    if (!n2.key) throw new Error('Parameter "key" is required');
    this.request = new Vi(n2, a2);
    const t2 = new go(this.request), s2 = new yo(this.request), i2 = new jo(this.request), o2 = new Eo(this.request), r2 = new Bo(this.request), c2 = new _o(this.request), p2 = new Fo(this.request), l2 = new Ao(this.request, "/v4/inbox/seedlists/a"), u2 = new Ao(this.request, "/v4/inbox/results/a"), d2 = new Oo(this.request, "/v4/inbox/seedlists/_filters"), m2 = new Oo(this.request, "/v4/inbox/results/_filters"), h2 = new To(this.request, l2, d2), f2 = new Co(this.request, u2, m2, p2), x2 = new Do(this.request);
    this.domains = new Ji(this.request, s2, i2, o2, r2), this.webhooks = new uo(this.request), this.events = new Qi(this.request), this.stats = new Xi(this.request), this.metrics = new Po(this.request), this.suppressions = new po(this.request), this.messages = new mo(this.request), this.routes = new ho(this.request), this.ips = new xo(this.request), this.ip_pools = new vo(this.request), this.lists = new bo(this.request, t2), this.validate = new fo(this.request, c2), this.subaccounts = new Hi(this.request), this.inboxPlacements = new qo(this.request, h2, f2, x2);
  }
  setSubaccount(e5) {
    this.request?.setSubaccountHeader(e5);
  }
  resetSubaccount() {
    this.request?.resetSubaccountHeader();
  }
};
var Uo = class {
  static get default() {
    return this;
  }
  formData;
  constructor(e5) {
    this.formData = e5;
  }
  client(e5) {
    return new Lo(e5, this.formData);
  }
};

// netlify/functions/sendEmail.js
var handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const { name, company, email, phone, interest, message } = JSON.parse(event.body);
    if (!name || !email || !interest || !message) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: "Missing required fields",
          missing: Object.entries({ name, email, interest, message }).filter(([_2, value]) => !value).map(([key]) => key)
        })
      };
    }
    if (!process.env.MAILGUN_API_KEY || !process.env.MAILGUN_DOMAIN) {
      console.error("Mailgun configuration missing");
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: "Email service not configured" })
      };
    }
    const mailgun = new Uo(import_form_data.default);
    const mg = mailgun.client({ username: "api", key: process.env.MAILGUN_API_KEY });
    const emailContent = `
      <h2>New Contact Form Submission</h2>
      <p><strong>Name:</strong> ${name}</p>
      <p><strong>Company:</strong> ${company || "Not provided"}</p>
      <p><strong>Email:</strong> ${email}</p>
      <p><strong>Phone:</strong> ${phone || "Not provided"}</p>
      <p><strong>Interest:</strong> ${interest}</p>
      <p><strong>Message:</strong></p>
      <p>${message}</p>
    `;
    const messageData = {
      from: process.env.FROM_EMAIL,
      to: process.env.TO_EMAIL,
      subject: `New Contact Form Submission: ${interest}`,
      html: emailContent
    };
    const response = await mg.messages.create(process.env.MAILGUN_DOMAIN, messageData);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        message: "Email sent successfully",
        id: response.id
      })
    };
  } catch (error) {
    console.error("Error sending email:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Failed to send email",
        details: error.message
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
/*! Bundled license information:

mime-db/index.js:
  (*!
   * mime-db
   * Copyright(c) 2014 Jonathan Ong
   * Copyright(c) 2015-2022 Douglas Christopher Wilson
   * MIT Licensed
   *)

mime-types/index.js:
  (*!
   * mime-types
   * Copyright(c) 2014 Jonathan Ong
   * Copyright(c) 2015 Douglas Christopher Wilson
   * MIT Licensed
   *)

mailgun.js/ESM/mailgun.node.js:
  (*! https://mths.be/base64 v1.0.0 by @mathias | MIT license *)
*/
